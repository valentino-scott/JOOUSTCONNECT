// ---------------- CSRF Token ----------------
let cachedCSRF = null;
function getCSRFToken() {
    if (cachedCSRF) return cachedCSRF;
    const match = document.cookie.split('; ').find(c => c.startsWith('csrftoken='));
    cachedCSRF = match ? decodeURIComponent(match.split('=')[1]) : null;
    return cachedCSRF;
}

// ---------------- Utility: POST Fetch ----------------
async function postRequest(url, data = {}) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCSRFToken(),
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams(data)
        });
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (err) {
        console.error('Fetch error:', err);
        throw err;
    }
}

// ---------------- Notifications ----------------
function showNotification(type, message) {
    const containerId = 'notification-container';
    let container = document.getElementById(containerId);
    if (!container) {
        container = document.createElement('div');
        container.id = containerId;
        container.style.cssText = 'position: fixed; top: 20px; right: 20px; z-index: 10000;';
        document.body.appendChild(container);
    }

    const notif = document.createElement('div');
    notif.style.cssText = `
        margin-top: 8px;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        color: white;
        background-color: ${getNotificationColor(type)};
        transition: all 0.3s ease;
        transform: translateX(100%);
    `;
    notif.textContent = message;
    container.appendChild(notif);

    setTimeout(() => notif.style.transform = 'translateX(0)', 100);
    setTimeout(() => {
        notif.style.transform = 'translateX(100%)';
        setTimeout(() => notif.remove(), 300);
    }, 3000);
}

function getNotificationColor(type) {
    const colors = {
        success: 'var(--success, #00ba7c)',
        error: 'var(--error, #f91880)',
        info: 'var(--text-muted, #71767b)'
    };
    return colors[type] || colors.info;
}

// ---------------- Post Interactions ----------------
class PostInteractions {
    constructor(containerSelector = null) {
        this.container = containerSelector ? document.querySelector(containerSelector) : document;
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        this.container.addEventListener('click', (e) => {
            const likeBtn = e.target.closest('[data-action="like-post"]');
            if (likeBtn) { e.preventDefault(); e.stopPropagation(); this.likePost(likeBtn.dataset.postId, likeBtn); }

            const repostBtn = e.target.closest('[data-action="repost-post"]');
            if (repostBtn) { e.preventDefault(); e.stopPropagation(); this.repostPost(repostBtn.dataset.postId, repostBtn); }

            const commentBtn = e.target.closest('[data-action="comment-post"]');
            if (commentBtn) { e.preventDefault(); e.stopPropagation(); this.commentPost(commentBtn.dataset.postId); }
        });
    }

    async likePost(postId, button) {
        try {
            const data = await postRequest(`/posts/${postId}/like/`);
            this.updateLikeUI(button, data);
        } catch {
            this.toggleLikeUI(button);
        }
    }

    async repostPost(postId, button) {
        try {
            const data = await postRequest(`/posts/${postId}/repost/`);
            this.updateRepostUI(button, data);
        } catch {
            this.toggleRepostUI(button);
        }
    }

    updateLikeUI(button, data) {
        const likeCount = button.querySelector('span');
        const icon = button.querySelector('i');
        if (!likeCount || !icon) return;

        const liked = data.liked || data.success;
        const newCount = data.like_count || data.likes_count;

        if (liked) {
            likeCount.textContent = newCount ?? (parseInt(likeCount.textContent) + 1);
            icon.classList.replace('far', 'fas');
            button.style.color = '#f91880';
        } else {
            likeCount.textContent = newCount ?? Math.max(0, parseInt(likeCount.textContent) - 1);
            icon.classList.replace('fas', 'far');
            button.style.color = '';
        }
    }

    updateRepostUI(button, data) {
        const repostCount = button.querySelector('span');
        if (!repostCount) return;

        const reposted = data.reposted || data.success;
        const newCount = data.repost_count || data.reposts_count;

        if (reposted) {
            repostCount.textContent = newCount ?? (parseInt(repostCount.textContent) + 1);
            button.style.color = '#00ba7c';
        } else {
            repostCount.textContent = newCount ?? Math.max(0, parseInt(repostCount.textContent) - 1);
            button.style.color = '';
        }
    }

    toggleLikeUI(button) {
        const likeCount = button.querySelector('span');
        const icon = button.querySelector('i');
        if (!likeCount || !icon) return;

        if (icon.classList.contains('far')) {
            likeCount.textContent = parseInt(likeCount.textContent) + 1;
            icon.classList.replace('far', 'fas');
            button.style.color = '#f91880';
        } else {
            likeCount.textContent = Math.max(0, parseInt(likeCount.textContent) - 1);
            icon.classList.replace('fas', 'far');
            button.style.color = '';
        }
    }

    toggleRepostUI(button) {
        const repostCount = button.querySelector('span');
        if (!repostCount) return;

        if (button.style.color === 'rgb(0, 186, 124)') {
            repostCount.textContent = Math.max(0, parseInt(repostCount.textContent) - 1);
            button.style.color = '';
        } else {
            repostCount.textContent = parseInt(repostCount.textContent) + 1;
            button.style.color = '#00ba7c';
        }
    }

    commentPost(postId) {
        window.location.href = `/posts/${postId}/`;
    }
}

// ---------------- Follow System ----------------
class FollowSystem {
    constructor(containerSelector = null) {
        this.container = containerSelector ? document.querySelector(containerSelector) : document;
        this.init();
    }

    init() { this.bindEvents(); }

    bindEvents() {
        this.container.addEventListener('click', (e) => {
            const followBtn = e.target.closest('[data-action="follow-user"], #followBtn, .follow-btn[data-username]');
            if (!followBtn) return;
            e.preventDefault();
            e.stopPropagation();
            const username = followBtn.dataset.username;
            if (username) this.followUser(username, followBtn);
        });
    }

    async followUser(username, button) {
        if (!username || button.disabled) return;

        const originalHTML = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        button.disabled = true;

        try {
            const data = await postRequest(`/accounts/follow/${username}/`);
            this.updateFollowUI(button, data);
        } catch {
            this.toggleFollowUI(button);
        }
    }

    updateFollowUI(button, data) {
        if (data.error) {
            console.error('Follow error:', data.error);
            showNotification('error', 'Follow failed');
            button.innerHTML = this.getFollowButtonHTML(false);
            button.disabled = false;
            return;
        }

        const isNowFollowing = data.status === 'followed';
        button.innerHTML = this.getFollowButtonHTML(isNowFollowing);
        button.classList.toggle('following', isNowFollowing);

        if (isNowFollowing) showNotification('success', 'Following user');
        else showNotification('info', 'Unfollowed user');

        if (data.followers_count) this.updateFollowerCounts(data.followers_count);

        button.disabled = false;
    }

    toggleFollowUI(button) {
        const isFollowing = button.classList.contains('following');
        button.innerHTML = this.getFollowButtonHTML(!isFollowing);
        button.classList.toggle('following');
        showNotification(isFollowing ? 'info' : 'success', isFollowing ? 'Unfollowed user' : 'Following user');
        button.disabled = false;
    }

    getFollowButtonHTML(isFollowing) {
        return isFollowing
            ? '<i class="fas fa-user-check"></i> Following'
            : '<i class="fas fa-user-plus"></i> Follow';
    }

    updateFollowerCounts(followersCount) {
        document.querySelectorAll('.stat-count').forEach(el => {
            const label = el.nextElementSibling?.textContent?.toLowerCase();
            if (label?.includes('follower')) el.textContent = followersCount;
        });
    }
}

// ---------------- Utilities ----------------
function formatAllTimes() {
    document.querySelectorAll('.post-time').forEach(el => {
        const timestamp = el.dataset.timestamp;
        if (!timestamp) return;

        const postTime = new Date(timestamp);
        const diffMs = new Date() - postTime;
        const mins = Math.floor(diffMs / 60000);
        const hours = Math.floor(mins / 60);
        const days = Math.floor(hours / 24);
        const weeks = Math.floor(days / 7);
        const months = Math.floor(days / 30);
        const years = Math.floor(days / 365);

        let formatted = '';
        if (mins < 1) formatted = 'now';
        else if (mins < 60) formatted = `${mins}m`;
        else if (hours < 24) formatted = `${hours}h`;
        else if (days < 7) formatted = `${days}d`;
        else if (weeks < 4) formatted = `${weeks}w`;
        else if (months < 12) formatted = `${months}mo`;
        else formatted = `${years}y`;

        el.textContent = formatted;
    });
}

function initializeShowMore() {
    const trendingItems = document.querySelectorAll('.trending-item');
    const followItems = document.querySelectorAll('.follow-item');

    if (trendingItems.length <= 3) document.querySelector('.trending-widget .show-more')?.style.display = 'none';
    if (followItems.length <= 3) document.querySelector('.follow-widget .show-more')?.style.display = 'none';
}

function initializeFollowButtons() {
    document.querySelectorAll('.follow-btn[data-initial-state]').forEach(button => {
        const initialState = button.dataset.initialState;
        button.innerHTML = initialState === 'following'
            ? '<i class="fas fa-user-check"></i> Following'
            : '<i class="fas fa-user-plus"></i> Follow';
        button.classList.toggle('following', initialState === 'following');
    });
}

// ---------------- Global Backward Compatibility ----------------
function followUser(username) {
    const followBtn = document.getElementById('followBtn');
    if (followBtn && window.followSystem) window.followSystem.followUser(username, followBtn);
}

// ---------------- Initialization ----------------
document.addEventListener('DOMContentLoaded', () => {
    window.postInteractions = new PostInteractions();
    window.followSystem = new FollowSystem();
    formatAllTimes();
    initializeShowMore();
    initializeFollowButtons();
    console.log('All systems initialized successfully');
});
