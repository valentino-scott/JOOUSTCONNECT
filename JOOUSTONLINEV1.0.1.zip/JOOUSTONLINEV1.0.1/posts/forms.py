from django import forms
from .models import Post, Comment, Quote

class PostForm(forms.ModelForm):
    """Form for creating posts"""
    class Meta:
        model = Post
        fields = ('content', 'image', 'video')
        widgets = {
            'content': forms.Textarea(attrs={
                'class': 'w-full px-4 py-2 border-0 focus:ring-0 resize-none dark:bg-gray-800 dark:text-white',
                'rows': 3,
                'placeholder': "What's on your mind?"
            }),
            'image': forms.FileInput(attrs={
                'class': 'hidden',
                'accept': 'image/*'
            }),
            'video': forms.FileInput(attrs={
                'class': 'hidden', 
                'accept': 'video/*'
            }),
        }
    
    def clean_content(self):
        content = self.cleaned_data.get('content', '').strip()
        image = self.cleaned_data.get('image')
        video = self.cleaned_data.get('video')
        
        # Require either content, image, or video
        if not content and not image and not video:
            raise forms.ValidationError("Post must contain text, image, or video.")
        
        return content


class CommentForm(forms.ModelForm):
    """Form for creating comments and replies"""
    parent_comment_id = forms.IntegerField(required=False, widget=forms.HiddenInput())
    
    class Meta:
        model = Comment
        fields = ('content',)
        widgets = {
            'content': forms.TextInput(attrs={
                'class': 'w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-full focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white',
                'placeholder': 'Write a comment...'
            }),
        }
    
    def clean_content(self):
        content = self.cleaned_data.get('content', '').strip()
        if not content:
            raise forms.ValidationError("Comment content is required.")
        if len(content) > 1000:
            raise forms.ValidationError("Comment is too long. Maximum 1000 characters.")
        return content


class ReplyForm(forms.ModelForm):
    """Form specifically for replying to comments"""
    class Meta:
        model = Comment
        fields = ('content',)
        widgets = {
            'content': forms.TextInput(attrs={
                'class': 'w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-full focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white text-sm',
                'placeholder': 'Write your reply...'
            }),
        }
    
    def clean_content(self):
        content = self.cleaned_data.get('content', '').strip()
        if not content:
            raise forms.ValidationError("Reply content is required.")
        if len(content) > 1000:
            raise forms.ValidationError("Reply is too long. Maximum 1000 characters.")
        return content


class QuoteForm(forms.ModelForm):
    """Form for creating quotes"""
    class Meta:
        model = Quote
        fields = ['quote_content']
        widgets = {
            'quote_content': forms.Textarea(attrs={
                'placeholder': 'Add a comment...',
                'rows': 3,
                'class': 'w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white resize-none'
            }),
        }
        labels = {
            'quote_content': ''
        }
    
    def clean_quote_content(self):
        quote_content = self.cleaned_data.get('quote_content', '').strip()
        if not quote_content:
            raise forms.ValidationError("Quote comment is required.")
        if len(quote_content) > 280:
            raise forms.ValidationError("Quote comment is too long. Maximum 280 characters.")
        return quote_content