from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.utils.html import format_html
from .models import User, Profile, Follow

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Custom User admin"""
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active_account', 'date_joined')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'is_active_account', 'date_joined')
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    readonly_fields = ('date_joined', 'last_login')
    
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Account Status', {'fields': ('is_active_account',)}),
    )
    
    # Add actions for bulk operations
    actions = ['activate_accounts', 'deactivate_accounts']
    
    def activate_accounts(self, request, queryset):
        """Activate selected user accounts"""
        updated = queryset.update(is_active_account=True)
        self.message_user(request, f'{updated} user(s) successfully activated.')
    activate_accounts.short_description = "Activate selected user accounts"
    
    def deactivate_accounts(self, request, queryset):
        """Deactivate selected user accounts"""
        updated = queryset.update(is_active_account=False)
        self.message_user(request, f'{updated} user(s) successfully deactivated.')
    deactivate_accounts.short_description = "Deactivate selected user accounts"


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    """Profile admin"""
    list_display = ('user', 'course', 'department', 'year', 'has_blue_tick', 'created_at', 'profile_photo_preview')
    
    # Only real model fields in list_filter
    list_filter = ('year', 'department', 'created_at')  # removed has_blue_tick
    search_fields = ('user__username', 'user__email', 'course', 'department', 'bio')
    readonly_fields = ('created_at', 'updated_at', 'profile_photo_preview')
    list_editable = ()  # removed has_blue_tick
    list_per_page = 25
    
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'profile_photo_preview', 'photo')
        }),
        ('Academic Information', {
            'fields': ('course', 'department', 'year')
        }),
        ('Profile Details', {
            'fields': ('bio', 'location', 'website', 'date_of_birth')
        }),
        ('Verification & Status', {
            'fields': ('has_blue_tick', 'is_verified')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        })
    )
    
    def profile_photo_preview(self, obj):
        """Display profile photo preview in admin"""
        if obj.photo:
            return format_html(
                '<img src="{}" width="50" height="50" style="border-radius: 50%; object-fit: cover;" />',
                obj.photo.url
            )
        return "No Photo"
    profile_photo_preview.short_description = 'Photo Preview'


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    """Follow relationship admin"""
    list_display = ('follower', 'following', 'created_at', 'follow_duration')
    list_filter = ('created_at',)
    search_fields = ('follower__username', 'following__username')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at',)
    list_per_page = 50
    
    def follow_duration(self, obj):
        """Calculate how long the follow relationship has existed"""
        from django.utils import timezone
        from django.utils.timesince import timesince
        
        if obj.created_at:
            return timesince(obj.created_at)
        return "N/A"
    follow_duration.short_description = 'Following Since'
    
    # Prevent duplicate follow relationships
    def save_model(self, request, obj, form, change):
        """Prevent duplicate follow relationships"""
        if not change:  # Only for new objects
            if Follow.objects.filter(follower=obj.follower, following=obj.following).exists():
                from django.contrib import messages
                messages.warning(request, f'A follow relationship between {obj.follower} and {obj.following} already exists.')
                return
        super().save_model(request, obj, form, change)
