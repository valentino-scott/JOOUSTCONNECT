from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Subscription, Payment
import uuid

@login_required
def subscriptions_view(request):
    """View subscription plans"""
    subscription, created = Subscription.objects.get_or_create(
        user=request.user,
        defaults={'tier': 'free'}
    )
    
    return render(request, 'subscriptions/plans.html', {
        'subscription': subscription
    })


@login_required
def upgrade_to_premium(request):
    """Upgrade to premium subscription"""
    if request.method == 'POST':
        subscription, created = Subscription.objects.get_or_create(user=request.user)
        
        payment = Payment.objects.create(
            subscription=subscription,
            amount=500.00,
            payment_method=request.POST.get('payment_method', 'mpesa'),
            status='completed',
            transaction_id=str(uuid.uuid4())
        )
        
        subscription.tier = 'premium'
        subscription.is_active = True
        subscription.renew(months=1)
        subscription.save()
        
        messages.success(request, 'Congratulations! You are now a Premium member with a blue tick!')
        return redirect('subscriptions:plans')
    
    return render(request, 'subscriptions/upgrade.html')


@login_required
def cancel_subscription(request):
    """Cancel premium subscription"""
    if request.method == 'POST':
        subscription = request.user.subscription
        subscription.tier = 'free'
        subscription.auto_renew = False
        subscription.save()
        
        messages.success(request, 'Your premium subscription has been cancelled.')
        return redirect('subscriptions:plans')
    
    return render(request, 'subscriptions/cancel.html')
