// CSRF Token function
function getCSRFToken() {
    const name = 'csrftoken';
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Post Interactions - SIMPLIFIED VERSION
class PostInteractions {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            // Like button
            if (e.target.closest('[data-action="like-post"]')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('[data-action="like-post"]');
                const postId = button.dataset.postId;
                this.likePost(postId, button);
            }
            
            // Repost button
            if (e.target.closest('[data-action="repost-post"]')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('[data-action="repost-post"]');
                const postId = button.dataset.postId;
                this.repostPost(postId, button);
            }
            
            // Comment button
            if (e.target.closest('[data-action="comment-post"]')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('[data-action="comment-post"]');
                const postId = button.dataset.postId;
                this.commentPost(postId);
            }
        });
    }

    likePost(postId, button) {
        console.log('Liking post:', postId);
        
        // Use absolute URL to ensure it works from any page
        const url = `/posts/${postId}/like/`;
        
        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCSRFToken(),
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Like response:', data);
            this.updateLikeUI(button, data);
        })
        .catch(error => {
            console.error('Error liking post:', error);
            this.toggleLikeUI(button); // Fallback UI toggle
        });
    }

    repostPost(postId, button) {
        console.log('Reposting post:', postId);
        
        // Use absolute URL to ensure it works from any page
        const url = `/posts/${postId}/repost/`;
        
        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCSRFToken(),
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Repost response:', data);
            this.updateRepostUI(button, data);
        })
        .catch(error => {
            console.error('Error reposting post:', error);
            this.toggleRepostUI(button); // Fallback UI toggle
        });
    }

    updateLikeUI(button, data) {
        const likeCount = button.querySelector('span');
        const icon = button.querySelector('i');
        
        if (likeCount && icon) {
            // Handle different response formats
            const liked = data.liked || data.success;
            const newCount = data.like_count || data.likes_count;
            
            if (liked) {
                // Liked state
                likeCount.textContent = newCount || (parseInt(likeCount.textContent) + 1);
                icon.classList.remove('far');
                icon.classList.add('fas');
                button.style.color = '#f91880';
            } else {
                // Unliked state
                likeCount.textContent = newCount || Math.max(0, parseInt(likeCount.textContent) - 1);
                icon.classList.remove('fas');
                icon.classList.add('far');
                button.style.color = '';
            }
        }
    }

    updateRepostUI(button, data) {
        const repostCount = button.querySelector('span');
        
        if (repostCount) {
            // Handle different response formats
            const reposted = data.reposted || data.success;
            const newCount = data.repost_count || data.reposts_count;
            
            if (reposted) {
                // Reposted state
                repostCount.textContent = newCount || (parseInt(repostCount.textContent) + 1);
                button.style.color = '#00ba7c';
            } else {
                // Unreposted state
                repostCount.textContent = newCount || Math.max(0, parseInt(repostCount.textContent) - 1);
                button.style.color = '';
            }
        }
    }

    toggleLikeUI(button) {
        const likeCount = button.querySelector('span');
        const icon = button.querySelector('i');
        
        if (likeCount && icon) {
            if (icon.classList.contains('far')) {
                // Like it
                likeCount.textContent = parseInt(likeCount.textContent) + 1;
                icon.classList.remove('far');
                icon.classList.add('fas');
                button.style.color = '#f91880';
            } else {
                // Unlike it
                likeCount.textContent = Math.max(0, parseInt(likeCount.textContent) - 1);
                icon.classList.remove('fas');
                icon.classList.add('far');
                button.style.color = '';
            }
        }
    }

    toggleRepostUI(button) {
        const repostCount = button.querySelector('span');
        
        if (repostCount) {
            if (button.style.color === 'rgb(0, 186, 124)') {
                // Unrepost
                repostCount.textContent = Math.max(0, parseInt(repostCount.textContent) - 1);
                button.style.color = '';
            } else {
                // Repost
                repostCount.textContent = parseInt(repostCount.textContent) + 1;
                button.style.color = '#00ba7c';
            }
        }
    }

    commentPost(postId) {
        window.location.href = `/posts/${postId}/`;
    }
}

// Follow Functionality - SIMPLIFIED VERSION
class FollowSystem {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        document.addEventListener('click', (e) => {
            // Follow button in Who to Follow section
            if (e.target.closest('[data-action="follow-user"]')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('[data-action="follow-user"]');
                const username = button.dataset.username;
                this.followUser(username, button);
            }
            
            // Follow button in profile page
            if (e.target.closest('#followBtn')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('#followBtn');
                const username = button.dataset.username;
                if (username) {
                    this.followUser(username, button);
                }
            }
            
            // Generic follow buttons with data-username attribute
            if (e.target.closest('.follow-btn[data-username]')) {
                e.preventDefault();
                e.stopPropagation();
                const button = e.target.closest('.follow-btn[data-username]');
                const username = button.dataset.username;
                this.followUser(username, button);
            }
        });
    }

    followUser(username, button) {
        console.log('Following user:', username);
        
        if (!username) {
            console.log('No username found for follow button');
            return;
        }
        
        // Prevent multiple clicks
        if (button.disabled) return;
        
        // Show loading state
        const originalHTML = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        button.disabled = true;
        
        // Use absolute URL to ensure it works from any page
        const url = `/accounts/follow/${username}/`;
        
        fetch(url, {
            method: 'POST',
            headers: {
                'X-CSRFToken': getCSRFToken(),
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log('Follow response:', data);
            this.updateFollowUI(button, data);
        })
        .catch(error => {
            console.error('Error following user:', error);
            this.toggleFollowUI(button); // Fallback UI toggle
        });
    }

    updateFollowUI(button, data) {
        if (data.error) {
            // Handle error from server
            console.error('Follow error:', data.error);
            this.showNotification('error', 'Follow failed');
            button.innerHTML = this.getFollowButtonHTML(false);
            button.disabled = false;
            return;
        }
        
        // Update button state based on response
        const isNowFollowing = data.status === 'followed';
        
        if (isNowFollowing) {
            button.innerHTML = this.getFollowButtonHTML(true);
            button.classList.add('following');
            this.showNotification('success', 'Following user');
        } else {
            button.innerHTML = this.getFollowButtonHTML(false);
            button.classList.remove('following');
            this.showNotification('info', 'Unfollowed user');
        }
        
        // Update follower counts if available
        if (data.followers_count) {
            this.updateFollowerCounts(data.followers_count);
        }
        
        button.disabled = false;
    }

    toggleFollowUI(button) {
        const isCurrentlyFollowing = button.classList.contains('following');
        
        if (isCurrentlyFollowing) {
            // Unfollow
            button.innerHTML = this.getFollowButtonHTML(false);
            button.classList.remove('following');
            this.showNotification('info', 'Unfollowed user');
        } else {
            // Follow
            button.innerHTML = this.getFollowButtonHTML(true);
            button.classList.add('following');
            this.showNotification('success', 'Following user');
        }
        
        button.disabled = false;
    }

    getFollowButtonHTML(isFollowing) {
        if (isFollowing) {
            return '<i class="fas fa-user-check"></i> Following';
        } else {
            return '<i class="fas fa-user-plus"></i> Follow';
        }
    }

    updateFollowerCounts(followersCount) {
        // Update follower count in profile page if available
        const followerCountElements = document.querySelectorAll('.stat-count');
        followerCountElements.forEach(element => {
            // You might want to be more specific about which element to update
            const label = element.nextElementSibling?.textContent?.toLowerCase();
            if (label && label.includes('follower')) {
                element.textContent = followersCount;
            }
        });
    }

    showNotification(type, message) {
        // Create a subtle notification
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            z-index: 10000;
            transition: all 0.3s ease;
            transform: translateX(100%);
            background-color: ${this.getNotificationColor(type)};
            color: white;
        `;
        
        notification.textContent = message;
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => {
            notification.style.transform = 'translateX(0)';
        }, 100);
        
        // Animate out and remove
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    getNotificationColor(type) {
        const colors = {
            success: 'var(--success, #00ba7c)',
            error: 'var(--error, #f91880)',
            info: 'var(--text-muted, #71767b)'
        };
        return colors[type] || colors.info;
    }
}

// Utility Functions
function formatAllTimes() {
    const timeElements = document.querySelectorAll('.post-time');
    timeElements.forEach(el => {
        const timestamp = el.getAttribute('data-timestamp');
        let formattedTime = '';
        
        if (timestamp) {
            const postTime = new Date(timestamp);
            const now = new Date();
            const diffMs = now - postTime;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMs / 3600000);
            const diffDays = Math.floor(diffMs / 86400000);
            const diffWeeks = Math.floor(diffDays / 7);
            const diffMonths = Math.floor(diffDays / 30);
            const diffYears = Math.floor(diffDays / 365);
            
            if (diffMins < 1) {
                formattedTime = 'now';
            } else if (diffMins < 60) {
                formattedTime = `${diffMins}m`;
            } else if (diffHours < 24) {
                formattedTime = `${diffHours}h`;
            } else if (diffDays < 7) {
                formattedTime = `${diffDays}d`;
            } else if (diffWeeks < 4) {
                formattedTime = `${diffWeeks}w`;
            } else if (diffMonths < 12) {
                formattedTime = `${diffMonths}mo`;
            } else {
                formattedTime = `${diffYears}y`;
            }
        } else {
            const timeText = el.textContent.trim().toLowerCase();
            if (timeText.includes('minute')) {
                formattedTime = timeText.replace('minute', 'm').replace('minutes', 'm').replace('ago', '').trim();
            } else if (timeText.includes('hour')) {
                formattedTime = timeText.replace('hour', 'h').replace('hours', 'h').replace('ago', '').trim();
            } else if (timeText.includes('day')) {
                formattedTime = timeText.replace('day', 'd').replace('days', 'd').replace('ago', '').trim();
            } else if (timeText.includes('week')) {
                formattedTime = timeText.replace('week', 'w').replace('weeks', 'w').replace('ago', '').trim();
            } else if (timeText.includes('month')) {
                formattedTime = timeText.replace('month', 'mo').replace('months', 'mo').replace('ago', '').trim();
            } else if (timeText.includes('year')) {
                formattedTime = timeText.replace('year', 'y').replace('years', 'y').replace('ago', '').trim();
            } else if (timeText.includes('second')) {
                formattedTime = timeText.replace('second', 's').replace('seconds', 's').replace('ago', '').trim();
            } else if (timeText.includes('just now')) {
                formattedTime = 'now';
            } else {
                formattedTime = timeText.replace('ago', '').trim();
            }
        }
        
        el.textContent = formattedTime;
    });
}

function initializeShowMore() {
    // Check if we have enough items to need "Show more"
    const trendingItems = document.querySelectorAll('.trending-item');
    const followItems = document.querySelectorAll('.follow-item');
    
    if (trendingItems.length <= 3) {
        const trendingButton = document.querySelector('.trending-widget .show-more');
        if (trendingButton) trendingButton.style.display = 'none';
    }
    
    if (followItems.length <= 3) {
        const followButton = document.querySelector('.follow-widget .show-more');
        if (followButton) followButton.style.display = 'none';
    }
}

function initializeFollowButtons() {
    // Set initial state for follow buttons based on data attributes
    document.querySelectorAll('.follow-btn[data-initial-state]').forEach(button => {
        const initialState = button.dataset.initialState;
        if (initialState === 'following') {
            button.innerHTML = '<i class="fas fa-user-check"></i> Following';
            button.classList.add('following');
        } else {
            button.innerHTML = '<i class="fas fa-user-plus"></i> Follow';
            button.classList.remove('following');
        }
    });
}

// Global function for profile page follow button (backward compatibility)
function followUser(username) {
    const followBtn = document.getElementById('followBtn');
    if (followBtn && window.followSystem) {
        window.followSystem.followUser(username, followBtn);
    }
}

// Initialize all systems when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize post interactions
    window.postInteractions = new PostInteractions();
    
    // Initialize follow system
    window.followSystem = new FollowSystem();
    
    // Initialize other utilities
    formatAllTimes();
    initializeShowMore();
    initializeFollowButtons();
    
    console.log('All systems initialized successfully');
});