from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from accounts.models import Profile, Follow
from posts.models import Post, Like, Comment
from messaging.models import Thread, Message
from notifications.models import Notification
from subscriptions.models import Subscription
from reports.models import Report
from announcements.models import Announcement

User = get_user_model()

class Command(BaseCommand):
    help = 'Populate database with dummy data for demonstration'
    
    def handle(self, *args, **kwargs):
        self.stdout.write('Creating dummy data...')
        
        users = []
        usernames = ['john_doe', 'jane_smith', 'mike_wilson', 'sarah_jones', 'alex_brown']
        courses = ['Computer Science', 'Information Technology', 'Business IT', 'Data Science', 'Software Engineering']
        departments = ['School of Computing', 'School of Informatics', 'School of Computing', 'School of Informatics', 'School of Computing']
        
        for i, username in enumerate(usernames):
            if User.objects.filter(username=username).exists():
                user = User.objects.get(username=username)
            else:
                user = User.objects.create_user(
                    username=username,
                    email=f'{username}@jooust.ac.ke',
                    password='password123',
                    first_name=username.split('_')[0].capitalize(),
                    last_name=username.split('_')[1].capitalize()
                )
                user.profile.course = courses[i]
                user.profile.department = departments[i]
                user.profile.year = str((i % 4) + 1)
                user.profile.bio = f'JOOUST student studying {courses[i]}. Year {(i % 4) + 1}.'
                user.profile.save()
            users.append(user)
        
        self.stdout.write(f'Created {len(users)} users')
        
        Follow.objects.get_or_create(follower=users[0], following=users[1])
        Follow.objects.get_or_create(follower=users[0], following=users[2])
        Follow.objects.get_or_create(follower=users[1], following=users[0])
        Follow.objects.get_or_create(follower=users[2], following=users[0])
        Follow.objects.get_or_create(follower=users[3], following=users[0])
        
        self.stdout.write('Created follow relationships')
        
        posts_data = [
            {'user': 0, 'content': 'Just finished my Data Structures assignment! 🎉 #JOOUST #ComputerScience'},
            {'user': 1, 'content': 'Anyone heading to the library? Need a study partner for the upcoming exams.'},
            {'user': 2, 'content': 'The new cafeteria menu is amazing! Finally some variety on campus. 🍔'},
            {'user': 0, 'content': 'Excited about the upcoming tech hackathon at JOOUST! Who\'s participating?'},
            {'user': 3, 'content': 'Great lecture today on Machine Learning. Professor was on fire! 🔥'},
            {'user': 4, 'content': 'Looking for project partners for Software Engineering. DM me!'},
            {'user': 1, 'content': 'Campus life at JOOUST is the best! Love the community here. ❤️'},
            {'user': 2, 'content': 'Don\'t forget: Assignment deadline is tomorrow! #StudyMode'},
            {'user': 3, 'content': 'Just joined JOOUST CONNECT! This platform is amazing for staying connected.'},
            {'user': 4, 'content': 'Who else is excited for the upcoming university games? 🏆 #JOOUSTEvents'},
        ]
        
        posts = []
        for post_data in posts_data:
            post, created = Post.objects.get_or_create(
                user=users[post_data['user']],
                content=post_data['content']
            )
            posts.append(post)
        
        self.stdout.write(f'Created {len(posts)} posts')
        
        Like.objects.get_or_create(user=users[1], post=posts[0])
        Like.objects.get_or_create(user=users[2], post=posts[0])
        Like.objects.get_or_create(user=users[0], post=posts[1])
        Comment.objects.get_or_create(user=users[1], post=posts[0], content='Great job!')
        Comment.objects.get_or_create(user=users[2], post=posts[3], content='Count me in!')
        
        self.stdout.write('Created likes and comments')
        
        thread1, _ = Thread.objects.get_or_create()
        if thread1.participants.count() == 0:
            thread1.participants.add(users[0], users[1])
        Message.objects.get_or_create(
            thread=thread1,
            sender=users[0],
            content='Hey! Are you free to study together this weekend?'
        )
        Message.objects.get_or_create(
            thread=thread1,
            sender=users[1],
            content='Sure! Let\'s meet at the library on Saturday.'
        )
        
        thread2, _ = Thread.objects.get_or_create()
        if thread2.participants.count() == 0:
            thread2.participants.add(users[0], users[2])
        Message.objects.get_or_create(
            thread=thread2,
            sender=users[2],
            content='Thanks for the notes! Really helpful.'
        )
        
        self.stdout.write('Created message threads')
        
        Subscription.objects.get_or_create(user=users[0], defaults={'tier': 'premium', 'is_active': True})
        Subscription.objects.get_or_create(user=users[1], defaults={'tier': 'free'})
        
        self.stdout.write('Created subscriptions')
        
        Report.objects.get_or_create(
            reporter=users[1],
            reported_post=posts[5],
            report_type='spam',
            description='This looks like spam content',
            defaults={'status': 'pending'}
        )
        Report.objects.get_or_create(
            reporter=users[2],
            reported_user=users[4],
            report_type='other',
            description='Inappropriate behavior',
            defaults={'status': 'under_review'}
        )
        
        self.stdout.write('Created reports')
        
        Announcement.objects.get_or_create(
            author=users[0],
            title='Welcome to JOOUST CONNECT!',
            content='We are excited to launch JOOUST CONNECT, the new social networking platform for all JOOUST students. Connect with fellow students, share updates, and stay informed about university events and announcements.',
            category='general',
            defaults={'is_pinned': True}
        )
        Announcement.objects.get_or_create(
            author=users[0],
            title='Upcoming Exams Schedule',
            content='End of semester exams will begin on December 1st. Please check the academic portal for your personalized timetable. Good luck to all students!',
            category='academic'
        )
        
        self.stdout.write('Created announcements')
        
        self.stdout.write(self.style.SUCCESS('Successfully populated database with dummy data!'))
        self.stdout.write(self.style.SUCCESS('You can now login with any of these users:'))
        for user in users:
            self.stdout.write(f'  Username: {user.username} | Password: password123')
