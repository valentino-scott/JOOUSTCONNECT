from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from posts.models import Post, Like, Repost, Quote
from accounts.models import Follow, User
import datetime
from django.utils import timezone
from django.db.models import Count, Q

@login_required
def home_view(request):
    """Home feed with posts from followed users"""
    # Get posts from followed users and current user
    following_users = Follow.objects.filter(follower=request.user).values_list('following_id', flat=True)
    
    posts = Post.objects.filter(user__in=following_users) | Post.objects.filter(user=request.user)
    posts = posts.distinct().order_by('-created_at')[:50]
    
    # Get user engagement data
    user_liked_ids = list(Like.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_reposted_ids = list(Repost.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_quoted_ids = list(Quote.objects.filter(user=request.user).values_list('original_post_id', flat=True))
    
    # Get trending topics (hashtags from last 7 days)
    one_week_ago = timezone.now() - datetime.timedelta(days=7)
    
    # Simple trending logic - analyze recent posts for hashtags
    recent_posts = Post.objects.filter(
        created_at__gte=one_week_ago
    ).exclude(
        Q(content__isnull=True) | Q(content__exact='')
    ).order_by('-created_at')[:100]  # Get recent posts for analysis
    
    hashtag_counts = {}
    for post in recent_posts:
        if '#' in post.content:
            words = post.content.split()
            for word in words:
                if word.startswith('#') and len(word) > 1:
                    hashtag = word.lower()
                    hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1
    
    # Convert to trending topics format
    trending_topics = []
    for hashtag, count in sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:3]:
        # Determine category based on hashtag content
        category = "Trending at JOOUST"
        if any(term in hashtag for term in ['exam', 'study', 'class', 'lecture']):
            category = "Academic · Trending"
        elif any(term in hashtag for term in ['event', 'party', 'sport', 'game']):
            category = "Campus Life"
        elif any(term in hashtag for term in ['kenya', 'nairobi', 'kisumu']):
            category = "Trending in Kenya"
        
        trending_topics.append({
            'hashtag': hashtag,
            'post_count': count,
            'category': category
        })
    
    # Fallback trending topics if none found
    if not trending_topics:
        trending_topics = [
            {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
            {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
            {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
        ]
    
    # Get suggested users (users not followed by current user)
    try:
        # Get IDs of users that the current user is following
        following_ids = list(Follow.objects.filter(follower=request.user).values_list('following_id', flat=True))
        following_ids.append(request.user.id)  # Exclude self
        
        # Get random users not followed by current user
        suggested_users = User.objects.exclude(
            id__in=following_ids
        ).exclude(
            is_active=False
        ).order_by('?')[:2]  # Random 2 users
        
    except Exception as e:
        # Fallback if there's any error with user suggestions
        suggested_users = User.objects.filter(
            is_active=True
        ).exclude(
            id=request.user.id
        ).order_by('?')[:2]
    
    # Get profile data for the template
    try:
        profile = request.user.profile
    except:
        profile = None
    
    # Get follow counts
    following_count = request.user.following.count()
    followers_count = request.user.followers.count()
    
    context = {
        'posts': posts,
        'title': 'Home',
        'trending_topics': trending_topics,
        'suggested_users': suggested_users,
        'user_liked_ids': user_liked_ids,
        'user_reposted_ids': user_reposted_ids,
        'user_quoted_ids': user_quoted_ids,
        'profile_user': request.user,  # This is crucial for the template
        'profile': profile,
        'following_count': following_count,
        'followers_count': followers_count,
        'is_following': False,
    }
    
    return render(request, 'core/home.html', context)


def landing_page(request):
    """Landing page for non-authenticated users"""
    if request.user.is_authenticated:
        return home_view(request)
    
    # Provide some default data for landing page if needed
    context = {
        'trending_topics': [
            {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
            {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
            {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
        ],
        'suggested_users': User.objects.filter(is_active=True).order_by('?')[:2],
    }
    
    return render(request, 'core/landing.html', context)