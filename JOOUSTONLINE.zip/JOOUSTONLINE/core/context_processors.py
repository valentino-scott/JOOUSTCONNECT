from django.db.models import Count, Q
from posts.models import Post
from accounts.models import User
import datetime
from django.utils import timezone

def sidebar_data(request):
    context = {}
    
    if request.user.is_authenticated:
        # Get trending topics (hashtags from last 7 days)
        one_week_ago = timezone.now() - datetime.timedelta(days=7)
        
        # Simple trending logic - you can improve this based on your Post model
        try:
            # Get recent posts with hashtags
            recent_posts = Post.objects.filter(
                created_at__gte=one_week_ago
            ).exclude(
                Q(content__isnull=True) | Q(content__exact='')
            ).order_by('-created_at')[:50]  # Get recent posts for analysis
            
            # Simple hashtag extraction (you might want to improve this)
            hashtag_counts = {}
            for post in recent_posts:
                if '#' in post.content:
                    words = post.content.split()
                    for word in words:
                        if word.startswith('#') and len(word) > 1:
                            hashtag = word.lower()
                            hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1
            
            # Convert to trending topics format
            trending_topics = []
            for hashtag, count in sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:3]:
                trending_topics.append({
                    'hashtag': hashtag,
                    'post_count': count,
                    'category': 'Trending at JOOUST'
                })
            
            # If no trending topics found, use defaults
            if not trending_topics:
                trending_topics = [
                    {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
                    {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
                    {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
                ]
                
            context['trending_topics'] = trending_topics
            
        except Exception as e:
            # Fallback if there's any error
            context['trending_topics'] = [
                {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
                {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
                {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
            ]
        
        # Get suggested users (users not followed by current user)
        try:
            # Assuming you have a follow system - adjust based on your model
            following_ids = []
            if hasattr(request.user, 'following'):
                following_ids = list(request.user.following.values_list('id', flat=True))
            
            suggested_users = User.objects.exclude(
                id__in=following_ids + [request.user.id]
            ).order_by('?')[:2]  # Random 2 users
            
            context['suggested_users'] = suggested_users
            
        except Exception as e:
            # Fallback if there's any error with user suggestions
            context['suggested_users'] = User.objects.filter(is_staff=True)[:2]
    
    else:
        # Default data for non-authenticated users
        context['trending_topics'] = [
            {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
            {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
            {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
        ]
        context['suggested_users'] = User.objects.filter(is_staff=True)[:2]
    
    return context