from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import Notification

@login_required
def notifications_view(request):
    """View all notifications"""
    notifications = request.user.notifications.all()[:50]
    
    request.user.notifications.filter(is_read=False).update(is_read=True)
    
    return render(request, 'notifications/list.html', {
        'notifications': notifications
    })


@login_required
def unread_count(request):
    """Get unread notification count"""
    count = request.user.notifications.filter(is_read=False).count()
    return JsonResponse({'count': count})


@login_required
def mark_as_read(request, notification_id):
    """Mark a notification as read"""
    if request.method == 'POST':
        notification = request.user.notifications.filter(id=notification_id).first()
        if notification:
            notification.is_read = True
            notification.save()
            return JsonResponse({'status': 'success'})
    
    return JsonResponse({'error': 'Invalid request'}, status=400)
