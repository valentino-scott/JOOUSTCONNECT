from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Announcement

@login_required
def announcements_list(request):
    """View all announcements"""
    announcements = Announcement.objects.filter(is_published=True)
    
    return render(request, 'announcements/list.html', {
        'announcements': announcements
    })


@login_required
def announcement_detail(request, announcement_id):
    """View announcement details"""
    announcement = get_object_or_404(Announcement, id=announcement_id, is_published=True)
    
    return render(request, 'announcements/detail.html', {
        'announcement': announcement
    })
