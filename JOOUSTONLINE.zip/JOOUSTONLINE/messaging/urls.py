from django.urls import path
from . import views

app_name = 'messaging'

urlpatterns = [
    path('', views.inbox_view, name='inbox'),
    path('thread/<int:thread_id>/', views.thread_view, name='thread'),
    path('send/', views.send_message, name='send_message'),  # Add this line
    path('start/<str:username>/', views.start_thread, name='start_thread'),
    path('delete/<int:thread_id>/', views.delete_thread, name='delete_thread'),
]