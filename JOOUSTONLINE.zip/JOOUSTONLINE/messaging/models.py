from django.db import models
from django.conf import settings
import os
import uuid

def message_image_path(instance, filename):
    """Generate path for message images: message_images/thread_id/filename"""
    ext = filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{ext}"
    return f'message_images/{instance.thread.id}/{filename}'

def message_file_path(instance, filename):
    """Generate path for message files: message_files/thread_id/filename"""
    ext = filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{ext}"
    return f'message_files/{instance.thread.id}/{filename}'

class ThreadManager(models.Manager):
    def get_or_create_thread(self, user1, user2):
        """Get or create a 1-to-1 thread between two users."""
        threads = self.filter(participants=user1).filter(participants=user2)
        
        if threads.exists():
            return threads.first()
        
        thread = self.create()
        thread.participants.add(user1, user2)
        return thread

    def get_user_threads(self, user):
        """Get all threads for a user."""
        return self.filter(participants=user).prefetch_related(
            'participants',
            'messages'
        ).distinct()

class Thread(models.Model):
    participants = models.ManyToManyField(settings.AUTH_USER_MODEL, related_name='threads')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = ThreadManager()

    class Meta:
        ordering = ['-updated_at']
        indexes = [
            models.Index(fields=['-updated_at']),
        ]

    def __str__(self):
        # Use list comprehension to avoid database queries in __str__
        participant_names = [user.username for user in self.participants.all()]
        return f"Thread {self.id} – {', '.join(participant_names)}"

    def get_other_user(self, current_user):
        """Return the other participant in a 1-to-1 thread."""
        return self.participants.exclude(id=current_user.id).first()

    @property
    def last_message(self):
        """Most recent message in this thread."""
        try:
            return self.messages.order_by('-created_at').first()
        except Exception:
            return None

    def touch(self):
        """Update only the `updated_at` field without saving other fields."""
        self.save(update_fields=['updated_at'])

    def add_participants(self, users):
        """Add multiple participants to the thread."""
        self.participants.add(*users)

    def is_participant(self, user):
        """Check if user is a participant in this thread."""
        return self.participants.filter(id=user.id).exists()


class Message(models.Model):
    MESSAGE_TYPES = (
        ('text', 'Text'),
        ('image', 'Image'),
        ('file', 'File'),
        ('system', 'System'),
    )

    thread = models.ForeignKey(Thread, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content = models.TextField(blank=True)
    message_type = models.CharField(max_length=10, choices=MESSAGE_TYPES, default='text')
    
    # File fields
    image = models.ImageField(upload_to=message_image_path, blank=True, null=True)
    file = models.FileField(upload_to=message_file_path, blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True)
    
    # Message status
    is_read = models.BooleanField(default=False)
    is_edited = models.BooleanField(default=False)
    is_deleted = models.BooleanField(default=False)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['created_at']
        indexes = [
            models.Index(fields=['thread', 'created_at']),
            models.Index(fields=['sender', 'created_at']),
            models.Index(fields=['is_read']),
        ]

    def __str__(self):
        if self.message_type == 'image':
            return f"Image message from {self.sender.username}"
        elif self.message_type == 'file':
            return f"File message from {self.sender.username}"
        return f"Message {self.id} from {self.sender.username}"

    def save(self, *args, **kwargs):
        """Override save to set message_type and file_name automatically."""
        # Set message type based on content
        if self.image:
            self.message_type = 'image'
        elif self.file:
            self.message_type = 'file'
            if self.file and not self.file_name:
                self.file_name = os.path.basename(self.file.name)
        elif not self.content.strip() and not self.image and not self.file:
            self.message_type = 'system'
        else:
            self.message_type = 'text'
        
        # Update thread's updated_at when new message is created
        if not self.pk:
            try:
                self.thread.touch()
            except Exception:
                pass  # Thread might not be saved yet
        
        super().save(*args, **kwargs)

    def mark_as_read(self):
        """Mark the message as read (idempotent)."""
        if not self.is_read:
            self.is_read = True
            self.save(update_fields=['is_read'])

    def soft_delete(self):
        """Soft delete the message."""
        self.is_deleted = True
        self.content = "This message was deleted"
        self.image = None
        self.file = None
        self.file_name = ""
        self.save(update_fields=['is_deleted', 'content', 'image', 'file', 'file_name'])

    def edit(self, new_content):
        """Edit message content."""
        if self.message_type != 'text':
            raise ValueError("Only text messages can be edited")
        
        self.content = new_content
        self.is_edited = True
        self.save(update_fields=['content', 'is_edited', 'updated_at'])

    @property
    def has_attachment(self):
        """Check if message has any attachment."""
        return bool(self.image or self.file)

    @property
    def file_extension(self):
        """Get file extension if file exists."""
        if self.file and self.file_name:
            return os.path.splitext(self.file_name)[1].lower()
        return ''

    @property
    def is_attachment(self):
        """Check if this is primarily an attachment message."""
        return self.message_type in ['image', 'file']

    def get_display_content(self):
        """Get display content based on message type."""
        if self.is_deleted:
            return "This message was deleted"
        
        if self.message_type == 'image':
            return "📷 Image"
        elif self.message_type == 'file':
            return f"📎 {self.file_name}" if self.file_name else "📎 File"
        else:
            return self.content