from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from .models import Thread, Message

@login_required
@require_POST
def send_message(request):
    """Send a new message (handles both text and files)."""
    try:
        thread_id = request.POST.get('thread_id')
        content = request.POST.get('content', '')
        image = request.FILES.get('image')
        file = request.FILES.get('file')
        
        thread = get_object_or_404(Thread, id=thread_id)
        
        # Verify user is a participant
        if not request.user.threads.filter(id=thread_id).exists():
            return JsonResponse({'success': False, 'error': 'Access denied'})
        
        # Create message
        message = Message.objects.create(
            thread=thread,
            sender=request.user,
            content=content
        )
        
        # Handle file uploads
        if image:
            message.image = image
        if file:
            message.file = file
            message.file_name = file.name
        
        message.save()
        
        return JsonResponse({
            'success': True,
            'message_id': message.id,
            'content': message.content,
            'image_url': message.image.url if message.image else None,
            'file_url': message.file.url if message.file else None,
            'file_name': message.file_name
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def inbox_view(request):
    """Display all threads for the current user."""
    try:
        # Use the reverse relation from User to Thread
        threads = request.user.threads.all().order_by('-updated_at')
        
        threads_with_data = []
        for thread in threads:
            # Get last message safely
            last_message = thread.messages.order_by('-created_at').first()
            
            # Get other user safely
            other_user = thread.participants.exclude(id=request.user.id).first()
            
            threads_with_data.append({
                'thread': thread,
                'last_message': last_message,
                'other_user': other_user,
            })
        
        context = {
            'threads': threads_with_data,
            'active_tab': 'messages'
        }
        return render(request, 'messaging/inbox.html', context)
        
    except Exception as e:
        print(f"Error in inbox_view: {e}")
        context = {
            'threads': [],
            'active_tab': 'messages',
            'error': 'Unable to load messages'
        }
        return render(request, 'messaging/inbox.html', context)

@login_required
def thread_view(request, thread_id):
    """Display a specific thread and its messages."""
    thread = get_object_or_404(Thread, id=thread_id)
    
    # Check if user is a participant in this thread using the reverse relation
    if not request.user.threads.filter(id=thread_id).exists():
        return redirect('messaging:inbox')
    
    # Get messages for this thread
    messages = thread.messages.select_related('sender').all()
    
    other_user = thread.participants.exclude(id=request.user.id).first()
    
    context = {
        'thread': thread,
        'messages': messages,
        'other_user': other_user,
        'active_tab': 'messages'
    }
    return render(request, 'messaging/thread.html', context)

@login_required
def start_thread(request, username):
    """Start a new thread with a user."""
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    other_user = get_object_or_404(User, username=username)
    
    if other_user == request.user:
        return redirect('messaging:inbox')
    
    # Get or create thread
    thread = Thread.objects.get_or_create_thread(request.user, other_user)
    
    return redirect('messaging:thread', thread_id=thread.id)

@login_required
def delete_thread(request, thread_id):
    """Delete a thread (soft delete by removing user from participants)."""
    thread = get_object_or_404(Thread, id=thread_id)
    
    if request.user.threads.filter(id=thread_id).exists():
        thread.participants.remove(request.user)
    
    return redirect('messaging:inbox')