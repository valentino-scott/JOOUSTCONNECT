from django.contrib import admin
from .models import Report

@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ('reporter', 'report_type', 'status', 'created_at')
    list_filter = ('report_type', 'status', 'created_at')
    search_fields = ('reporter__username', 'reported_user__username', 'description')
    date_hierarchy = 'created_at'
    
    fieldsets = (
        ('Report Information', {
            'fields': ('reporter', 'reported_user', 'reported_post', 'report_type', 'description')
        }),
        ('Status & Review', {
            'fields': ('status', 'admin_notes')
        }),
    )
    readonly_fields = ('reporter', 'reported_user', 'reported_post', 'created_at')
