from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, Profile, Follow

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Custom User admin"""
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_active_account')
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'is_active_account')
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Account Status', {'fields': ('is_active_account',)}),
    )


@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    """Profile admin"""
    list_display = ('user', 'course', 'department', 'year', 'has_blue_tick', 'created_at')
    list_filter = ('year', 'department', 'created_at')
    search_fields = ('user__username', 'user__email', 'course', 'department')
    readonly_fields = ('created_at', 'updated_at')


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    """Follow relationship admin"""
    list_display = ('follower', 'following', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('follower__username', 'following__username')
    date_hierarchy = 'created_at'
