from django.urls import path
from . import views

app_name = 'accounts'

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/<str:username>/', views.profile_view, name='profile'),
    path('edit-profile/', views.edit_profile_view, name='edit_profile'),
    path('follow/<str:username>/', views.follow_user, name='follow'),
    path('followers/<str:username>/', views.followers_list, name='followers'),
    path('following/<str:username>/', views.following_list, name='following'),
    path('search/', views.search_users, name='search'),
    path('deactivate/', views.deactivate_account, name='deactivate'),
    path('reactivate/', views.reactivate_account, name='reactivate'),
]
