from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from .models import User, Profile, Follow
from .forms import UserRegistrationForm, UserLoginForm, ProfileEditForm

def register_view(request):
    """User registration view"""
    if request.user.is_authenticated:
        return redirect('core:home')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome to JOOUST CONNECT! Your account has been created.')
            return redirect('core:home')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    """User login view"""
    if request.user.is_authenticated:
        return redirect('core:home')
    
    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active_account:
                    login(request, user)
                    messages.success(request, f'Welcome back, {user.username}!')
                    return redirect('core:home')
                else:
                    messages.error(request, 'This account has been deactivated.')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = UserLoginForm()
    
    return render(request, 'accounts/login.html', {'form': form})


@login_required
def logout_view(request):
    """User logout view"""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('accounts:login')


@login_required
def profile_view(request, username):
    """View user profile"""
    user = get_object_or_404(User, username=username)
    profile = user.profile
    
    is_following = False
    if request.user.is_authenticated and request.user != user:
        is_following = Follow.objects.filter(follower=request.user, following=user).exists()
    
    posts = user.posts.all().order_by('-created_at')[:20]
    followers_count = user.followers.count()
    following_count = user.following.count()
    posts_count = user.posts.count()
    
    context = {
        'profile_user': user,
        'profile': profile,
        'is_following': is_following,
        'posts': posts,
        'followers_count': followers_count,
        'following_count': following_count,
        'posts_count': posts_count,
    }
    
    return render(request, 'accounts/profile.html', context)


@login_required
def edit_profile_view(request):
    """Edit user profile"""
    profile = request.user.profile
    
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully!')
            return redirect('accounts:profile', username=request.user.username)
    else:
        form = ProfileEditForm(instance=profile)
    
    return render(request, 'accounts/edit_profile.html', {'form': form})


@login_required
def follow_user(request, username):
    """Follow or unfollow a user"""
    if request.method == 'POST':
        user_to_follow = get_object_or_404(User, username=username)
        
        if user_to_follow == request.user:
            return JsonResponse({'error': 'You cannot follow yourself'}, status=400)
        
        follow_obj, created = Follow.objects.get_or_create(
            follower=request.user,
            following=user_to_follow
        )
        
        if not created:
            follow_obj.delete()
            return JsonResponse({
                'status': 'unfollowed',
                'followers_count': user_to_follow.followers.count()
            })
        else:
            from notifications.models import Notification
            Notification.objects.create(
                recipient=user_to_follow,
                sender=request.user,
                notification_type='follow',
                text=f'{request.user.username} started following you'
            )
            return JsonResponse({
                'status': 'followed',
                'followers_count': user_to_follow.followers.count()
            })
    
    return JsonResponse({'error': 'Invalid request'}, status=400)


@login_required
def followers_list(request, username):
    """List user followers"""
    user = get_object_or_404(User, username=username)
    followers = Follow.objects.filter(following=user).select_related('follower__profile')
    
    return render(request, 'accounts/followers_list.html', {
        'profile_user': user,
        'followers': followers
    })


@login_required
def following_list(request, username):
    """List users being followed"""
    user = get_object_or_404(User, username=username)
    following = Follow.objects.filter(follower=user).select_related('following__profile')
    
    return render(request, 'accounts/following_list.html', {
        'profile_user': user,
        'following': following
    })


@login_required
def search_users(request):
    """Search for users"""
    query = request.GET.get('q', '').strip()
    users = []
    
    if query:
        users = User.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(profile__course__icontains=query) |
            Q(profile__department__icontains=query)
        ).exclude(id=request.user.id).select_related('profile')[:20]
    
    return render(request, 'accounts/search.html', {
        'query': query,
        'users': users
    })


@login_required
def deactivate_account(request):
    """Deactivate user account"""
    if request.method == 'POST':
        request.user.is_active_account = False
        request.user.save()
        logout(request)
        messages.success(request, 'Your account has been deactivated.')
        return redirect('accounts:login')
    
    return render(request, 'accounts/deactivate_confirm.html')


@login_required
def reactivate_account(request):
    """Reactivate user account"""
    if request.method == 'POST':
        request.user.is_active_account = True
        request.user.save()
        messages.success(request, 'Your account has been reactivated!')
        return redirect('core:home')
    
    return render(request, 'accounts/reactivate_confirm.html')
