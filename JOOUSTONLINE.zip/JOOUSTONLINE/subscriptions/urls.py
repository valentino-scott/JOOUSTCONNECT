from django.urls import path
from . import views

app_name = 'subscriptions'

urlpatterns = [
    path('', views.subscriptions_view, name='plans'),
    path('upgrade/', views.upgrade_to_premium, name='upgrade'),
    path('cancel/', views.cancel_subscription, name='cancel'),
]
