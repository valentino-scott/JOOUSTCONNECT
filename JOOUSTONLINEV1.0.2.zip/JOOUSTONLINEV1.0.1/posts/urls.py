from django.urls import path
from . import views

app_name = 'posts'

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_post, name='create'),
    path('<int:post_id>/', views.post_detail, name='detail'),
    path('<int:post_id>/delete/', views.delete_post, name='delete'),
    path('<int:post_id>/like/', views.like_post, name='like'),
    path('<int:post_id>/comment/', views.comment_post, name='comment'),
    path('<int:post_id>/repost/', views.repost_post, name='repost'),
    path('<int:post_id>/quote/', views.quote_post, name='quote'),
    path('quote/<int:quote_id>/delete/', views.delete_quote, name='delete_quote'),
    path('explore/', views.explore_feed, name='explore'),
    path('search/', views.search_view, name='search'),
    
    # Comment URLs for nested comments
    path('comment/<int:comment_id>/like/', views.like_comment, name='like_comment'),
    path('comment/<int:comment_id>/delete/', views.delete_comment, name='delete_comment'),
    path('comment/<int:comment_id>/replies/', views.get_comment_replies, name='get_comment_replies'),
]