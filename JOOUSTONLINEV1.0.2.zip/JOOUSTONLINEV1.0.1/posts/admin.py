from django.contrib import admin
from .models import Post, Like, Comment, Repost, PostView

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    """Post admin"""
    list_display = ('user', 'content_preview', 'created_at', 'like_count', 'comment_count', 'view_count')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'content')
    date_hierarchy = 'created_at'
    
    def content_preview(self, obj):
        return obj.content[:50] + '...' if len(obj.content) > 50 else obj.content
    content_preview.short_description = 'Content'


@admin.register(Like)
class LikeAdmin(admin.ModelAdmin):
    """Like admin"""
    list_display = ('user', 'post', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'post__content')


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    """Comment admin"""
    list_display = ('user', 'post', 'content_preview', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'content', 'post__content')
    
    def content_preview(self, obj):
        return obj.content[:50] + '...' if len(obj.content) > 50 else obj.content
    content_preview.short_description = 'Content'


@admin.register(Repost)
class RepostAdmin(admin.ModelAdmin):
    """Repost admin"""
    list_display = ('user', 'post', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('user__username', 'post__content', 'comment')


@admin.register(PostView)
class PostViewAdmin(admin.ModelAdmin):
    """Post view admin"""
    list_display = ('post', 'user', 'ip_address', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('post__content', 'user__username')
