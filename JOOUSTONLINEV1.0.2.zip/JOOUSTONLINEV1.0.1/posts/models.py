from django.db import models
from django.conf import settings
from django.utils import timezone
from django.urls import reverse
from django.core.exceptions import ValidationError
import os

def validate_image_size(value):
    """Validate image size - max 3MB"""
    max_size = 3 * 1024 * 1024  # 3MB
    if value.size > max_size:
        raise ValidationError(f'Image size cannot exceed 3MB. Your file is {value.size / (1024*1024):.1f}MB.')

def validate_video_size(value):
    """Validate video size - max 10MB"""
    max_size = 10 * 1024 * 1024  # 10MB
    if value.size > max_size:
        raise ValidationError(f'Video size cannot exceed 10MB. Your file is {value.size / (1024*1024):.1f}MB.')

def validate_video_extension(value):
    """Validate video file extensions"""
    ext = os.path.splitext(value.name)[1].lower()
    valid_extensions = ['.mp4', '.mov', '.avi', '.wmv', '.flv', '.webm', '.mkv']
    if ext not in valid_extensions:
        raise ValidationError(f'Unsupported video format. Supported formats: {", ".join(valid_extensions)}')

class Post(models.Model):
    """Post model for text, images, GIFs, and videos"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='posts')
    content = models.TextField(max_length=5000, blank=True)
    image = models.ImageField(
        upload_to='posts/images/', 
        blank=True, 
        null=True,
        validators=[validate_image_size]  # Add image size validation
    )
    video = models.FileField(
        upload_to='posts/videos/', 
        blank=True, 
        null=True,
        validators=[validate_video_size, validate_video_extension]  # Add video validators
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username}: {self.content[:50]}"
    
    def get_absolute_url(self):
        return reverse('posts:post_detail', kwargs={'pk': self.id})
    
    def clean(self):
        """Additional validation at model level"""
        super().clean()
        
        # Ensure both image and video aren't uploaded together
        if self.image and self.video:
            raise ValidationError("Cannot upload both image and video in the same post.")
    
    def save(self, *args, **kwargs):
        """Run full validation on save"""
        self.full_clean()
        super().save(*args, **kwargs)
    
    def like_count(self):
        return self.likes.count()
    
    def comment_count(self):
        return self.comments.count()
    
    def repost_count(self):
        return self.reposts.count()
    
    def quote_count(self):
        """Count how many times this post has been quoted"""
        return self.quoted_by.count()
    
    def view_count(self):
        """Count unique views for this post"""
        return self.views.count()
    
    @property
    def is_repost(self):
        """Check if this post is a repost"""
        return hasattr(self, 'repost')
    
    @property 
    def reposted_by(self):
        """Get the user who reposted this"""
        if hasattr(self, 'repost') and self.repost:
            return self.repost.user
        return None
    
    @property
    def is_quote(self):
        """Check if this post is a quote"""
        return hasattr(self, 'quote')
    
    @property 
    def quoted_post(self):
        """Get the original post that was quoted"""
        if hasattr(self, 'quote'):
            return self.quote.original_post
        return None
    
    @property
    def quote_content(self):
        """Get the quote comment content"""
        if hasattr(self, 'quote'):
            return self.quote.quote_content
        return None

class Like(models.Model):
    """Like model for posts"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='likes')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'post')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} likes {self.post.id}"


class Comment(models.Model):
    """Comment model for posts with support for nested replies"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='comments')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='replies')
    content = models.TextField(max_length=1000)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['created_at']
    
    def __str__(self):
        return f"{self.user.username} on {self.post.id}: {self.content[:30]}"
    
    @property
    def is_reply(self):
        """Check if this comment is a reply to another comment"""
        return self.parent is not None
    
    def like_count(self):
        """Count likes for this comment"""
        return self.comment_likes.count()
    
    def reply_count(self):
        """Count replies to this comment"""
        return self.replies.count()


class CommentLike(models.Model):
    """Like model for comments"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='comment_likes')
    comment = models.ForeignKey(Comment, on_delete=models.CASCADE, related_name='comment_likes')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'comment')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} likes comment {self.comment.id}"


class Repost(models.Model):
    """Repost model (like retweet)"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reposts')
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='reposts')
    comment = models.TextField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('user', 'post')
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} reposted {self.post.id}"


class Quote(models.Model):
    """Quote model - creates a new post with quoted content"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='quotes')
    original_post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='quoted_by')
    quote_content = models.TextField(max_length=280, blank=True)
    # Create a new post for the quote
    quote_post = models.OneToOneField(Post, on_delete=models.CASCADE, related_name='quote', 
                                     null=True, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.user.username} quoted {self.original_post.user.username}"

    def save(self, *args, **kwargs):
        # If this is a new quote and doesn't have a quote_post yet, create one
        if not self.quote_post and not self.pk:
            # Create the post first
            quote_post = Post.objects.create(
                user=self.user,
                content=self.quote_content,
                # You can copy image/video from original_post if needed
                image=self.original_post.image if self.original_post.image else None,
                video=self.original_post.video if self.original_post.video else None,
            )
            self.quote_post = quote_post
        elif self.quote_post and self.quote_content:
            # Update the post content if quote_content changes
            self.quote_post.content = self.quote_content
            self.quote_post.save()
        
        super().save(*args, **kwargs)


class PostView(models.Model):
    """Track unique post views"""
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='post_views', null=True, blank=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='views')
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        unique_together = ('user', 'post')  # Prevent duplicate views from same user
    
    def __str__(self):
        return f"View on {self.post.id}"