from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import get_user_model
from django.http import JsonResponse
from django.db.models import Count, Q
from django.utils import timezone
from django.core.paginator import Paginator
from django.core.exceptions import ValidationError
from datetime import timedelta

from .models import Post, Like, Comment, CommentLike, Repost, PostView, Quote
from .forms import PostForm, CommentForm, QuoteForm

User = get_user_model()


def get_client_ip(request):
    """Get client IP address"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        return x_forwarded_for.split(',')[0]
    return request.META.get('REMOTE_ADDR')


# --------------------------
# HOME FEED
# --------------------------
@login_required
def home(request):
    """Home feed with for you and following tabs"""
    # Get active tab from request
    active_tab = request.GET.get('tab', 'for_you')
    
    if active_tab == 'following':
        following_ids = request.user.following.values_list('id', flat=True)
        posts = Post.objects.filter(
            user_id__in=following_ids
        ).select_related('user__profile').prefetch_related(
            'likes', 'comments', 'reposts', 'views', 'quote'
        ).order_by('-created_at')
    else:
        # For You tab - show all posts
        posts = Post.objects.all().select_related('user__profile').prefetch_related(
            'likes', 'comments', 'reposts', 'views', 'quote'
        ).order_by('-created_at')

    user_liked_ids = list(Like.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_reposted_ids = list(Repost.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_quoted_ids = list(Quote.objects.filter(user=request.user).values_list('original_post_id', flat=True))

    context = {
        'posts': posts,
        'user_liked_ids': user_liked_ids,
        'user_reposted_ids': user_reposted_ids,
        'user_quoted_ids': user_quoted_ids,
        'active_tab': active_tab,
    }

    return render(request, 'core/home.html', context)


# --------------------------
# CREATE POST (UPDATED WITH BETTER ERROR HANDLING)
# --------------------------
@login_required
def create_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                post = form.save(commit=False)
                post.user = request.user
                post.save()
                
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({'success': True, 'post_id': post.id})
                return redirect('posts:home')
                
            except ValidationError as e:
                # Handle model-level validation errors
                if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    return JsonResponse({
                        'success': False, 
                        'errors': {'__all__': [str(e)]}
                    })
                # For non-AJAX, the form will show the error
                form.add_error(None, e)
                
        # Handle form errors
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            errors = {}
            for field, error_list in form.errors.items():
                errors[field] = [str(error) for error in error_list]
            return JsonResponse({
                'success': False, 
                'errors': errors
            })
    else:
        form = PostForm()
    
    return render(request, 'posts/create_post.html', {'form': form})


# --------------------------
# POST DETAIL
# --------------------------
@login_required
def post_detail(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    ip = get_client_ip(request)
    
    # Track view
    if request.user.is_authenticated:
        PostView.objects.get_or_create(user=request.user, post=post, defaults={'ip_address': ip})
    else:
        if not PostView.objects.filter(post=post, ip_address=ip).exists():
            PostView.objects.create(post=post, ip_address=ip)

    # Get comments with pagination
    comments_list = post.comments.filter(parent__isnull=True).select_related(
        'user__profile'
    ).prefetch_related(
        'replies__user__profile',
        'comment_likes',
        'replies__comment_likes'
    ).order_by('-created_at')
    
    # Add pagination for comments
    paginator = Paginator(comments_list, 20)  # 20 comments per page
    page_number = request.GET.get('page')
    comments = paginator.get_page(page_number)

    # Get comment likes for current user
    user_liked_comment_ids = []
    if request.user.is_authenticated:
        user_liked_comment_ids = CommentLike.objects.filter(
            user=request.user,
            comment__post=post
        ).values_list('comment_id', flat=True)

    context = {
        'post': post,
        'comments': comments,
        'user_liked_comment_ids': list(user_liked_comment_ids),
        'is_liked': Like.objects.filter(user=request.user, post=post).exists(),
        'is_reposted': Repost.objects.filter(user=request.user, post=post).exists(),
        'is_quoted': Quote.objects.filter(user=request.user, original_post=post).exists(),
    }

    return render(request, 'posts/post_detail.html', context)


# --------------------------
# DELETE POST
# --------------------------
@login_required
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id, user=request.user)
    if request.method == 'POST':
        post.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({'success': True})
        return redirect('posts:home')
    return JsonResponse({'error': 'Invalid request'}, status=400)


# --------------------------
# LIKE POST
# --------------------------
@login_required
def like_post(request, post_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request'}, status=400)
    
    post = get_object_or_404(Post, id=post_id)
    like, created = Like.objects.get_or_create(user=request.user, post=post)
    
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
        # Create notification if not liking own post
        if post.user != request.user:
            try:
                from notifications.models import Notification
                Notification.objects.create(
                    recipient=post.user,
                    sender=request.user,
                    notification_type='like',
                    post=post,
                    text=f'{request.user.username} liked your post',
                )
            except ImportError:
                pass
    
    return JsonResponse({
        'liked': liked, 
        'like_count': post.like_count(), 
        'success': True
    })


# --------------------------
# COMMENT POST
# --------------------------
@login_required
def comment_post(request, post_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request'}, status=400)
    
    post = get_object_or_404(Post, id=post_id)
    parent_comment_id = request.GET.get('parent_id') or request.POST.get('parent_comment_id')
    parent_comment = None
    
    # Check if this is a reply to another comment
    if parent_comment_id:
        try:
            parent_comment = Comment.objects.get(id=parent_comment_id, post=post)
        except Comment.DoesNotExist:
            return JsonResponse({'success': False, 'error': 'Parent comment not found'}, status=400)
    
    content = request.POST.get('content', '').strip()
    if not content:
        return JsonResponse({'success': False, 'error': 'Comment content is required'}, status=400)
    
    # Validate content length
    if len(content) > 280:
        return JsonResponse({'success': False, 'error': 'Comment must be 280 characters or less'}, status=400)
    
    # Create the comment
    comment = Comment.objects.create(
        user=request.user,
        post=post,
        parent=parent_comment,
        content=content
    )
    
    # Create notification if not commenting on own post and not replying to own comment
    if post.user != request.user and (not parent_comment or parent_comment.user != request.user):
        try:
            from notifications.models import Notification
            notification_text = f'{request.user.username} commented on your post'
            if parent_comment:
                notification_text = f'{request.user.username} replied to your comment'
                
            Notification.objects.create(
                recipient=post.user if not parent_comment else parent_comment.user,
                sender=request.user,
                notification_type='comment',
                post=post,
                text=notification_text,
            )
        except ImportError:
            pass
    
    # Prepare response data
    response_data = {
        'success': True,
        'status': 'success',
        'comment': {
            'id': comment.id,
            'user': comment.user.username,
            'user_display_name': comment.user.get_full_name() or comment.user.username,
            'content': comment.content,
            'created_at': comment.created_at.strftime('%b %d, %Y %I:%M %p'),
            'is_reply': comment.is_reply,
            'parent_id': comment.parent_id,
        },
        'comments_count': post.comment_count(),
    }
    
    # For AJAX requests, just return JSON data - the frontend will handle the refresh
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse(response_data)
    
    return JsonResponse(response_data)


# --------------------------
# LIKE COMMENT
# --------------------------
@login_required
def like_comment(request, comment_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request'}, status=400)
    
    comment = get_object_or_404(Comment, id=comment_id)
    like, created = CommentLike.objects.get_or_create(user=request.user, comment=comment)
    
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
        # Create notification if not liking own comment
        if comment.user != request.user:
            try:
                from notifications.models import Notification
                Notification.objects.create(
                    recipient=comment.user,
                    sender=request.user,
                    notification_type='like',
                    post=comment.post,
                    text=f'{request.user.username} liked your comment',
                )
            except ImportError:
                pass
    
    return JsonResponse({
        'liked': liked, 
        'like_count': comment.like_count(), 
        'success': True
    })


# --------------------------
# DELETE COMMENT
# --------------------------
@login_required
def delete_comment(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    
    # Check if user owns the comment or the post
    if comment.user != request.user and comment.post.user != request.user:
        return JsonResponse({'error': 'Permission denied'}, status=403)
    
    if request.method == 'POST':
        comment.delete()
        return JsonResponse({'success': True})
    
    return JsonResponse({'error': 'Invalid request'}, status=400)


# --------------------------
# REPOST
# --------------------------
@login_required
def repost_post(request, post_id):
    if request.method != 'POST':
        return JsonResponse({'error': 'Invalid request'}, status=400)
    
    post = get_object_or_404(Post, id=post_id)
    repost, created = Repost.objects.get_or_create(user=request.user, post=post)
    
    if not created:
        repost.delete()
        reposted = False
    else:
        reposted = True
        # Create notification if not reposting own post
        if post.user != request.user:
            try:
                from notifications.models import Notification
                Notification.objects.create(
                    recipient=post.user,
                    sender=request.user,
                    notification_type='repost',
                    post=post,
                    text=f'{request.user.username} reposted your post',
                )
            except ImportError:
                pass
    
    return JsonResponse({
        'reposted': reposted, 
        'repost_count': post.repost_count(), 
        'success': True
    })


# --------------------------
# QUOTE POST
# --------------------------
@login_required
def quote_post(request, post_id):
    original_post = get_object_or_404(Post, id=post_id)
    
    if request.method == 'POST':
        form = QuoteForm(request.POST)
        if form.is_valid():
            quote = form.save(commit=False)
            quote.user = request.user
            quote.original_post = original_post
            quote.save()
            
            # Create notification if not quoting own post
            if original_post.user != request.user:
                try:
                    from notifications.models import Notification
                    Notification.objects.create(
                        recipient=original_post.user,
                        sender=request.user,
                        notification_type='quote',
                        post=original_post,
                        text=f'{request.user.username} quoted your post',
                    )
                except ImportError:
                    pass
            
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': True, 
                    'quote_id': quote.id, 
                    'quote_count': original_post.quote_count()
                })
            return redirect('posts:home')
        else:
            # Return form errors for AJAX requests
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({
                    'success': False, 
                    'errors': form.errors
                })
    
    else:
        form = QuoteForm()
    
    template = 'posts/quote_modal.html' if request.headers.get('X-Requested-With') == 'XMLHttpRequest' else 'posts/quote_post.html'
    return render(request, template, {'form': form, 'post': original_post})


# --------------------------
# DELETE QUOTE
# --------------------------
@login_required
def delete_quote(request, quote_id):
    quote = get_object_or_404(Quote, id=quote_id, user=request.user)
    
    if request.method == 'POST':
        quote.delete()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True, 
                'quote_count': quote.original_post.quote_count()
            })
        return redirect('posts:home')
    
    return JsonResponse({'error': 'Invalid request'}, status=400)


# --------------------------
# EXPLORE FEED
# --------------------------
@login_required
def explore_feed(request):
    time_threshold = timezone.now() - timedelta(days=7)
    
    trending_posts = Post.objects.filter(created_at__gte=time_threshold).annotate(
        like_count=Count('likes'),
        comment_count=Count('comments'),
        repost_count=Count('reposts'),
        quote_count=Count('quoted_by'),
    ).annotate(
        engagement_score=Count('likes') + Count('comments')*2 + Count('reposts')*3 + Count('quoted_by')*3
    ).order_by('-engagement_score', '-created_at')[:50]

    user_liked_ids = list(Like.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_reposted_ids = list(Repost.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_quoted_ids = list(Quote.objects.filter(user=request.user).values_list('original_post_id', flat=True))

    return render(request, 'posts/explore.html', {
        'posts': trending_posts,
        'user_liked_ids': user_liked_ids,
        'user_reposted_ids': user_reposted_ids,
        'user_quoted_ids': user_quoted_ids,
        'title': 'Explore Trending Posts',
    })


# --------------------------
# SEARCH
# --------------------------
@login_required
def search_view(request):
    query = request.GET.get('q', '').strip()
    results = {'posts': [], 'users': [], 'query': query}
    
    if query:
        results['posts'] = Post.objects.filter(content__icontains=query).select_related('user__profile').prefetch_related(
            'likes', 'comments', 'reposts', 'quote'
        ).order_by('-created_at')[:20]

        results['users'] = User.objects.filter(
            Q(username__icontains=query) | 
            Q(first_name__icontains=query) | 
            Q(last_name__icontains=query)
        ).exclude(id=request.user.id).select_related('profile')[:20]

        results['user_liked_ids'] = list(
            Like.objects.filter(user=request.user, post__in=results['posts']).values_list('post_id', flat=True)
        )
        results['user_reposted_ids'] = list(
            Repost.objects.filter(user=request.user, post__in=results['posts']).values_list('post_id', flat=True)
        )
        results['user_quoted_ids'] = list(
            Quote.objects.filter(user=request.user, original_post__in=results['posts']).values_list('original_post_id', flat=True)
        )

    return render(request, 'posts/search.html', results)


# --------------------------
# GET COMMENT REPLIES (AJAX)
# --------------------------
@login_required
def get_comment_replies(request, comment_id):
    """Get replies for a comment via AJAX"""
    comment = get_object_or_404(Comment, id=comment_id)
    replies = comment.replies.select_related('user__profile').prefetch_related('comment_likes').order_by('created_at')
    
    # Get comment likes for current user
    user_liked_comment_ids = []
    if request.user.is_authenticated:
        user_liked_comment_ids = CommentLike.objects.filter(
            user=request.user,
            comment__in=replies
        ).values_list('comment_id', flat=True)
    
    replies_data = []
    for reply in replies:
        replies_data.append({
            'id': reply.id,
            'user': {
                'username': reply.user.username,
                'display_name': reply.user.get_full_name() or reply.user.username,
                'profile_photo': reply.user.profile.photo.url if reply.user.profile.photo else None,
                'has_blue_tick': reply.user.profile.has_blue_tick,
            },
            'content': reply.content,
            'created_at': reply.created_at.strftime('%b %d, %Y %I:%M %p'),
            'like_count': reply.like_count(),
            'is_liked': reply.id in user_liked_comment_ids,
            'is_reply': True,
        })
    
    return JsonResponse({
        'success': True,
        'replies': replies_data,
        'reply_count': comment.reply_count(),
    })


# --------------------------
# GET COMMENTS WITH PAGINATION (AJAX)
# --------------------------
@login_required
def get_comments(request, post_id):
    """Get paginated comments via AJAX"""
    post = get_object_or_404(Post, id=post_id)
    page_number = request.GET.get('page', 1)
    
    comments_list = post.comments.filter(parent__isnull=True).select_related(
        'user__profile'
    ).prefetch_related(
        'replies__user__profile',
        'comment_likes',
        'replies__comment_likes'
    ).order_by('-created_at')
    
    paginator = Paginator(comments_list, 20)
    comments = paginator.get_page(page_number)
    
    # Get comment likes for current user
    user_liked_comment_ids = []
    if request.user.is_authenticated:
        user_liked_comment_ids = CommentLike.objects.filter(
            user=request.user,
            comment__post=post
        ).values_list('comment_id', flat=True)
    
    # For now, just return basic data without HTML rendering
    # You can implement HTML rendering later if needed
    comments_data = []
    for comment in comments:
        comment_data = {
            'id': comment.id,
            'user': {
                'username': comment.user.username,
                'display_name': comment.user.get_full_name() or comment.user.username,
                'profile_photo': comment.user.profile.photo.url if comment.user.profile.photo else None,
                'has_blue_tick': comment.user.profile.has_blue_tick,
            },
            'content': comment.content,
            'created_at': comment.created_at.strftime('%b %d, %Y %I:%M %p'),
            'like_count': comment.like_count(),
            'is_liked': comment.id in user_liked_comment_ids,
            'reply_count': comment.reply_count(),
            'replies': []
        }
        
        # Add replies data
        for reply in comment.replies.all():
            reply_data = {
                'id': reply.id,
                'user': {
                    'username': reply.user.username,
                    'display_name': reply.user.get_full_name() or reply.user.username,
                    'profile_photo': reply.user.profile.photo.url if reply.user.profile.photo else None,
                    'has_blue_tick': reply.user.profile.has_blue_tick,
                },
                'content': reply.content,
                'created_at': reply.created_at.strftime('%b %d, %Y %I:%M %p'),
                'like_count': reply.like_count(),
                'is_liked': reply.id in user_liked_comment_ids,
                'is_reply': True,
            }
            comment_data['replies'].append(reply_data)
        
        comments_data.append(comment_data)
    
    return JsonResponse({
        'success': True,
        'comments': comments_data,
        'has_next': comments.has_next(),
        'next_page': comments.next_page_number() if comments.has_next() else None
    })


# --------------------------
# SORT COMMENTS (AJAX)
# --------------------------
@login_required
def sort_comments(request, post_id):
    """Sort comments via AJAX"""
    post = get_object_or_404(Post, id=post_id)
    sort_by = request.GET.get('sort', 'newest')
    
    comments_list = post.comments.filter(parent__isnull=True).select_related(
        'user__profile'
    ).prefetch_related(
        'replies__user__profile',
        'comment_likes',
        'replies__comment_likes'
    )
    
    # Apply sorting
    if sort_by == 'oldest':
        comments_list = comments_list.order_by('created_at')
    elif sort_by == 'popular':
        comments_list = comments_list.annotate(
            like_count=Count('comment_likes')
        ).order_by('-like_count', '-created_at')
    else:  # newest (default)
        comments_list = comments_list.order_by('-created_at')
    
    paginator = Paginator(comments_list, 20)
    page_number = request.GET.get('page', 1)
    comments = paginator.get_page(page_number)
    
    # Get comment likes for current user
    user_liked_comment_ids = []
    if request.user.is_authenticated:
        user_liked_comment_ids = CommentLike.objects.filter(
            user=request.user,
            comment__post=post
        ).values_list('comment_id', flat=True)
    
    # Return JSON data instead of HTML
    comments_data = []
    for comment in comments:
        comment_data = {
            'id': comment.id,
            'user': {
                'username': comment.user.username,
                'display_name': comment.user.get_full_name() or comment.user.username,
                'profile_photo': comment.user.profile.photo.url if comment.user.profile.photo else None,
                'has_blue_tick': comment.user.profile.has_blue_tick,
            },
            'content': comment.content,
            'created_at': comment.created_at.strftime('%b %d, %Y %I:%M %p'),
            'like_count': comment.like_count(),
            'is_liked': comment.id in user_liked_comment_ids,
            'reply_count': comment.reply_count(),
            'replies': []
        }
        
        # Add replies data
        for reply in comment.replies.all():
            reply_data = {
                'id': reply.id,
                'user': {
                    'username': reply.user.username,
                    'display_name': reply.user.get_full_name() or reply.user.username,
                    'profile_photo': reply.user.profile.photo.url if reply.user.profile.photo else None,
                    'has_blue_tick': reply.user.profile.has_blue_tick,
                },
                'content': reply.content,
                'created_at': reply.created_at.strftime('%b %d, %Y %I:%M %p'),
                'like_count': reply.like_count(),
                'is_liked': reply.id in user_liked_comment_ids,
                'is_reply': True,
            }
            comment_data['replies'].append(reply_data)
        
        comments_data.append(comment_data)
    
    return JsonResponse({
        'success': True,
        'comments': comments_data,
        'has_next': comments.has_next(),
        'next_page': comments.next_page_number() if comments.has_next() else None,
        'sort_by': sort_by
    })