from django import forms
from .models import Post, Comment, Quote

class PostForm(forms.ModelForm):
    content = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': "What's happening?",
            'rows': 3,
            'maxlength': '5000'
        }),
        required=False,
        max_length=5000
    )
    
    image = forms.ImageField(
        required=False,
        widget=forms.FileInput(attrs={
            'accept': 'image/*'
        })
    )
    
    video = forms.FileField(
        required=False,
        widget=forms.FileInput(attrs={
            'accept': 'video/*'
        }),
        help_text="Maximum video size: 10MB. Supported formats: MP4, MOV, AVI, WMV, FLV, WebM, MKV"
    )

    class Meta:
        model = Post
        fields = ['content', 'image', 'video']
    
    def clean(self):
        cleaned_data = super().clean()
        content = cleaned_data.get('content', '').strip()
        image = cleaned_data.get('image')
        video = cleaned_data.get('video')
        
        # Require at least one field to be filled
        if not content and not image and not video:
            raise forms.ValidationError("Please provide content, an image, or a video.")
        
        # Validate that both image and video aren't uploaded
        if image and video:
            raise forms.ValidationError("Cannot upload both image and video in the same post.")
        
        return cleaned_data

class CommentForm(forms.ModelForm):
    content = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': 'Write a comment...',
            'rows': 2,
            'maxlength': '1000'
        }),
        max_length=1000
    )

    class Meta:
        model = Comment
        fields = ['content']

class QuoteForm(forms.ModelForm):
    quote_content = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': 'Add a comment...',
            'rows': 3,
            'maxlength': '280'
        }),
        max_length=280,
        required=True
    )

    class Meta:
        model = Quote
        fields = ['quote_content']