from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from posts.models import Post
from accounts.models import User
from .models import Report

@login_required
def report_post(request, post_id):
    """Report a post"""
    post = get_object_or_404(Post, id=post_id)
    
    if request.method == 'POST':
        report_type = request.POST.get('report_type')
        description = request.POST.get('description', '')
        
        Report.objects.create(
            reporter=request.user,
            reported_post=post,
            reported_user=post.user,
            report_type=report_type,
            description=description
        )
        
        messages.success(request, 'Report submitted successfully. Our team will review it.')
        return redirect('posts:detail', post_id=post.id)
    
    return render(request, 'reports/report_post.html', {'post': post})


@login_required
def report_user(request, username):
    """Report a user"""
    user = get_object_or_404(User, username=username)
    
    if request.method == 'POST':
        report_type = request.POST.get('report_type')
        description = request.POST.get('description', '')
        
        Report.objects.create(
            reporter=request.user,
            reported_user=user,
            report_type=report_type,
            description=description
        )
        
        messages.success(request, 'Report submitted successfully. Our team will review it.')
        return redirect('accounts:profile', username=user.username)
    
    return render(request, 'reports/report_user.html', {'reported_user': user})
