from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    path('post/<int:post_id>/', views.report_post, name='report_post'),
    path('user/<str:username>/', views.report_user, name='report_user'),
]
