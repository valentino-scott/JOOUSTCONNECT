from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from posts.models import Post, Like, Repost, Quote
from accounts.models import Follow, User
import datetime
from django.utils import timezone
from django.db.models import Count, Q

@login_required
def home_view(request):
    """Home feed with posts from followed users"""
    # Get posts from followed users and current user
    following_users = Follow.objects.filter(follower=request.user).values_list('following_id', flat=True)
    
    posts = Post.objects.filter(user__in=following_users) | Post.objects.filter(user=request.user)
    posts = posts.distinct().order_by('-created_at')[:50]
    
    # Get user engagement data
    user_liked_ids = list(Like.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_reposted_ids = list(Repost.objects.filter(user=request.user).values_list('post_id', flat=True))
    user_quoted_ids = list(Quote.objects.filter(user=request.user).values_list('original_post_id', flat=True))
    
    # Get trending topics (hashtags from last 7 days)
    one_week_ago = timezone.now() - datetime.timedelta(days=7)
    
    # Simple trending logic - analyze recent posts for hashtags
    recent_posts = Post.objects.filter(
        created_at__gte=one_week_ago
    ).exclude(
        Q(content__isnull=True) | Q(content__exact='')
    ).order_by('-created_at')[:100]  # Get recent posts for analysis
    
    hashtag_counts = {}
    for post in recent_posts:
        if '#' in post.content:
            words = post.content.split()
            for word in words:
                if word.startswith('#') and len(word) > 1:
                    hashtag = word.lower()
                    hashtag_counts[hashtag] = hashtag_counts.get(hashtag, 0) + 1
    
    # Convert to trending topics format
    trending_topics = []
    for hashtag, count in sorted(hashtag_counts.items(), key=lambda x: x[1], reverse=True)[:3]:
        # Determine category based on hashtag content
        category = "Trending at JOOUST"
        if any(term in hashtag for term in ['exam', 'study', 'class', 'lecture']):
            category = "Academic · Trending"
        elif any(term in hashtag for term in ['event', 'party', 'sport', 'game']):
            category = "Campus Life"
        elif any(term in hashtag for term in ['kenya', 'nairobi', 'kisumu']):
            category = "Trending in Kenya"
        
        trending_topics.append({
            'hashtag': hashtag,
            'post_count': count,
            'category': category
        })
    
    # Fallback trending topics if none found
    if not trending_topics:
        trending_topics = [
            {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
            {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
            {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
        ]
    
    # Get suggested users (users not followed by current user)
    try:
        # Get IDs of users that the current user is following
        following_ids = list(Follow.objects.filter(follower=request.user).values_list('following_id', flat=True))
        following_ids.append(request.user.id)  # Exclude self
        
        # Get random users not followed by current user
        suggested_users = User.objects.exclude(
            id__in=following_ids
        ).exclude(
            is_active=False
        ).order_by('?')[:2]  # Random 2 users
        
    except Exception as e:
        # Fallback if there's any error with user suggestions
        suggested_users = User.objects.filter(
            is_active=True
        ).exclude(
            id=request.user.id
        ).order_by('?')[:2]
    
    # Get profile data for the template
    try:
        profile = request.user.profile
    except:
        profile = None
    
    # Get follow counts
    following_count = request.user.following.count()
    followers_count = request.user.followers.count()
    
    context = {
        'posts': posts,
        'title': 'Home',
        'trending_topics': trending_topics,
        'suggested_users': suggested_users,
        'user_liked_ids': user_liked_ids,
        'user_reposted_ids': user_reposted_ids,
        'user_quoted_ids': user_quoted_ids,
        'profile_user': request.user,  # This is crucial for the template
        'profile': profile,
        'following_count': following_count,
        'followers_count': followers_count,
        'is_following': False,
    }
    
    return render(request, 'core/home.html', context)


def landing_page(request):
    """Landing page for non-authenticated users"""
    if request.user.is_authenticated:
        return home_view(request)
    
    # Provide some default data for landing page if needed
    context = {
        'trending_topics': [
            {'hashtag': '#JOOUSTConnect', 'post_count': 2345, 'category': 'Trending in Kenya'},
            {'hashtag': '#ExamsWeek', 'post_count': 1847, 'category': 'Academic · Trending'},
            {'hashtag': '#JOOUSTEvents', 'post_count': 932, 'category': 'Campus Life'},
        ],
        'suggested_users': User.objects.filter(is_active=True).order_by('?')[:2],
    }
    
    return render(request, 'core/landing.html', context)

# core/views.py
from django.views.generic import TemplateView

class TermsOfServiceView(TemplateView):
    template_name = 'core/terms_of_service.html'

class PrivacyPolicyView(TemplateView):
    template_name = 'core/privacy_policy.html'

class CookiePolicyView(TemplateView):
    template_name = 'core/cookie_policy.html'

class AccessibilityView(TemplateView):
    template_name = 'core/accessibility.html'

class AdsInfoView(TemplateView):
    template_name = 'core/ads_info.html'

class MoreView(TemplateView):
    template_name = 'core/more.html'

# Add this at the bottom of your views.py, after the other class-based views
class AboutView(TemplateView):
    template_name = 'core/about.html'

class HelpCenterView(TemplateView):
    template_name = 'core/help_center_standalone.html'  # Changed template name
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Main help categories like X
        context['help_categories'] = [
            {
                'title': 'Getting Started',
                'icon': 'rocket',
                'color': '#1DA1F2',
                'description': 'Learn the basics and set up your account',
                'topics': [
                    {'title': 'Creating an account', 'url': '#', 'popular': True},
                    {'title': 'Setting up your profile', 'url': '#'},
                    {'title': 'Finding people to follow', 'url': '#'},
                    {'title': 'Posting your first message', 'url': '#'},
                ]
            },
            {
                'title': 'Managing Your Account',
                'icon': 'user-cog',
                'color': '#00BA7C',
                'description': 'Security, privacy, and account settings',
                'topics': [
                    {'title': 'Reset your password', 'url': '#', 'popular': True},
                    {'title': 'Update email address', 'url': '#'},
                    {'title': 'Privacy and safety', 'url': '#'},
                    {'title': 'Deactivate account', 'url': '#'},
                ]
            },
            {
                'title': 'Troubleshooting',
                'icon': 'tools',
                'color': '#F91880',
                'description': 'Fix login issues and technical problems',
                'topics': [
                    {'title': 'Login issues', 'url': '#', 'popular': True},
                    {'title': 'App not working', 'url': '#'},
                    {'title': 'Notifications problems', 'url': '#'},
                    {'title': 'Performance issues', 'url': '#'},
                ]
            },
            {
                'title': 'Safety & Reporting',
                'icon': 'shield-alt',
                'color': '#FFAD00',
                'description': 'Report issues and stay safe',
                'topics': [
                    {'title': 'Report abusive behavior', 'url': '#', 'popular': True},
                    {'title': 'Block and mute accounts', 'url': '#'},
                    {'title': 'Community guidelines', 'url': '#'},
                    {'title': 'Privacy controls', 'url': '#'},
                ]
            },
            {
                'title': 'Features & How-Tos',
                'icon': 'book-open',
                'color': '#794BC4',
                'description': 'Master JOOUST Connect features',
                'topics': [
                    {'title': 'Study groups', 'url': '#', 'popular': True},
                    {'title': 'Direct messaging', 'url': '#'},
                    {'title': 'File sharing', 'url': '#'},
                    {'title': 'Event creation', 'url': '#'},
                ]
            },
            {
                'title': 'Policies & Guidelines',
                'icon': 'file-alt',
                'color': '#17BF63',
                'description': 'Terms of service and community rules',
                'topics': [
                    {'title': 'Terms of service', 'url': '{% url "core:terms_of_service" %}'},
                    {'title': 'Privacy policy', 'url': '{% url "core:privacy_policy" %}'},
                    {'title': 'Cookie policy', 'url': '{% url "core:cookie_policy" %}'},
                    {'title': 'Community guidelines', 'url': '#'},
                ]
            }
        ]
        
        # Popular help topics
        context['popular_topics'] = [
            {'title': 'How to reset your password', 'category': 'Account', 'url': '#', 'views': '2.4k'},
            {'title': 'Reporting inappropriate content', 'category': 'Safety', 'url': '#', 'views': '1.8k'},
            {'title': 'Creating study groups', 'category': 'Features', 'url': '#', 'views': '1.5k'},
            {'title': 'Managing notification settings', 'category': 'Account', 'url': '#', 'views': '1.2k'},
            {'title': 'Troubleshooting login issues', 'category': 'Troubleshooting', 'url': '#', 'views': '980'},
        ]
        
        # Support contact information
        context['support_contacts'] = {
            'email': 'support@jooustconnect.ac.ke',
            'phone': '+254794477726',
            'agents': [
                {'name': 'Valentino Achira', 'email': 'valentinoachira@gmail.com', 'role': 'Senior Support'},
                {'name': 'Moses Keraso', 'email': 'moseskeraso@gmail.com', 'role': 'Support Specialist'},
            ],
            'response_time': 'Typically within 2 hours',
            'availability': 'Monday - Friday, 8:00 AM - 6:00 PM EAT'
        }
        
        return context
    # Add this at the very bottom of your views.py file, outside all other classes

class HelpSearchView(TemplateView):
    template_name = 'core/help_search.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        query = self.request.GET.get('q', '')
        context['search_query'] = query
        context['search_results'] = self.get_search_results(query)
        return context
    
    def get_search_results(self, query):
        # Simplified search - replace with real search logic
        if not query:
            return []
        
        # Mock search results
        mock_results = [
            {
                'title': 'How to reset your password',
                'category': 'Account Management',
                'url': '#',
                'snippet': f'Learn how to reset your password when you forget it.',
                'relevance': 95
            },
            {
                'title': 'Creating study groups',
                'category': 'Features', 
                'url': '#',
                'snippet': f'Step-by-step guide to create study groups.',
                'relevance': 87
            }
        ]
        
        return mock_results
# ========== ERROR HANDLERS ==========
# Add these at the VERY BOTTOM of your views.py file

def custom_404(request, exception):
    """
    Custom 404 error handler
    """
    return render(request, '404.html', status=404)

def custom_500(request):
    """
    Custom 500 error handler
    """
    return render(request, '500.html', status=500)