from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    path('', views.landing_page, name='landing'),
    path('home/', views.home_view, name='home'),

    # Footer URLs - Class-based views (use the ones you added at the bottom)
    path('terms/', views.TermsOfServiceView.as_view(), name='terms_of_service'),
    path('privacy/', views.PrivacyPolicyView.as_view(), name='privacy_policy'),
    path('cookies/', views.CookiePolicyView.as_view(), name='cookie_policy'),
    path('accessibility/', views.AccessibilityView.as_view(), name='accessibility'),
    path('ads-info/', views.AdsInfoView.as_view(), name='ads_info'),
    path('more/', views.MoreView.as_view(), name='more'),
    path('about/', views.AboutView.as_view(), name='about'),  # Add this missing line
    path('help/', views.HelpCenterView.as_view(), name='help_center'),
    path('help/search/', views.HelpSearchView.as_view(), name='help_search'),
]