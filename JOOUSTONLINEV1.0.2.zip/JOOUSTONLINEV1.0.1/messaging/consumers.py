import json
from channels.generic.websocket import AsyncWebsocketConsumer
from django.contrib.auth.models import AnonymousUser
from asgiref.sync import sync_to_async
from .models import Thread, Message
from django.contrib.auth import get_user_model

User = get_user_model()

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.thread_id = self.scope['url_route']['kwargs']['thread_id']
        self.room_group_name = f'chat_{self.thread_id}'
        self.user = self.scope["user"]

        print(f"🔗 Connection attempt: user={self.user.username}, thread={self.thread_id}")

        # Verify user has access to this thread
        has_access = await self.verify_access()
        print(f"🔐 Access verification: user={self.user.id}, thread={self.thread_id}, access={has_access}")

        if has_access:
            # Join room group
            await self.channel_layer.group_add(
                self.room_group_name,
                self.channel_name
            )
            await self.accept()
            print(f"✅ WebSocket connected successfully")

            # Send online status to other users
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'user_status_message',
                    'user_id': self.user.id,
                    'username': self.user.username,
                    'is_online': True
                }
            )
        else:
            await self.close()

    async def disconnect(self, close_code):
        print(f"🔌 WebSocket disconnected, code: {close_code}")
        
        # Send offline status to other users
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'user_status_message',
                    'user_id': self.user.id,
                    'username': self.user.username,
                    'is_online': False
                }
            )
            
            # Leave room group
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name
            )

    async def receive(self, text_data):
        try:
            text_data_json = json.loads(text_data)
            message_type = text_data_json.get('type')
            
            print(f"📨 Received message type: {message_type}, data: {text_data_json}")

            if message_type == 'message':
                await self.handle_chat_message(text_data_json)
            elif message_type == 'typing':
                await self.handle_typing_indicator(text_data_json)
            elif message_type == 'user_status':
                await self.handle_user_status(text_data_json)
            elif message_type == 'file_message':
                await self.handle_file_message(text_data_json)
            elif message_type == 'message_deleted':
                await self.handle_message_deletion(text_data_json)
            else:
                print(f"❓ Unknown message type: {message_type}")
                
        except Exception as e:
            print(f"❌ Error in receive: {e}")
            await self.send(text_data=json.dumps({
                'type': 'error',
                'message': str(e)
            }))

    async def handle_chat_message(self, data):
        """Handle text message"""
        message_content = data.get('message', '')
        thread_id = data.get('thread_id')
        
        print(f"💬 Handling chat message from {self.user.username}: '{message_content}'")
        
        # Save message to database
        message = await self.save_message_to_db(thread_id, message_content)
        
        if message:
            print(f"✅ Message saved to database: {message.id}")
            
            # ✅ FIX: CREATE NOTIFICATIONS FOR OTHER USERS
            await self.create_message_notifications(thread_id, message_content, message.id)
            
            # Send message to room group
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'chat_message',
                    'message': message_content,
                    'sender': self.user.username,
                    'sender_id': self.user.id,
                    'message_id': message.id,
                    'timestamp': message.created_at.isoformat()
                }
            )

    async def handle_file_message(self, data):
        """Handle file message for instant display"""
        print(f"📁 Handling file message from {self.user.username}")
        
        # ✅ FIX: CREATE NOTIFICATIONS FOR FILE MESSAGES TOO
        thread_id = data.get('thread_id')
        message_content = data.get('message', '')
        
        if thread_id:
            await self.create_message_notifications(thread_id, message_content or "sent a file")
        
        # Broadcast file message to all users in room for instant display
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'file_message',
                'message': data.get('message', ''),
                'image_url': data.get('image_url'),
                'file_url': data.get('file_url'),
                'file_name': data.get('file_name'),
                'sender': self.user.username,
                'sender_id': self.user.id
            }
        )

    async def handle_typing_indicator(self, data):
        """Handle typing indicators"""
        is_typing = data.get('is_typing', False)
        user_id = data.get('user_id')
        
        print(f"⌨️ Typing indicator from {self.user.username}: {is_typing}")
        
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'typing_indicator',
                'is_typing': is_typing,
                'user_id': user_id,
                'username': self.user.username
            }
        )

    async def handle_user_status(self, data):
        """Handle user status updates"""
        is_online = data.get('is_online', False)
        user_id = data.get('user_id')
        
        print(f"👤 User status from {self.user.username}: {is_online}")
        
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_status_message',
                'is_online': is_online,
                'user_id': user_id,
                'username': self.user.username
            }
        )

    async def handle_message_deletion(self, data):
        """Handle message deletion requests"""
        message_id = data.get('message_id')
        thread_id = data.get('thread_id')
        
        print(f"🗑️ Handling message deletion from {self.user.username}: message_id={message_id}")
        
        # Verify the user owns this message
        can_delete = await self.verify_message_ownership(message_id)
        
        if can_delete:
            # Broadcast deletion to all users in the thread
            await self.channel_layer.group_send(
                self.room_group_name,
                {
                    'type': 'message_deleted',
                    'message_id': message_id,
                    'deleted_by': self.user.username,
                    'deleted_by_id': self.user.id
                }
            )
            print(f"✅ Message deletion broadcasted: {message_id}")
        else:
            print(f"❌ User {self.user.username} cannot delete message {message_id}")

    # ✅ NEW: Create notifications for message recipients
    @sync_to_async
    def create_message_notifications(self, thread_id, message_content, message_id=None):
        """Create notifications for all other users in the thread"""
        try:
            from notifications.utils import create_notification
            from django.urls import reverse
            
            thread = Thread.objects.get(id=thread_id)
            other_users = thread.participants.exclude(id=self.user.id)
            
            notification_count = 0
            for other_user in other_users:
                # Create notification text
                if message_content:
                    if len(message_content) > 50:
                        notification_text = f"{self.user.username}: {message_content[:50]}..."
                    else:
                        notification_text = f"{self.user.username}: {message_content}"
                else:
                    notification_text = f"{self.user.username} sent you a message"
                
                # Create the notification
                notification = create_notification(
                    recipient=other_user,
                    notification_type='message',
                    title='New Message',
                    text=notification_text,
                    sender=self.user,
                    target_url=reverse('messaging:thread', kwargs={'thread_id': thread_id})
                )
                
                if notification:
                    notification_count += 1
                    print(f"✅ Created message notification for {other_user.username}")
                else:
                    print(f"❌ Failed to create notification for {other_user.username}")
            
            print(f"📢 Created {notification_count} notifications for thread {thread_id}")
            return notification_count
            
        except Exception as e:
            print(f"❌ Error creating message notifications: {e}")
            return 0

    # Handler methods for different message types
    async def chat_message(self, event):
        """Send chat message to WebSocket"""
        print(f"📢 Broadcasting message to client: {event}")
        await self.send(text_data=json.dumps({
            'type': 'message',
            'message': event['message'],
            'sender': event['sender'],
            'sender_id': event['sender_id'],
            'message_id': event.get('message_id'),
            'timestamp': event.get('timestamp')
        }))

    async def file_message(self, event):
        """Send file message to WebSocket"""
        print(f"📁 Broadcasting file message to client: {event}")
        await self.send(text_data=json.dumps({
            'type': 'file_message',
            'message': event['message'],
            'image_url': event.get('image_url'),
            'file_url': event.get('file_url'),
            'file_name': event.get('file_name'),
            'sender': event['sender'],
            'sender_id': event['sender_id']
        }))

    async def typing_indicator(self, event):
        """Send typing indicator to WebSocket"""
        print(f"⌨️ Broadcasting typing indicator: {event}")
        await self.send(text_data=json.dumps({
            'type': 'typing',
            'is_typing': event['is_typing'],
            'user_id': event['user_id'],
            'username': event['username']
        }))

    async def user_status_message(self, event):
        """Send user status to WebSocket"""
        print(f"👤 Broadcasting user status: {event}")
        await self.send(text_data=json.dumps({
            'type': 'user_status',
            'is_online': event['is_online'],
            'user_id': event['user_id'],
            'username': event['username']
        }))

    async def message_deleted(self, event):
        """Send message deletion event to WebSocket"""
        print(f"🗑️ Broadcasting message deletion: {event}")
        await self.send(text_data=json.dumps({
            'type': 'message_deleted',
            'message_id': event['message_id'],
            'deleted_by': event.get('deleted_by'),
            'deleted_by_id': event.get('deleted_by_id')
        }))

    @sync_to_async
    def verify_access(self):
        """Verify user has access to this thread"""
        try:
            return Thread.objects.filter(
                id=self.thread_id, 
                participants=self.user
            ).exists()
        except Exception as e:
            print(f"❌ Access verification error: {e}")
            return False

    @sync_to_async
    def save_message_to_db(self, thread_id, content):
        """Save message to database"""
        try:
            thread = Thread.objects.get(id=thread_id)
            message = Message.objects.create(
                thread=thread,
                sender=self.user,
                content=content
            )
            return message
        except Exception as e:
            print(f"❌ Error saving message to DB: {e}")
            return None

    @sync_to_async
    def verify_message_ownership(self, message_id):
        """Verify that the user owns the message they're trying to delete"""
        try:
            message = Message.objects.get(id=message_id)
            return message.sender == self.user
        except Message.DoesNotExist:
            print(f"❌ Message {message_id} not found")
            return False
        except Exception as e:
            print(f"❌ Error verifying message ownership: {e}")
            return False