from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.urls import reverse
from .models import Thread, Message

@login_required
@require_POST
def send_message(request):
    """Send a new message (handles both text and files)."""
    try:
        thread_id = request.POST.get('thread_id')
        content = request.POST.get('content', '')
        image = request.FILES.get('image')
        file = request.FILES.get('file')
        
        thread = get_object_or_404(Thread, id=thread_id)
        
        # Verify user is a participant
        if not request.user.threads.filter(id=thread_id).exists():
            return JsonResponse({'success': False, 'error': 'Access denied'})
        
        # Create message
        message = Message.objects.create(
            thread=thread,
            sender=request.user,
            content=content
        )
        
        # Handle file uploads
        if image:
            message.image = image
        if file:
            message.file = file
            message.file_name = file.name
        
        message.save()
        
        # ✅ FIX: CREATE NOTIFICATION FOR RECIPIENT
        try:
            from notifications.utils import create_notification
            
            # Get the other user(s) in the thread
            other_users = thread.participants.exclude(id=request.user.id)
            
            for other_user in other_users:
                # Create notification for each recipient
                notification_text = f"{request.user.username} sent you a message"
                if content:
                    if len(content) > 50:
                        notification_text = f"{request.user.username}: {content[:50]}..."
                    else:
                        notification_text = f"{request.user.username}: {content}"
                
                create_notification(
                    recipient=other_user,
                    notification_type='message',
                    title='New Message',
                    text=notification_text,
                    sender=request.user,
                    target_url=reverse('messaging:thread', kwargs={'thread_id': thread.id})
                )
                
                print(f"✅ Created message notification for {other_user.username}")
                
        except Exception as e:
            print(f"❌ Error creating message notification: {e}")
        
        return JsonResponse({
            'success': True,
            'message_id': message.id,
            'content': message.content,
            'image_url': message.image.url if message.image else None,
            'file_url': message.file.url if message.file else None,
            'file_name': message.file_name
        })
        
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)})

@login_required
def inbox_view(request):
    """Display all threads for the current user."""
    try:
        # Use the reverse relation from User to Thread
        threads = request.user.threads.all().order_by('-updated_at')
        
        threads_with_data = []
        for thread in threads:
            # Get last message safely
            last_message = thread.messages.order_by('-created_at').first()
            
            # Get other user safely
            other_user = thread.participants.exclude(id=request.user.id).first()
            
            # Count unread messages in this thread
            unread_count = thread.messages.filter(
                is_read=False
            ).exclude(sender=request.user).count()
            
            threads_with_data.append({
                'thread': thread,
                'last_message': last_message,
                'other_user': other_user,
                'unread_count': unread_count  # Add unread count for UI
            })
        
        context = {
            'threads': threads_with_data,
            'active_tab': 'messages'
        }
        return render(request, 'messaging/inbox.html', context)
        
    except Exception as e:
        print(f"Error in inbox_view: {e}")
        context = {
            'threads': [],
            'active_tab': 'messages',
            'error': 'Unable to load messages'
        }
        return render(request, 'messaging/inbox.html', context)

@login_required
def thread_view(request, thread_id):
    """Display a specific thread and its messages."""
    thread = get_object_or_404(Thread, id=thread_id)
    
    # Check if user is a participant in this thread using the reverse relation
    if not request.user.threads.filter(id=thread_id).exists():
        return redirect('messaging:inbox')
    
    # ✅ FIX: MARK MESSAGES AS READ WHEN VIEWING THREAD
    try:
        # Mark all unread messages in this thread as read
        unread_messages = thread.messages.filter(
            is_read=False
        ).exclude(sender=request.user)
        
        unread_count = unread_messages.count()
        if unread_count > 0:
            unread_messages.update(is_read=True)
            print(f"✅ Marked {unread_count} messages as read in thread {thread_id}")
            
    except Exception as e:
        print(f"❌ Error marking messages as read: {e}")
    
    # Get messages for this thread (exclude deleted messages)
    messages = thread.messages.select_related('sender').filter(is_deleted=False)
    
    other_user = thread.participants.exclude(id=request.user.id).first()
    
    context = {
        'thread': thread,
        'messages': messages,
        'other_user': other_user,
        'active_tab': 'messages'
    }
    return render(request, 'messaging/thread.html', context)

@login_required
def start_thread(request, username):
    """Start a new thread with a user."""
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    other_user = get_object_or_404(User, username=username)
    
    if other_user == request.user:
        return redirect('messaging:inbox')
    
    # Get or create thread
    thread = Thread.objects.get_or_create_thread(request.user, other_user)
    
    return redirect('messaging:thread', thread_id=thread.id)

@login_required
@require_POST
def delete_message(request, message_id):
    """Delete a specific message using soft delete."""
    try:
        message = get_object_or_404(Message, id=message_id)
        
        # Verify user is the sender of the message
        if message.sender != request.user:
            return JsonResponse({
                'success': False, 
                'error': 'You can only delete your own messages'
            }, status=403)
        
        # Use the existing soft_delete method from your model
        message.soft_delete()
        
        return JsonResponse({
            'success': True,
            'message': 'Message deleted successfully'
        })
        
    except Exception as e:
        return JsonResponse({
            'success': False, 
            'error': str(e)
        }, status=500)

@login_required
@require_POST
def delete_thread(request, thread_id):
    """Delete a message thread."""
    try:
        thread = get_object_or_404(Thread, id=thread_id)
        
        # Verify user is a participant in this thread
        if not request.user.threads.filter(id=thread_id).exists():
            return JsonResponse({
                'success': False, 
                'error': 'Access denied'
            }, status=403)
        
        # Delete the thread
        thread.delete()
        
        # Return JSON response for AJAX requests
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({
                'success': True,
                'message': 'Conversation deleted successfully',
                'redirect_url': reverse('messaging:inbox')
            })
        
        # For regular form submissions
        return redirect('messaging:inbox')
        
    except Exception as e:
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({
                'success': False, 
                'error': str(e)
            }, status=500)
        # Handle non-AJAX error appropriately
        return redirect('messaging:inbox')

# ✅ ADD: Test function to debug notifications
@login_required
def test_message_notification(request, username):
    """Test message notification creation"""
    try:
        from notifications.utils import create_notification
        from django.contrib.auth import get_user_model
        User = get_user_model()
        
        other_user = User.objects.get(username=username)
        
        # Create test notification
        notification = create_notification(
            recipient=other_user,
            notification_type='message',
            title='Test Message',
            text=f'{request.user.username} sent you a test message',
            sender=request.user,
            target_url=reverse('messaging:inbox')
        )
        
        if notification:
            return JsonResponse({
                'success': True,
                'message': f'✅ Test notification created for {other_user.username}',
                'notification_id': notification.id
            })
        else:
            return JsonResponse({
                'success': False,
                'message': '❌ Failed to create notification (user preferences might be disabled)'
            })
            
    except User.DoesNotExist:
        return JsonResponse({'success': False, 'message': '❌ User not found'})
    except Exception as e:
        return JsonResponse({'success': False, 'message': f'❌ Error: {str(e)}'})