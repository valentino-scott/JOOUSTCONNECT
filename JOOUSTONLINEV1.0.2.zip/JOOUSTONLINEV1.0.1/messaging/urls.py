from django.urls import path
from . import views

app_name = 'messaging'

urlpatterns = [
    path('', views.inbox_view, name='inbox'),
    path('thread/<int:thread_id>/', views.thread_view, name='thread'),
    path('send/', views.send_message, name='send_message'),
    path('start/<str:username>/', views.start_thread, name='start_thread'),
    path('delete/<int:thread_id>/', views.delete_thread, name='delete_thread'),
    path('test-notification/<str:username>/', views.test_message_notification, name='test_message_notification'),  # ADD THIS

    path('delete-message/<int:message_id>/', views.delete_message, name='delete_message'),  # ADD THIS LINE
]