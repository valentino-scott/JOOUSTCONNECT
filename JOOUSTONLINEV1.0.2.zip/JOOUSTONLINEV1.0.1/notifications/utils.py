from django.utils import timezone
from .models import Notification, NotificationPreference

def create_notification(recipient, notification_type, text, sender=None, post=None, title=None, target_url=None):
    """
    Create a new notification with enhanced features
    
    Args:
        recipient: User receiving the notification
        notification_type: Type of notification
        text: Notification message
        sender: User who triggered the notification (optional)
        post: Related post (optional)
        title: Notification title (optional)
        target_url: URL to redirect to (optional)
    """
    # Check user preferences
    preference, created = NotificationPreference.objects.get_or_create(user=recipient)
    
    # Check if user wants this type of notification
    if not preference.should_send_notification(notification_type):
        return None
    
    # Check quiet hours
    if preference.is_quiet_hours():
        # Still create the notification but don't send immediate alerts
        pass
    
    notification = Notification.objects.create(
        recipient=recipient,
        sender=sender,
        notification_type=notification_type,
        text=text,
        post=post,
        title=title or text,  # Use text as title if no title provided
        target_url=target_url
    )
    
    return notification

def get_unread_notifications_count(user):
    """Get count of unread notifications for user"""
    return Notification.objects.filter(recipient=user, is_read=False).count()

def get_unread_notifications(user, limit=10):
    """Get unread notifications for user"""
    return Notification.objects.filter(recipient=user, is_read=False).order_by('-created_at')[:limit]

def get_all_notifications(user, limit=20):
    """Get all notifications for user"""
    return Notification.objects.filter(recipient=user).order_by('-created_at')[:limit]

def mark_notifications_read(user, notification_ids=None):
    """Mark notifications as read"""
    if notification_ids:
        Notification.objects.filter(recipient=user, id__in=notification_ids, is_read=False).update(is_read=True)
    else:
        Notification.objects.filter(recipient=user, is_read=False).update(is_read=True)

def mark_notification_read(notification_id, user):
    """Mark a specific notification as read"""
    try:
        notification = Notification.objects.get(id=notification_id, recipient=user)
        notification.mark_as_read()
        return True
    except Notification.DoesNotExist:
        return False

def create_follow_notification(followed_user, follower):
    """Create notification for new follower"""
    text = f"{follower.username} started following you"
    title = "New Follower"
    target_url = f"/accounts/profile/{follower.username}/"
    
    return create_notification(
        recipient=followed_user,
        notification_type='follow',
        text=text,
        sender=follower,
        title=title,
        target_url=target_url
    )

def create_like_notification(post, liker):
    """Create notification for post like"""
    text = f"{liker.username} liked your post"
    title = "Post Liked"
    target_url = post.get_absolute_url() if hasattr(post, 'get_absolute_url') else f"/posts/{post.id}/"
    
    return create_notification(
        recipient=post.author,
        notification_type='like',
        text=text,
        sender=liker,
        post=post,
        title=title,
        target_url=target_url
    )

def create_comment_notification(post, commenter, comment_text):
    """Create notification for new comment"""
    text = f"{commenter.username} commented: {comment_text[:50]}..."
    title = "New Comment"
    target_url = post.get_absolute_url() if hasattr(post, 'get_absolute_url') else f"/posts/{post.id}/"
    
    return create_notification(
        recipient=post.author,
        notification_type='comment',
        text=text,
        sender=commenter,
        post=post,
        title=title,
        target_url=target_url
    )

def create_new_post_notification(post, followers):
    """Create notifications for new post to followers"""
    text = f"{post.author.username} created a new post"
    title = "New Post from User You Follow"
    target_url = post.get_absolute_url() if hasattr(post, 'get_absolute_url') else f"/posts/{post.id}/"
    
    notifications = []
    for follower in followers:
        notification = create_notification(
            recipient=follower,
            notification_type='new_post',
            text=text,
            sender=post.author,
            post=post,
            title=title,
            target_url=target_url
        )
        if notification:
            notifications.append(notification)
    
    return notifications

def get_notification_stats(user):
    """Get comprehensive notification statistics"""
    total_notifications = Notification.objects.filter(recipient=user).count()
    unread_count = get_unread_notifications_count(user)
    read_count = total_notifications - unread_count
    
    # Count by type
    type_counts = {}
    for notification_type, _ in Notification.NOTIFICATION_TYPES:
        count = Notification.objects.filter(recipient=user, notification_type=notification_type).count()
        type_counts[notification_type] = count
    
    return {
        'total': total_notifications,
        'unread': unread_count,
        'read': read_count,
        'by_type': type_counts
    }