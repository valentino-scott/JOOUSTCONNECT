from django.contrib import admin
from .models import Notification, NotificationPreference

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('recipient', 'sender', 'notification_type', 'is_read', 'created_at', 'title')
    list_filter = ('notification_type', 'is_read', 'created_at')
    search_fields = ('recipient__username', 'sender__username', 'text', 'title')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at',)
    fieldsets = (
        ('Basic Information', {
            'fields': ('recipient', 'sender', 'notification_type', 'is_read')
        }),
        ('Content', {
            'fields': ('title', 'text', 'post', 'target_url')
        }),
        ('Metadata', {
            'fields': ('created_at', 'related_object_id', 'related_content_type')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('recipient', 'sender', 'post')

@admin.register(NotificationPreference)
class NotificationPreferenceAdmin(admin.ModelAdmin):
    list_display = ('user', 'email_notifications', 'push_notifications', 'in_app_notifications', 'quiet_hours_enabled')
    list_filter = ('email_notifications', 'push_notifications', 'in_app_notifications', 'quiet_hours_enabled')
    search_fields = ('user__username', 'user__email')
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('User', {
            'fields': ('user',)
        }),
        ('Notification Channels', {
            'fields': ('email_notifications', 'push_notifications', 'in_app_notifications')
        }),
        ('Notification Types', {
            'fields': (
                'enable_follow_notifications',
                'enable_like_notifications', 
                'enable_comment_notifications',
                'enable_repost_notifications',
                'enable_message_notifications',
                'enable_mention_notifications',
                'enable_new_post_notifications',
                'enable_announcement_notifications',
            )
        }),
        ('Quiet Hours', {
            'fields': ('quiet_hours_enabled', 'quiet_hours_start', 'quiet_hours_end')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')