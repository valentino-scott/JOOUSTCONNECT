from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Notification

@login_required
def notifications_view(request):
    """View all notifications"""
    notifications = request.user.notifications.all()[:50]
    
    # Mark all as read when user visits notifications page
    request.user.notifications.filter(is_read=False).update(is_read=True)
    
    return render(request, 'notifications/list.html', {
        'notifications': notifications
    })

@login_required
def unread_count(request):
    """Get unread notification count"""
    count = request.user.notifications.filter(is_read=False).count()
    return JsonResponse({'count': count})

@login_required
def mark_as_read(request, notification_id):
    """Mark a notification as read"""
    if request.method == 'POST':
        notification = request.user.notifications.filter(id=notification_id).first()
        if notification:
            notification.is_read = True
            notification.save()
            return JsonResponse({'status': 'success'})
    
    return JsonResponse({'error': 'Invalid request'}, status=400)

# NEW ENHANCED VIEWS

@login_required
@require_http_methods(["GET"])
def enhanced_unread_count(request):
    """Enhanced API to get counts for all notification types"""
    try:
        from messaging.models import Message
        from posts.models import Post
        from django.utils import timezone
        from datetime import timedelta
        
        user = request.user
        
        # Get unread notifications count (existing functionality)
        unread_notifications_count = user.notifications.filter(is_read=False).count()
        
        # Get unread messages count
        try:
            unread_messages_count = Message.objects.filter(
                thread__participants=user,
                is_read=False
            ).exclude(sender=user).count()
        except Exception as e:
            print(f"Error getting message count: {e}")
            unread_messages_count = 0
        
        # Get new posts count (posts from followed users in last 24 hours)
        try:
            new_posts_count = Post.objects.filter(
                created_at__gte=timezone.now() - timedelta(hours=24),
                author__profile__followers=user
            ).exclude(author=user).count()
        except Exception as e:
            print(f"Error getting new posts count: {e}")
            new_posts_count = 0
        
        total = unread_notifications_count + unread_messages_count
        
        return JsonResponse({
            'new_posts': min(new_posts_count, 99),
            'unread_messages': min(unread_messages_count, 99),
            'unread_notifications': min(unread_notifications_count, 99),
            'total': min(total, 99)
        })
        
    except Exception as e:
        print(f"Error in enhanced_unread_count: {e}")
        return JsonResponse({
            'new_posts': 0,
            'unread_messages': 0,
            'unread_notifications': 0,
            'total': 0
        })

@login_required
@csrf_exempt
@require_http_methods(["POST"])
def mark_all_read(request):
    """Mark all notifications as read"""
    try:
        data = json.loads(request.body)
        notification_type = data.get('type', 'all')
        
        if notification_type == 'messages':
            # Mark all messages as read
            try:
                from messaging.models import Message
                Message.objects.filter(
                    thread__participants=request.user,
                    is_read=False
                ).exclude(sender=request.user).update(is_read=True)
            except Exception as e:
                print(f"Error marking messages read: {e}")
                
        elif notification_type == 'notifications':
            # Mark all app notifications as read
            request.user.notifications.filter(is_read=False).update(is_read=True)
            
        elif notification_type == 'all':
            # Mark everything as read
            request.user.notifications.filter(is_read=False).update(is_read=True)
            try:
                from messaging.models import Message
                Message.objects.filter(
                    thread__participants=request.user,
                    is_read=False
                ).exclude(sender=request.user).update(is_read=True)
            except Exception as e:
                print(f"Error marking messages read: {e}")
        
        return JsonResponse({'status': 'success'})
        
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

@login_required
@require_http_methods(["GET"])
def notification_list_api(request):
    """API endpoint to get notification list for dropdown"""
    try:
        notifications = request.user.notifications.filter(is_read=False).order_by('-created_at')[:10]
        notifications_data = []
        
        for notification in notifications:
            notifications_data.append({
                'id': notification.id,
                'type': notification.notification_type,
                'title': notification.title or notification.text,
                'message': notification.text,
                'target_url': notification.get_absolute_url(),
                'created_at': notification.created_at.isoformat(),
                'is_read': notification.is_read,
                'sender': notification.sender.username if notification.sender else None,
                'is_recent': notification.is_recent
            })
        
        return JsonResponse({
            'notifications': notifications_data,
            'count': len(notifications_data)
        })
        
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

@login_required
def notification_preferences(request):
    """View and update notification preferences"""
    # Get or create preferences for user
    preference, created = NotificationPreference.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        # Update preferences
        preference.email_notifications = request.POST.get('email_notifications') == 'on'
        preference.push_notifications = request.POST.get('push_notifications') == 'on'
        preference.in_app_notifications = request.POST.get('in_app_notifications') == 'on'
        
        # Type-specific preferences
        preference.enable_follow_notifications = request.POST.get('enable_follow_notifications') == 'on'
        preference.enable_like_notifications = request.POST.get('enable_like_notifications') == 'on'
        preference.enable_comment_notifications = request.POST.get('enable_comment_notifications') == 'on'
        preference.enable_repost_notifications = request.POST.get('enable_repost_notifications') == 'on'
        preference.enable_message_notifications = request.POST.get('enable_message_notifications') == 'on'
        preference.enable_mention_notifications = request.POST.get('enable_mention_notifications') == 'on'
        preference.enable_new_post_notifications = request.POST.get('enable_new_post_notifications') == 'on'
        preference.enable_announcement_notifications = request.POST.get('enable_announcement_notifications') == 'on'
        
        # Quiet hours
        preference.quiet_hours_enabled = request.POST.get('quiet_hours_enabled') == 'on'
        
        preference.save()
        
        return JsonResponse({'status': 'success'})
    
    return render(request, 'notifications/preferences.html', {
        'preference': preference
    })