from django.urls import path
from . import views

app_name = 'notifications'

urlpatterns = [
    # EXISTING URLS - KEEP THESE UNCHANGED
    path('', views.notifications_view, name='list'),
    path('unread-count/', views.unread_count, name='unread_count'),
    path('<int:notification_id>/read/', views.mark_as_read, name='mark_read'),
    
    # NEW ENHANCED API ENDPOINTS
    path('api/enhanced-unread-count/', views.enhanced_unread_count, name='api_enhanced_unread_count'),
    path('api/mark-all-read/', views.mark_all_read, name='api_mark_all_read'),
    path('api/notification-list/', views.notification_list_api, name='api_notification_list'),
    path('preferences/', views.notification_preferences, name='preferences'),
]