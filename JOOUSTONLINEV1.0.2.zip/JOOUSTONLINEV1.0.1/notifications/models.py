from django.db import models
from django.conf import settings

class Notification(models.Model):
    """Enhanced Notification model for user alerts"""
    NOTIFICATION_TYPES = [
        ('follow', 'Follow'),
        ('like', 'Like'),
        ('comment', 'Comment'),
        ('repost', 'Repost'),
        ('message', 'Message'),
        ('mention', 'Mention'),
        ('new_post', 'New Post'),  # Added
        ('announcement', 'Announcement'),  # Added
    ]
    
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='sent_notifications', null=True, blank=True)
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    text = models.CharField(max_length=255)
    post = models.ForeignKey('posts.Post', on_delete=models.CASCADE, null=True, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    # New fields for enhanced functionality
    title = models.CharField(max_length=200, blank=True, null=True)  # Added for richer notifications
    target_url = models.URLField(blank=True, null=True)  # Added for direct linking
    related_object_id = models.PositiveIntegerField(blank=True, null=True)  # For generic relationships
    related_content_type = models.CharField(max_length=50, blank=True, null=True)  # For generic relationships
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', 'is_read', 'created_at']),
            models.Index(fields=['recipient', 'notification_type']),
        ]
    
    def __str__(self):
        return f"{self.notification_type} notification for {self.recipient.username}"
    
    def mark_as_read(self):
        """Mark this notification as read"""
        self.is_read = True
        self.save()
    
    @property
    def is_recent(self):
        """Check if notification is from last 24 hours"""
        from django.utils import timezone
        from datetime import timedelta
        return self.created_at >= timezone.now() - timedelta(hours=24)
    
    def get_absolute_url(self):
        """Get URL for this notification"""
        if self.target_url:
            return self.target_url
        elif self.post:
            return self.post.get_absolute_url()
        elif self.sender:
            return f"/accounts/profile/{self.sender.username}/"
        return "#"

# New model for notification preferences
class NotificationPreference(models.Model):
    """User preferences for notifications"""
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notification_preferences')
    
    # Notification type preferences
    email_notifications = models.BooleanField(default=True)
    push_notifications = models.BooleanField(default=True)
    in_app_notifications = models.BooleanField(default=True)
    
    # Type-specific preferences
    enable_follow_notifications = models.BooleanField(default=True)
    enable_like_notifications = models.BooleanField(default=True)
    enable_comment_notifications = models.BooleanField(default=True)
    enable_repost_notifications = models.BooleanField(default=True)
    enable_message_notifications = models.BooleanField(default=True)
    enable_mention_notifications = models.BooleanField(default=True)
    enable_new_post_notifications = models.BooleanField(default=True)
    enable_announcement_notifications = models.BooleanField(default=True)
    
    # Quiet hours
    quiet_hours_enabled = models.BooleanField(default=False)
    quiet_hours_start = models.TimeField(default='22:00')  # 10 PM
    quiet_hours_end = models.TimeField(default='07:00')    # 7 AM
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Notification preferences for {self.user.username}"
    
    def should_send_notification(self, notification_type):
        """Check if notification should be sent based on user preferences"""
        if not self.in_app_notifications:
            return False
            
        type_mapping = {
            'follow': self.enable_follow_notifications,
            'like': self.enable_like_notifications,
            'comment': self.enable_comment_notifications,
            'repost': self.enable_repost_notifications,
            'message': self.enable_message_notifications,
            'mention': self.enable_mention_notifications,
            'new_post': self.enable_new_post_notifications,
            'announcement': self.enable_announcement_notifications,
        }
        
        return type_mapping.get(notification_type, True)
    
    def is_quiet_hours(self):
        """Check if currently in quiet hours"""
        if not self.quiet_hours_enabled:
            return False
            
        from django.utils import timezone
        import datetime
        
        now = timezone.now().time()
        return self.quiet_hours_start <= now <= self.quiet_hours_end