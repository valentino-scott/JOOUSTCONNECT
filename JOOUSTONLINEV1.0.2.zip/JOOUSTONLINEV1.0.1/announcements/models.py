from django.db import models
from django.conf import settings

class Announcement(models.Model):
    """Announcement model for university notices"""
    CATEGORY_CHOICES = [
        ('general', 'General'),
        ('academic', 'Academic'),
        ('event', 'Event'),
        ('deadline', 'Deadline'),
        ('maintenance', 'Maintenance'),
        ('urgent', 'Urgent'),
    ]
    
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='announcements')
    title = models.CharField(max_length=200)
    content = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    is_pinned = models.BooleanField(default=False)
    is_published = models.BooleanField(default=True)
    image = models.ImageField(upload_to='announcements/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-is_pinned', '-created_at']
    
    def __str__(self):
        return self.title
