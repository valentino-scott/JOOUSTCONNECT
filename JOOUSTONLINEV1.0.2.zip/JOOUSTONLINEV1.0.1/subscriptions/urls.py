# subscriptions/urls.py
from django.urls import path
from . import views

app_name = 'subscriptions'

urlpatterns = [
    path('plans/', views.plans, name='plans'),
    path('upgrade/', views.upgrade, name='upgrade'),
    path('payment-status/<str:checkout_request_id>/', views.payment_status, name='payment_status'),
    path('cancel/', views.cancel_subscription, name='cancel'),
    path('payhero-callback/', views.payhero_callback, name='payhero_callback'),
    path('reconcile/<str:reference>/', views.reconcile_payment, name='reconcile_payment'),
    # Optional: keep old callback for backward compatibility
    path('mpesa-callback/', views.mpesa_callback, name='mpesa_callback'),
]