# subscriptions/views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import json
import secrets
import logging
from django.utils import timezone
from .models import Subscription, SubscriptionPlan, PaymentTransaction
from .services import PayHeroService

logger = logging.getLogger(__name__)

@login_required
def plans(request):
    """Display subscription plans"""
    try:
        subscription = Subscription.objects.filter(user=request.user, is_active=True).first()
    except Subscription.DoesNotExist:
        subscription = None
    
    free_plan = SubscriptionPlan.objects.get(tier='free')
    premium_plan = SubscriptionPlan.objects.get(tier='premium')
    
    context = {
        'subscription': subscription,
        'free_plan': free_plan,
        'premium_plan': premium_plan,
    }
    return render(request, 'subscriptions/plans.html', context)

@login_required
def upgrade(request):
    """Upgrade to premium subscription with real PayHero integration"""
    # Check if user already has active premium subscription
    active_premium = Subscription.objects.filter(
        user=request.user, 
        is_active=True,
        plan__tier='premium'
    ).first()
    
    if active_premium and active_premium.is_valid:
        messages.info(request, 'You already have an active premium subscription!')
        return redirect('subscriptions:plans')
    
    if request.method == 'POST':
        phone_number = request.POST.get('phone_number')
        payment_method = request.POST.get('payment_method')
        
        if payment_method != 'mpesa':
            messages.error(request, 'Currently only M-Pesa payments are supported.')
            return redirect('subscriptions:upgrade')
        
        if not phone_number:
            messages.error(request, 'Please provide your M-Pesa phone number.')
            return redirect('subscriptions:upgrade')
        
        # Validate phone number format
        phone_number = phone_number.replace(' ', '').replace('+', '')
        if not (phone_number.startswith('254') or phone_number.startswith('07') or phone_number.startswith('+254')):
            messages.error(request, 'Please enter a valid Kenyan phone number!')
            return redirect('subscriptions:upgrade')
        
        # Convert phone number to 254 format
        if phone_number.startswith('07'):
            phone_number = '254' + phone_number[1:]
        elif phone_number.startswith('+254'):
            phone_number = phone_number[1:]
        
        # Get premium plan
        premium_plan = SubscriptionPlan.objects.get(tier='premium')
        
        # Generate unique reference
        external_reference = f"JOOUST{request.user.id}_{secrets.token_hex(8)}"
        
        # Create pending subscription
        subscription = Subscription.objects.create(
            user=request.user,
            plan=premium_plan,
            status='pending',
            is_active=False,
            phone_number=phone_number,
            amount_paid=premium_plan.price
        )
        
        # Initialize PayHero service
        payhero = PayHeroService()
        
        # Initiate STK push
        result = payhero.initiate_stk_push(
            phone_number=phone_number,
            amount=int(premium_plan.price),
            external_reference=external_reference
        )
        
        if result['success']:
            # Save checkout request ID
            subscription.checkout_request_id = external_reference
            subscription.save()
            
            # Create payment transaction record
            PaymentTransaction.objects.create(
                subscription=subscription,
                checkout_request_id=external_reference,
                external_reference=external_reference,
                phone_number=phone_number,
                amount=premium_plan.price,
                status='pending'
            )
            
            messages.success(request, f"✅ M-Pesa prompt sent to {phone_number}. Please check your phone to complete payment of KES {premium_plan.price}.")
            return redirect('subscriptions:payment_status', checkout_request_id=external_reference)
        else:
            subscription.delete()
            error_msg = result.get('message', 'Payment initiation failed. Please try again.')
            messages.error(request, f"❌ {error_msg}")
            return redirect('subscriptions:upgrade')
    
    return render(request, 'subscriptions/upgrade.html')

@login_required
def payment_status(request, checkout_request_id):
    """Check payment status with detailed failure reason handling"""
    # Use select_related to reduce database queries
    transaction = get_object_or_404(
        PaymentTransaction.objects.select_related('subscription', 'subscription__user'), 
        checkout_request_id=checkout_request_id
    )
    
    # Debug logging
    logger.info(f"🔍 Payment status check - Transaction: {checkout_request_id}, Current status: {transaction.status}, Failure reason: {transaction.failure_reason}")
    
    # Check if payment is already successful
    if transaction.status == 'successful':
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return JsonResponse({
                'status': 'successful',
                'redirect_url': f'/accounts/profile/{request.user.username}/'
            })
        messages.success(request, '🎉 Payment completed successfully! Welcome to JOOUST CONNECT Premium!')
        return redirect('accounts:profile', username=request.user.username)
    
    # If this is an AJAX request, return JSON for real-time updates
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'status': transaction.status,
            'failure_reason': transaction.failure_reason,
            'message': transaction.get_failure_message() if transaction.status == 'failed' else None,
            'updated_at': transaction.updated_at.isoformat() if transaction.updated_at else None,
            'checkout_request_id': checkout_request_id
        })
    
    # Check status with PayHero on POST or if still pending
    should_check_status = (
        request.method == 'POST' or 
        transaction.status in ['pending', 'initiated'] or
        (transaction.updated_at and (timezone.now() - transaction.updated_at).seconds > 30)
    )
    
    if should_check_status:
        payhero = PayHeroService()
        status_result = payhero.check_transaction_status(checkout_request_id)
        
        logger.info(f"🔍 PayHero status check result: {status_result}")
        
        if status_result['success']:
            remote_status = status_result.get('remote_status')
            remote_reason = status_result.get('remote_reason', '')
            
            logger.info(f"🔍 Remote status: {remote_status}, Remote reason: {remote_reason}")
            
            if remote_status == 'completed':  # Payment successful
                transaction.mark_as_successful()
                logger.info(f"✅ Payment marked as successful for {checkout_request_id}")
                messages.success(request, '🎉 Payment completed successfully! Welcome to JOOUST CONNECT Premium!')
                return redirect('accounts:profile', username=request.user.username)
                
            elif remote_status == 'failed':  # Failed payment
                failure_reason = map_failure_reason(remote_reason)
                transaction.mark_as_failed(failure_reason=failure_reason, result_description=remote_reason)
                failure_message = transaction.get_failure_message()
                logger.info(f"❌ Payment failed for {checkout_request_id}: {failure_reason}")
                messages.error(request, f'❌ {failure_message}')
                
            elif remote_status == 'cancelled':  # Cancelled payment
                transaction.mark_as_cancelled()
                logger.info(f"⏹️ Payment cancelled for {checkout_request_id}")
                messages.warning(request, 'Payment was cancelled. No amount was deducted.')
                
            else:  # Still pending
                # Refresh from database in case callback updated it
                transaction.refresh_from_db()
                if transaction.status != 'pending':
                    # Status changed, redirect to show updated status
                    return redirect('subscriptions:payment_status', checkout_request_id=checkout_request_id)
                else:
                    messages.info(request, '⏳ Payment is being processed. Please wait...')
        else:
            logger.warning(f"⚠️ PayHero status check failed: {status_result.get('message')}")
    
    context = {
        'transaction': transaction,
        'subscription': transaction.subscription,
    }
    return render(request, 'subscriptions/payment_status.html', context)

def map_failure_reason(remote_reason):
    """Map PayHero failure reasons to our failure reason codes"""
    if not remote_reason:
        return 'other'
    
    remote_reason_lower = remote_reason.lower()
    
    if any(term in remote_reason_lower for term in ['insufficient', 'low balance', 'not enough']):
        return 'insufficient_balance'
    elif any(term in remote_reason_lower for term in ['pin', 'wrong pin', 'invalid pin']):
        return 'wrong_pin'
    elif any(term in remote_reason_lower for term in ['cancelled', 'canceled', 'user cancelled']):
        return 'cancelled'
    elif any(term in remote_reason_lower for term in ['timeout', 'timed out', 'expired']):
        return 'timeout'
    elif any(term in remote_reason_lower for term in ['limit exceeded', 'daily limit']):
        return 'daily_limit_exceeded'
    elif any(term in remote_reason_lower for term in ['invalid account', 'not registered']):
        return 'invalid_account'
    else:
        return 'other'

@login_required
def cancel_subscription(request):
    """Cancel premium subscription"""
    subscription = get_object_or_404(
        Subscription, 
        user=request.user, 
        is_active=True,
        plan__tier='premium'
    )
    
    if request.method == 'POST':
        subscription.cancel_subscription()
        messages.success(request, 'Your premium subscription has been cancelled.')
        return redirect('subscriptions:plans')
    
    return render(request, 'subscriptions/cancel.html', {'subscription': subscription})

@csrf_exempt
@require_POST
def payhero_callback(request):
    """Handle PayHero callback - IMPROVED FAILURE REASON MAPPING"""
    try:
        # Get the raw request body
        raw_body = request.body.decode('utf-8')
        
        print("🎯" * 60)
        print("🎯 PAYHERO CALLBACK - RAW DATA:")
        print("🎯" * 60)
        print(raw_body)
        print("🎯" * 60)
        
        # Parse JSON
        data = json.loads(raw_body)
        
        # Extract reference from ALL possible locations
        reference = None
        
        # PayHero sends ExternalReference in the response
        if 'response' in data and isinstance(data['response'], dict):
            response_data = data['response']
            print(f"🎯 RESPONSE DATA: {json.dumps(response_data, indent=2)}")
            
            # Use ExternalReference (this is what we store as checkout_request_id)
            reference = response_data.get("ExternalReference")
            
            # Fallback to external_reference at root
            if not reference:
                reference = data.get("external_reference") or data.get("reference")
        
        print(f"🎯 EXTRACTED REFERENCE: {reference}")
        
        if reference:
            try:
                # Lookup by external_reference (which is our checkout_request_id)
                transaction = PaymentTransaction.objects.select_related('subscription').get(checkout_request_id=reference)
                print(f"🎯 FOUND TRANSACTION: {reference}")
                
                # Extract status and details from response
                if 'response' in data and isinstance(data['response'], dict):
                    response_data = data['response']
                    raw_status = response_data.get("Status", "unknown")
                    result_code = response_data.get("ResultCode")
                    result_desc = response_data.get("ResultDesc", "")
                    
                    print(f"🎯 RAW STATUS: {raw_status}, RESULT CODE: {result_code}, DESC: {result_desc}")
                    
                    # Map PayHero result codes to our failure reasons
                    failure_reason = map_payhero_failure_reason(result_code, result_desc)
                    
                    # Simple status mapping based on ResultCode and Status
                    if result_code == 0:
                        # Payment successful
                        transaction.mark_as_successful()
                        print(f"✅ MARKED AS SUCCESSFUL: {reference}")
                    elif result_code == 1032:
                        # User cancelled
                        transaction.mark_as_cancelled()
                        print(f"⏹️ MARKED AS CANCELLED: {reference}")
                    else:
                        # Other failure - use mapped failure reason
                        transaction.mark_as_failed(failure_reason=failure_reason, result_description=result_desc)
                        print(f"❌ MARKED AS FAILED: {reference} - {failure_reason} - {result_desc}")
                
            except PaymentTransaction.DoesNotExist:
                print(f"❌ TRANSACTION NOT FOUND: {reference}")
                # Log available references for debugging
                recent_refs = PaymentTransaction.objects.values_list('checkout_request_id', flat=True)[:5]
                print(f"🎯 AVAILABLE REFERENCES: {list(recent_refs)}")
        else:
            print("❌ NO REFERENCE FOUND IN CALLBACK DATA")
            print(f"🎯 ALL DATA KEYS: {list(data.keys())}")
        
        print("🎯 CALLBACK PROCESSING COMPLETE")
        print("🎯" * 60)
        
        return JsonResponse({"status": "received"}, status=200)
        
    except Exception as e:
        print(f"❌ CALLBACK ERROR: {e}")
        import traceback
        print(f"❌ TRACEBACK: {traceback.format_exc()}")
        return JsonResponse({"error": "processing_error"}, status=500)

def map_payhero_failure_reason(result_code, result_desc):
    """Map PayHero result codes and descriptions to our failure reasons"""
    # Common M-Pesa failure codes via PayHero
    payhero_failure_codes = {
        1: 'insufficient_balance',  # Insufficient funds
        6: 'wrong_pin',  # Wrong PIN
        10: 'invalid_account',  # Invalid account
        1032: 'cancelled',  # Request cancelled by user
        1037: 'timeout',  # Request timeout
        2001: 'timeout',  # Timeout
        2002: 'duplicate_transaction',  # Duplicate transaction
        2003: 'system_error',  # System error
        2004: 'transaction_limit_exceeded',  # Transaction limit
        2005: 'daily_limit_exceeded',  # Daily limit
    }
    
    # Try to get from known codes first
    if result_code in payhero_failure_codes:
        return payhero_failure_codes[result_code]
    
    # Fallback to description mapping
    desc_lower = result_desc.lower()
    if any(term in desc_lower for term in ['insufficient', 'low balance', 'not enough']):
        return 'insufficient_balance'
    elif any(term in desc_lower for term in ['pin', 'wrong pin', 'invalid pin']):
        return 'wrong_pin'
    elif any(term in desc_lower for term in ['cancelled', 'canceled', 'user cancelled']):
        return 'cancelled'
    elif any(term in desc_lower for term in ['timeout', 'timed out', 'expired']):
        return 'timeout'
    elif any(term in desc_lower for term in ['limit exceeded', 'daily limit']):
        return 'daily_limit_exceeded'
    elif any(term in desc_lower for term in ['invalid account', 'not registered']):
        return 'invalid_account'
    elif any(term in desc_lower for term in ['duplicate', 'already processed']):
        return 'duplicate_transaction'
    else:
        return 'other'
    

    
@login_required
def reconcile_payment(request, reference):
    """Re-check payment status by querying PayHero and updating DB"""
    try:
        # First check local DB
        try:
            transaction = PaymentTransaction.objects.get(checkout_request_id=reference)
            local_status = transaction.status
        except PaymentTransaction.DoesNotExist:
            return JsonResponse({'error': 'Payment not found locally'}, status=404)
        
        # If API credentials missing, just return local status
        from django.conf import settings
        if not getattr(settings, 'PAYHERO_API_USERNAME', '') or not getattr(settings, 'PAYHERO_API_PASSWORD', ''):
            return JsonResponse({
                'reference': reference, 
                'local_status': local_status, 
                'remote_status': None, 
                'message': 'API credentials not configured'
            })
        
        # Check with PayHero
        payhero = PayHeroService()
        result = payhero.check_transaction_status(reference)
        
        if result['success']:
            remote_status = result.get('remote_status')
            remote_reason = result.get('remote_reason')
            
            # If remote_status found and different, update local DB
            if remote_status and remote_status != local_status:
                if remote_status == 'successful':
                    transaction.mark_as_successful()
                elif remote_status == 'failed':
                    failure_reason = map_failure_reason(remote_reason)
                    transaction.mark_as_failed(failure_reason=failure_reason, result_description=remote_reason)
                elif remote_status == 'cancelled':
                    transaction.mark_as_cancelled()
                else:
                    transaction.status = remote_status
                    if remote_reason:
                        transaction.result_description = remote_reason
                    transaction.updated_at = timezone.now()
                    transaction.save()
            
            return JsonResponse({
                'reference': reference,
                'local_status': local_status,
                'remote_status': remote_status,
                'remote_reason': remote_reason,
                'failure_reason': transaction.failure_reason,
                'remote_raw': result.get('remote_raw', {})
            })
        else:
            return JsonResponse({
                'error': 'Failed to check remote status',
                'detail': result.get('message')
            }, status=500)
            
    except Exception as e:
        logger.error(f"Reconcile error: {e}")
        return JsonResponse({'error': 'Unexpected error', 'detail': str(e)}, status=500)

# Keep the old mpesa_callback for backward compatibility
@csrf_exempt
@require_POST
def mpesa_callback(request):
    """Handle M-Pesa payment callback (old method - for backward compatibility)"""
    try:
        data = json.loads(request.body)
        logger.info(f"M-Pesa Callback Received: {data}")
        
        callback_data = data.get('Body', {}).get('stkCallback', {})
        
        checkout_request_id = callback_data.get('CheckoutRequestID')
        result_code = callback_data.get('ResultCode')
        result_desc = callback_data.get('ResultDesc')
        
        logger.info(f"Processing callback for CheckoutRequestID: {checkout_request_id}, ResultCode: {result_code}")
        
        # Find the transaction
        try:
            transaction = PaymentTransaction.objects.get(checkout_request_id=checkout_request_id)
            
            if result_code == 0:  # Successful payment
                # Extract receipt number and other details
                callback_metadata = callback_data.get('CallbackMetadata', {}).get('Item', [])
                receipt_number = None
                transaction_date = None
                
                for item in callback_metadata:
                    if item.get('Name') == 'MpesaReceiptNumber':
                        receipt_number = item.get('Value')
                    elif item.get('Name') == 'TransactionDate':
                        transaction_date = item.get('Value')
                
                transaction.mark_as_successful(
                    mpesa_receipt_number=receipt_number,
                    transaction_date=transaction_date
                )
                
                logger.info(f"Payment successful for {transaction.subscription.user.username}. Receipt: {receipt_number}")
                
            else:  # Failed payment
                # Map M-Pesa result codes to failure reasons
                failure_reason = map_mpesa_failure_reason(result_code, result_desc)
                transaction.mark_as_failed(
                    failure_reason=failure_reason,
                    result_code=result_code,
                    result_description=result_desc
                )
                
                logger.warning(f"Payment failed for {transaction.subscription.user.username}. Reason: {result_desc}")
        
        except PaymentTransaction.DoesNotExist:
            logger.error(f"Transaction not found for checkout request: {checkout_request_id}")
        
        return JsonResponse({'ResultCode': 0, 'ResultDesc': 'Success'})
    
    except Exception as e:
        logger.error(f"Error processing M-Pesa callback: {e}")
        return JsonResponse({'ResultCode': 1, 'ResultDesc': 'Failed'})

def map_mpesa_failure_reason(result_code, result_desc):
    """Map M-Pesa result codes to failure reasons"""
    # Common M-Pesa failure codes
    mpesa_failure_codes = {
        1: 'insufficient_balance',  # Insufficient funds
        6: 'wrong_pin',  # Wrong PIN
        10: 'invalid_account',  # Invalid account
        2001: 'timeout',  # Timeout
        2002: 'duplicate_transaction',  # Duplicate transaction
        2003: 'system_error',  # System error
        2004: 'transaction_limit_exceeded',  # Transaction limit
        2005: 'daily_limit_exceeded',  # Daily limit
    }
    
    # Try to get from known codes first
    if result_code in mpesa_failure_codes:
        return mpesa_failure_codes[result_code]
    
    # Fallback to description mapping
    desc_lower = result_desc.lower()
    if any(term in desc_lower for term in ['insufficient', 'low balance']):
        return 'insufficient_balance'
    elif any(term in desc_lower for term in ['pin', 'wrong pin']):
        return 'wrong_pin'
    elif any(term in desc_lower for term in ['timeout', 'timed out']):
        return 'timeout'
    elif any(term in desc_lower for term in ['limit exceeded']):
        return 'daily_limit_exceeded'
    elif any(term in desc_lower for term in ['cancelled', 'canceled']):
        return 'cancelled'
    else:
        return 'other'