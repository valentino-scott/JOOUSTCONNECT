# subscriptions/services.py
import requests
import base64
import json
from datetime import datetime
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

class PayHeroService:
    def __init__(self):
        self.base_url = 'https://backend.payhero.co.ke/api/v2'
        self.api_username = getattr(settings, 'PAYHERO_API_USERNAME', '')
        self.api_password = getattr(settings, 'PAYHERO_API_PASSWORD', '')
        self.callback_url = getattr(settings, 'PAYHERO_CALLBACK_URL', '')
        
    def get_auth_header(self):
        """Generate Basic Auth header for PayHero"""
        auth_string = f"{self.api_username}:{self.api_password}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        return f'Basic {encoded_auth}'
    
    def initiate_stk_push(self, phone_number, amount, external_reference):
        """Initiate STK push using PayHero API with correct channel ID"""
        try:
            # Prepare payment data with your channel ID 3864
            payment_data = {
                'amount': int(amount),
                'phone_number': phone_number,
                'channel_id': 3864,  # Your correct channel ID
                'provider': 'm-pesa',
                'external_reference': external_reference,
                'callback_url': self.callback_url
            }
            
            print(f"Sending payment request: {json.dumps(payment_data, indent=2)}")
            
            # Prepare headers
            headers = {
                'Content-Type': 'application/json',
                'Authorization': self.get_auth_header(),
                'User-Agent': 'PayFlow/1.0'
            }
            
            # Make API request to PayHero
            response = requests.post(
                f'{self.base_url}/payments',
                json=payment_data,
                headers=headers,
                timeout=30
            )
            
            print(f"PayHero response status: {response.status_code}")
            print(f"PayHero response: {response.text}")
            
            # Process response
            result = response.json()
            
            # Accept 200 or 201 as valid initiation responses
            if response.status_code in (200, 201):
                if result.get('success') == True:
                    return {
                        'success': True,
                        'checkout_request_id': external_reference,
                        'customer_message': 'M-Pesa STK initiated successfully! Check your phone.',
                        'response_code': '0',
                        'external_reference': external_reference,
                        'response_data': result
                    }
                else:
                    error_message = result.get('message', 'STK push failed to initiate')
                    # Check for specific error messages
                    if 'insufficient funds' in error_message.lower():
                        error_message = 'Insufficient funds in your M-Pesa account'
                    elif 'timeout' in error_message.lower():
                        error_message = 'Payment timeout. Please try again'
                    elif 'invalid phone' in error_message.lower():
                        error_message = 'Invalid phone number format'
                    
                    return {
                        'success': False,
                        'message': error_message,
                        'response_data': result
                    }
            else:
                error_message = result.get('error_message', result.get('message', f'HTTP Error {response.status_code}'))
                return {
                    'success': False,
                    'message': error_message,
                    'response_data': result
                }
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Network error: {str(e)}")
            return {
                'success': False,
                'message': f'Network error: {str(e)}'
            }
        except Exception as e:
            logger.error(f"Unexpected error: {str(e)}")
            return {
                'success': False,
                'message': f'Unexpected error: {str(e)}'
            }
    
    def check_transaction_status(self, reference):
        """Check transaction status - matches Flask reconcile function"""
        try:
            # Build Basic auth header
            headers = {
                'Authorization': self.get_auth_header(),
                'User-Agent': 'PayFlow/1.0'
            }
            
            url = f"{self.base_url}/transaction-status?reference={reference}"
            response = requests.get(url, headers=headers, timeout=20)
            remote_data = response.json() if response.status_code == 200 else {}
            
            # Extract remote status
            remote_status = None
            remote_reason = None
            
            if isinstance(remote_data, dict):
                # remote could be { "success": true, "data": { "status": "SUCCESS", ... } }
                data = remote_data.get('data') or remote_data
                if isinstance(data, dict):
                    # handle both uppercase/lowercase
                    remote_status = data.get('status') or data.get('Status') or data.get('status_text')
                    # Normalize
                    if isinstance(remote_status, str):
                        remote_status = remote_status.strip().lower()
                        if remote_status in ('success', 'successful', 'completed', 'paid'):
                            remote_status = 'completed'
                        elif remote_status in ('failed', 'failure', 'error'):
                            remote_status = 'failed'
                        elif remote_status in ('cancelled', 'canceled', 'cancel'):
                            remote_status = 'cancelled'
                        elif remote_status in ('timeout', 'timed_out', 'request_timeout'):
                            remote_status = 'timeout'
                        elif remote_status in ('queued', 'pending', 'initiated'):
                            remote_status = 'pending'
                    remote_reason = data.get('message') or data.get('description') or None
            
            return {
                'success': True,
                'remote_status': remote_status,
                'remote_reason': remote_reason,
                'remote_raw': remote_data
            }
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Error checking transaction status: {e}")
            return {
                'success': False,
                'message': f'Network error: {str(e)}'
            }
        except Exception as e:
            logger.error(f"Unexpected error checking status: {e}")
            return {
                'success': False,
                'message': f'Unexpected error: {str(e)}'
            }