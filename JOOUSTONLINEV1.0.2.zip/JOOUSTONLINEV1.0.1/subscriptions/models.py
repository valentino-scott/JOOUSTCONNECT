# subscriptions/models.py
from django.db import models
from django.conf import settings
from django.utils import timezone
from datetime import timedelta

class SubscriptionPlan(models.Model):
    TIER_CHOICES = [
        ('free', 'Free'),
        ('premium', 'Premium'),
    ]
    
    name = models.CharField(max_length=100)
    tier = models.CharField(max_length=20, choices=TIER_CHOICES, default='free')
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    duration_days = models.IntegerField(default=30)
    features = models.JSONField(default=list)
    
    def __str__(self):
        return self.name

class Subscription(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('canceled', 'Canceled'),
        ('expired', 'Expired'),
        ('pending', 'Pending Payment'),
    ]
    
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='subscriptions')
    plan = models.ForeignKey(SubscriptionPlan, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    start_date = models.DateTimeField(default=timezone.now)
    end_date = models.DateTimeField()
    is_active = models.BooleanField(default=False)
    
    # Payment fields
    checkout_request_id = models.CharField(max_length=100, blank=True, null=True)
    mpesa_receipt_number = models.CharField(max_length=50, blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.plan.name}"
    
    def save(self, *args, **kwargs):
        if not self.end_date and self.plan:
            self.end_date = timezone.now() + timedelta(days=self.plan.duration_days)
        super().save(*args, **kwargs)
    
    @property
    def is_valid(self):
        return self.is_active and self.status == 'active' and timezone.now() < self.end_date
    
    def activate_subscription(self):
        self.is_active = True
        self.status = 'active'
        self.save()
        
        # Don't update profile.is_premium if it's a computed property
        # The property will automatically reflect the active subscription status
        # If you need to store premium status, add a proper field to Profile model
    
    def cancel_subscription(self):
        self.is_active = False
        self.status = 'canceled'
        self.save()
        
        # Don't update profile.is_premium if it's a computed property
        # The property will automatically reflect the subscription status

class PaymentTransaction(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('successful', 'Successful'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]
    
    FAILURE_REASON_CHOICES = [
        ('insufficient_balance', 'Insufficient Balance'),
        ('wrong_pin', 'Wrong PIN'),
        ('cancelled', 'Cancelled by User'),
        ('timeout', 'Payment Timeout'),
        ('system_error', 'System Error'),
        ('invalid_account', 'Invalid Account'),
        ('daily_limit_exceeded', 'Daily Limit Exceeded'),
        ('transaction_limit_exceeded', 'Transaction Limit Exceeded'),
        ('duplicate_transaction', 'Duplicate Transaction'),
        ('other', 'Other'),
    ]
    
    # Core transaction fields
    subscription = models.ForeignKey(Subscription, on_delete=models.CASCADE, related_name='transactions')
    checkout_request_id = models.CharField(max_length=100, unique=True)
    external_reference = models.CharField(max_length=100, unique=True, blank=True, null=True)  # For PayHero reference
    
    # Payment details
    phone_number = models.CharField(max_length=15)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    failure_reason = models.CharField(max_length=50, choices=FAILURE_REASON_CHOICES, blank=True, null=True)
    
    # M-Pesa specific fields
    mpesa_receipt_number = models.CharField(max_length=50, blank=True, null=True)
    transaction_date = models.DateTimeField(blank=True, null=True)
    result_code = models.IntegerField(blank=True, null=True)
    result_description = models.TextField(blank=True, null=True)
    
    # Provider fields
    provider = models.CharField(max_length=20, default='m-pesa')  # m-pesa, airtel-money, etc.
    channel_id = models.IntegerField(blank=True, null=True)  # PayHero channel ID
    
    # Timestamps
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['checkout_request_id']),
            models.Index(fields=['external_reference']),
            models.Index(fields=['status']),
            models.Index(fields=['phone_number']),
        ]
    
    def __str__(self):
        return f"Payment {self.checkout_request_id} - {self.status}"
    
    @property
    def is_successful(self):
        return self.status == 'successful'
    
    @property
    def is_failed(self):
        return self.status == 'failed'
    
    @property
    def is_pending(self):
        return self.status == 'pending'
    
    @property
    def formatted_amount(self):
        return f"KES {self.amount}"
    
    @property
    def formatted_phone(self):
        """Format phone number for display"""
        if self.phone_number.startswith('254'):
            return f"+{self.phone_number}"
        elif self.phone_number.startswith('0'):
            return f"+254{self.phone_number[1:]}"
        return self.phone_number
    
    def mark_as_successful(self, mpesa_receipt_number=None, transaction_date=None):
        """Mark transaction as successful"""
        self.status = 'successful'
        self.failure_reason = ''
        if mpesa_receipt_number:
            self.mpesa_receipt_number = mpesa_receipt_number
        if transaction_date:
            self.transaction_date = transaction_date
        self.save()
        
        # Activate the associated subscription
        if self.subscription:
            self.subscription.activate_subscription()
    
    def mark_as_failed(self, failure_reason='other', result_code=None, result_description=None):
        """Mark transaction as failed with specific reason"""
        self.status = 'failed'
        self.failure_reason = failure_reason
        if result_code:
            self.result_code = result_code
        if result_description:
            self.result_description = result_description
        self.save()
        
        # Update subscription status
        if self.subscription:
            self.subscription.status = 'pending'
            self.subscription.is_active = False
            self.subscription.save()
    
    def mark_as_cancelled(self):
        """Mark transaction as cancelled by user"""
        self.status = 'cancelled'
        self.failure_reason = 'cancelled'
        self.save()
    
    def get_failure_message(self):
        """Get user-friendly failure message"""
        failure_messages = {
            'insufficient_balance': 'Your M-Pesa account has insufficient funds. Please top up and try again.',
            'wrong_pin': 'The PIN you entered was incorrect. Please try again with the correct PIN.',
            'cancelled': 'You cancelled the payment request. No amount was deducted.',
            'timeout': 'The payment request timed out. Please try again.',
            'system_error': 'A temporary system error occurred. Please try again in a few minutes.',
            'invalid_account': 'The phone number provided is not registered with M-Pesa.',
            'daily_limit_exceeded': 'You have exceeded your daily transaction limit.',
            'transaction_limit_exceeded': 'This transaction exceeds your account limits.',
            'duplicate_transaction': 'A similar transaction was recently processed.',
            'other': 'Payment failed. Please try again or contact support.',
        }
        return failure_messages.get(self.failure_reason, failure_messages['other'])
    
    def get_status_display_info(self):
        """Get status display information for templates"""
        status_info = {
            'pending': {
                'icon': 'fas fa-spinner fa-spin',
                'color': '#f59e0b',
                'title': 'Processing Payment',
                'description': 'Please check your phone and enter your M-Pesa PIN to complete the transaction.'
            },
            'successful': {
                'icon': 'fas fa-check-circle',
                'color': '#10b981',
                'title': 'Payment Successful!',
                'description': 'Your payment was processed successfully. Your subscription is now active.'
            },
            'failed': {
                'icon': 'fas fa-times-circle',
                'color': '#ef4444',
                'title': 'Payment Failed',
                'description': self.get_failure_message()
            },
            'cancelled': {
                'icon': 'fas fa-ban',
                'color': '#6b7280',
                'title': 'Payment Cancelled',
                'description': 'The payment was cancelled. No amount was deducted from your account.'
            }
        }
        return status_info.get(self.status, status_info['pending'])

# Signal to handle subscription activation
from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=PaymentTransaction)
def handle_payment_status_change(sender, instance, **kwargs):
    """
    Automatically handle subscription activation when payment is successful
    """
    if instance.status == 'successful' and instance.subscription:
        instance.subscription.activate_subscription()