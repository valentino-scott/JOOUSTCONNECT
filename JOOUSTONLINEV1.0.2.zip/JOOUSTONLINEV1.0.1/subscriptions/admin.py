# subscriptions/admin.py
from django.contrib import admin
from .models import Subscription, PaymentTransaction, SubscriptionPlan

@admin.register(SubscriptionPlan)
class SubscriptionPlanAdmin(admin.ModelAdmin):
    list_display = ['name', 'tier', 'price', 'duration_days']
    list_filter = ['tier']
    search_fields = ['name']

@admin.register(Subscription)
class SubscriptionAdmin(admin.ModelAdmin):
    list_display = ['user', 'plan', 'status', 'is_active', 'start_date', 'end_date']
    list_filter = ['status', 'is_active', 'plan', 'start_date']
    search_fields = ['user__username', 'user__email']
    readonly_fields = ['created_at', 'updated_at']

@admin.register(PaymentTransaction)
class PaymentTransactionAdmin(admin.ModelAdmin):
    list_display = ['subscription', 'phone_number', 'amount', 'status', 'created_at']
    list_filter = ['status', 'created_at']
    search_fields = ['checkout_request_id', 'phone_number', 'mpesa_receipt_number']
    readonly_fields = ['created_at', 'updated_at']