def user_status(request):
    """Add user status information to template context"""
    if request.user.is_authenticated:
        return {
            'user_can_post': request.user.can_post if hasattr(request.user, 'can_post') else True,
            'user_can_interact': request.user.can_interact if hasattr(request.user, 'can_interact') else True,
            'user_can_follow': request.user.can_follow if hasattr(request.user, 'can_follow') else True,
            'user_is_suspended': request.user.is_currently_suspended if hasattr(request.user, 'is_currently_suspended') else False,
            'user_is_limited': request.user.is_currently_limited if hasattr(request.user, 'is_currently_limited') else False,
        }
    return {}