from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

app_name = 'accounts'

urlpatterns = [
    # Authentication URLs
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('google-login/', views.google_login_redirect, name='google_login'),
    
    # Password reset URLs
    path('password-reset/', 
         auth_views.PasswordResetView.as_view(
             template_name='accounts/password_reset.html',
             email_template_name='accounts/password_reset_email.html',
             subject_template_name='accounts/password_reset_subject.txt',
             success_url='/accounts/password-reset/done/'
         ), 
         name='password_reset'),
    path('password-reset/done/', 
         auth_views.PasswordResetDoneView.as_view(
             template_name='accounts/password_reset_done.html'
         ), 
         name='password_reset_done'),
    path('password-reset-confirm/<uidb64>/<token>/', 
         auth_views.PasswordResetConfirmView.as_view(
             template_name='accounts/password_reset_confirm.html',
             success_url='/accounts/password-reset-complete/'
         ), 
         name='password_reset_confirm'),
    path('password-reset-complete/', 
         auth_views.PasswordResetCompleteView.as_view(
             template_name='accounts/password_reset_complete.html'
         ), 
         name='password_reset_complete'),
    
    # Profile and social URLs
    path('profile/<str:username>/', views.profile_view, name='profile'),
    path('edit-profile/', views.edit_profile_view, name='edit_profile'),
    path('follow/<str:username>/', views.follow_user, name='follow'),
    path('followers/<str:username>/', views.followers_list, name='followers'),
    path('following/<str:username>/', views.following_list, name='following'),
    path('search/', views.search_users, name='search'),
    path('deactivate/', views.deactivate_account, name='deactivate'),
    path('reactivate/', views.reactivate_account, name='reactivate'),
    
    # NEW: Flagging and Suspension System URLs
    path('suspended/', views.suspended_page, name='suspended'),
    path('limited/', views.limited_page, name='limited'),
    
    # NEW: Admin moderation URLs
    path('admin/users/', views.admin_user_list, name='admin_user_list'),
    path('admin/flag-user/<int:user_id>/', views.admin_flag_user, name='admin_flag_user'),
    path('admin/suspend-user/<int:user_id>/', views.admin_suspend_user, name='admin_suspend_user'),
    path('admin/limit-user/<int:user_id>/', views.admin_limit_user, name='admin_limit_user'),
    path('admin/remove-restrictions/<int:user_id>/', views.admin_remove_restrictions, name='admin_remove_restrictions'),
]