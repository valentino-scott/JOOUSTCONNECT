from django.shortcuts import redirect
from django.urls import reverse

class UserStatusMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.user.is_authenticated:
            # Check if user has suspension/limitation attributes
            if hasattr(request.user, 'is_currently_suspended') and request.user.is_currently_suspended:
                # Allow access to suspension page and logout
                allowed_paths = [
                    '/accounts/suspended/',
                    '/accounts/logout/',
                    '/admin/logout/',
                ]
                
                if not any(request.path.startswith(path) for path in allowed_paths):
                    return redirect('accounts:suspended_page')
            
            # Check limitations for POST requests to core app
            if (request.method == 'POST' and 
                hasattr(request.user, 'is_currently_limited') and 
                request.user.is_currently_limited):
                # Check if this is a post creation or interaction
                if any(path in request.path for path in ['/post/', '/like/', '/comment/', '/follow/']):
                    from django.contrib import messages
                    messages.error(request, "Your account is currently limited. Please try again later.")
                    return redirect('accounts:limited_page')
        
        response = self.get_response(request)
        return response