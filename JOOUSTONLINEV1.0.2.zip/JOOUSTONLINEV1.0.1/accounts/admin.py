from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.utils.html import format_html
from .models import User, Profile, Follow

class ProfileInline(admin.StackedInline):
    model = Profile
    can_delete = False
    verbose_name_plural = 'Profile'

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 
                   'is_active_account', 'get_account_status', 'flags_count', 
                   'suspension_end', 'date_joined')
    
    list_filter = ('is_staff', 'is_active_account', 'is_flagged', 'is_suspended', 
                  'is_limited', 'date_joined')
    
    search_fields = ('username', 'email', 'first_name', 'last_name')
    ordering = ('-date_joined',)
    
    fieldsets = UserAdmin.fieldsets + (
        ('Account Status', {
            'fields': ('is_active_account', 'is_flagged', 'flags_count', 'is_suspended', 
                      'suspension_reason', 'suspension_end', 'is_limited', 
                      'limitation_reason', 'limitation_end')
        }),
    )
    
    readonly_fields = ('flags_count',)
    
    inlines = [ProfileInline]
    
    actions = ['flag_users', 'suspend_users_7_days', 'suspend_users_30_days', 
               'limit_users', 'remove_restrictions', 'deactivate_users', 'activate_users']
    
    def get_account_status(self, obj):
        """Display account status with colored badges"""
        if obj.is_currently_suspended:
            return format_html('<span style="color: red; font-weight: bold;">⛔ SUSPENDED</span>')
        elif obj.is_currently_limited:
            return format_html('<span style="color: orange; font-weight: bold;">⚠️ LIMITED</span>')
        elif obj.is_flagged:
            return format_html('<span style="color: #ff6b00; font-weight: bold;">🚩 FLAGGED</span>')
        elif not obj.is_active_account:
            return format_html('<span style="color: gray; font-weight: bold;">❌ DEACTIVATED</span>')
        else:
            return format_html('<span style="color: green; font-weight: bold;">✅ ACTIVE</span>')
    get_account_status.short_description = 'Account Status'
    
    def suspension_end(self, obj):
        """Display suspension end date"""
        if obj.suspension_end:
            from django.utils import timezone
            if obj.suspension_end > timezone.now():
                return obj.suspension_end.strftime("%Y-%m-%d %H:%M")
            else:
                return format_html('<span style="color: gray;">Expired</span>')
        return "-"
    suspension_end.short_description = 'Suspension Ends'
    
    # ACTIONS
    def flag_users(self, request, queryset):
        for user in queryset:
            user.flag_user("Flagged by admin")
        self.message_user(request, f"{queryset.count()} users have been flagged.")
    flag_users.short_description = "🚩 Flag selected users"
    
    def suspend_users_7_days(self, request, queryset):
        for user in queryset:
            user.suspend_user(7, "Suspended by admin for 7 days")
        self.message_user(request, f"{queryset.count()} users have been suspended for 7 days.")
    suspend_users_7_days.short_description = "⛔ Suspend for 7 days"
    
    def suspend_users_30_days(self, request, queryset):
        for user in queryset:
            user.suspend_user(30, "Suspended by admin for 30 days")
        self.message_user(request, f"{queryset.count()} users have been suspended for 30 days.")
    suspend_users_30_days.short_description = "⛔ Suspend for 30 days"
    
    def limit_users(self, request, queryset):
        for user in queryset:
            user.limit_user(3, "Limited by admin for 3 days")
        self.message_user(request, f"{queryset.count()} users have been limited for 3 days.")
    limit_users.short_description = "⚠️ Limit for 3 days"
    
    def remove_restrictions(self, request, queryset):
        for user in queryset:
            user.remove_restrictions()
        self.message_user(request, f"✅ Restrictions removed from {queryset.count()} users.")
    remove_restrictions.short_description = "✅ Remove all restrictions"
    
    def deactivate_users(self, request, queryset):
        for user in queryset:
            user.is_active_account = False
            user.save()
        self.message_user(request, f"❌ {queryset.count()} users have been deactivated.")
    deactivate_users.short_description = "❌ Deactivate users"
    
    def activate_users(self, request, queryset):
        for user in queryset:
            user.is_active_account = True
            user.save()
        self.message_user(request, f"✅ {queryset.count()} users have been activated.")
    activate_users.short_description = "✅ Activate users"
    def get_account_status(self, obj):
        """Safe account status display without auto-saving"""
        if obj.is_suspended and obj.suspension_end and obj.suspension_end > timezone.now():
            return format_html('<span style="color: red; font-weight: bold;">⛔ SUSPENDED</span>')
        elif obj.is_limited and obj.limitation_end and obj.limitation_end > timezone.now():
            return format_html('<span style="color: orange; font-weight: bold;">⚠️ LIMITED</span>')
        elif obj.is_flagged:
            return format_html('<span style="color: #ff6b00; font-weight: bold;">🚩 FLAGGED</span>')
        elif not obj.is_active_account:
            return format_html('<span style="color: gray; font-weight: bold;">❌ DEACTIVATED</span>')
        else:
            return format_html('<span style="color: green; font-weight: bold;">✅ ACTIVE</span>')
    get_account_status.short_description = 'Account Status'

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'course', 'department', 'year', 'get_account_status', 'created_at')
    list_filter = ('year', 'created_at', 'user__is_suspended', 'user__is_limited', 'user__is_flagged')
    search_fields = ('user__username', 'user__email', 'course', 'department')
    raw_id_fields = ('user',)
    
    def get_account_status(self, obj):
        """Display user account status in profile admin"""
        return obj.account_status.upper()
    get_account_status.short_description = 'Account Status'

@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    list_display = ('follower', 'following', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('follower__username', 'following__username')
    raw_id_fields = ('follower', 'following')

# Unregister the existing User admin and register with custom admin
from django.contrib.auth import get_user_model
User = get_user_model()

# Check if User is already registered and unregister it
try:
    admin.site.unregister(User)
except admin.sites.NotRegistered:
    pass

admin.site.register(User, CustomUserAdmin)