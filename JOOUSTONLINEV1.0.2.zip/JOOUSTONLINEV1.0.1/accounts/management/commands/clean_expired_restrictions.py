from django.core.management.base import BaseCommand
from django.utils import timezone
from accounts.models import User

class Command(BaseCommand):
    help = 'Remove expired suspensions and limitations'
    
    def handle(self, *args, **options):
        # Get users with active suspensions or limitations
        users_to_check = User.objects.filter(
            models.Q(is_suspended=True) | models.Q(is_limited=True)
        )
        
        cleaned_count = 0
        for user in users_to_check:
            if user.clean_expired_restrictions():
                cleaned_count += 1
        
        self.stdout.write(
            self.style.SUCCESS(f'Successfully cleaned {cleaned_count} users with expired restrictions')
        )