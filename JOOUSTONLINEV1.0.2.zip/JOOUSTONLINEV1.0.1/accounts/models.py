from django.db import models
from django.contrib.auth.models import AbstractUser
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils import timezone
from datetime import timedelta

class User(AbstractUser):
    """Extended User model for JOOUST CONNECT students"""
    email = models.EmailField(unique=True)
    is_active_account = models.BooleanField(default=True)
    
    # NEW FIELDS FOR FLAGGING/SUSPENSION
    is_flagged = models.BooleanField(default=False)
    is_suspended = models.BooleanField(default=False)
    suspension_reason = models.TextField(blank=True, null=True)
    suspension_end = models.DateTimeField(blank=True, null=True)
    is_limited = models.BooleanField(default=False)
    limitation_reason = models.TextField(blank=True, null=True)
    limitation_end = models.DateTimeField(blank=True, null=True)
    flags_count = models.IntegerField(default=0)
    
    def __str__(self):
        return self.username
    
    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}".strip() or self.username
    
    # FIXED: Properties without auto-saving to prevent database locks
    @property
    def is_currently_suspended(self):
        """Check if user is currently suspended (with time validation)"""
        if not self.is_suspended:
            return False
        if self.suspension_end and timezone.now() > self.suspension_end:
            return False
        return True
    
    @property
    def is_currently_limited(self):
        """Check if user is currently limited (with time validation)"""
        if not self.is_limited:
            return False
        if self.limitation_end and timezone.now() > self.limitation_end:
            return False
        return True
    
    @property
    def can_post(self):
        """Check if user can create posts"""
        return not self.is_currently_suspended and not self.is_currently_limited
    
    @property
    def can_interact(self):
        """Check if user can like, comment, share"""
        return not self.is_currently_suspended and not self.is_currently_limited
    
    @property
    def can_follow(self):
        """Check if user can follow others"""
        return not self.is_currently_suspended and not self.is_currently_limited
    
    # NEW: Method to manually clean expired restrictions
    def clean_expired_restrictions(self):
        """Manually remove expired restrictions - call this when needed"""
        needs_save = False
        
        if self.is_suspended and self.suspension_end and timezone.now() > self.suspension_end:
            self.is_suspended = False
            self.suspension_end = None
            self.suspension_reason = ""
            needs_save = True
            
        if self.is_limited and self.limitation_end and timezone.now() > self.limitation_end:
            self.is_limited = False
            self.limitation_end = None
            self.limitation_reason = ""
            needs_save = True
            
        if needs_save:
            self.save()
        return needs_save
    
    # NEW METHODS FOR MODERATION
    def flag_user(self, reason=""):
        """Flag user for moderation review"""
        self.is_flagged = True
        self.flags_count += 1
        self.save()
    
    def suspend_user(self, duration_days=7, reason=""):
        """Suspend user for specified days"""
        self.is_suspended = True
        self.suspension_end = timezone.now() + timedelta(days=duration_days)
        self.suspension_reason = reason
        self.save()
    
    def limit_user(self, duration_days=3, reason=""):
        """Apply temporary limitations to user"""
        self.is_limited = True
        self.limitation_end = timezone.now() + timedelta(days=duration_days)
        self.limitation_reason = reason
        self.save()
    
    def remove_restrictions(self):
        """Remove all restrictions from user"""
        self.is_flagged = False
        self.is_suspended = False
        self.is_limited = False
        self.suspension_end = None
        self.limitation_end = None
        self.suspension_reason = ""
        self.limitation_reason = ""
        self.save()


class Profile(models.Model):
    """User profile with academic and social information"""
    YEAR_CHOICES = [
        ('1', 'Year 1'),
        ('2', 'Year 2'),
        ('3', 'Year 3'),
        ('4', 'Year 4'),
        ('5', 'Year 5+'),
    ]
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    bio = models.TextField(max_length=500, blank=True)
    course = models.CharField(max_length=200, blank=True)
    department = models.CharField(max_length=200, blank=True)
    year = models.CharField(max_length=1, choices=YEAR_CHOICES, blank=True)
    photo = models.ImageField(upload_to='profile_photos/', blank=True, null=True)
    cover_photo = models.ImageField(upload_to='cover_photos/', blank=True, null=True)
    location = models.CharField(max_length=100, blank=True)
    website = models.URLField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s profile"
    
    @property
    def is_premium(self):
        """Check if user has active premium subscription"""
        return hasattr(self.user, 'subscription') and self.user.subscription.is_active
    
    @property
    def has_blue_tick(self):
        """Blue tick verification for premium users"""
        return self.is_premium
    
    def followers_count(self):
        return self.user.followers.count()
    
    def following_count(self):
        return self.user.following.count()
    
    # FIXED: Use safe status check without auto-saving
    @property
    def account_status(self):
        """Get user account status for display"""
        user = self.user
        
        # Safe check without auto-saving
        if user.is_suspended and user.suspension_end and user.suspension_end > timezone.now():
            return "suspended"
        elif user.is_limited and user.limitation_end and user.limitation_end > timezone.now():
            return "limited"
        elif user.is_flagged:
            return "flagged"
        else:
            return "active"


class Follow(models.Model):
    """Follow relationship between users"""
    follower = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following')
    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='followers')
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ('follower', 'following')
        ordering = ['-created_at']
    
    def __str__(self):
        # FIXED: Safe string representation that won't cause query issues
        try:
            return f"{self.follower.username} follows {self.following.username}"
        except (AttributeError, User.DoesNotExist):
            return "Follow relationship"
    
    def safe_str(self):
        """Safe string representation for use in templates"""
        try:
            return f"{self.follower.username} follows {self.following.username}"
        except (AttributeError, User.DoesNotExist):
            return "Follow relationship"


@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    """Automatically create profile when user is created"""
    if created:
        Profile.objects.create(user=instance)


@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    """Save profile when user is saved"""
    if hasattr(instance, 'profile'):
        instance.profile.save()