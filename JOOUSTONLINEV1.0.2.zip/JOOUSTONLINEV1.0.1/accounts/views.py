from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.http import JsonResponse, HttpResponseForbidden
from django.utils import timezone
from django.contrib.admin.views.decorators import staff_member_required
import json
from .models import User, Profile, Follow
from .forms import UserRegistrationForm, UserLoginForm, ProfileEditForm

# NEW: Middleware-style decorator for user status checking
def check_user_status(view_func):
    """Decorator to check user status before allowing access to views"""
    def wrapper(request, *args, **kwargs):
        if request.user.is_authenticated:
            # Check suspension
            if hasattr(request.user, 'is_currently_suspended') and request.user.is_currently_suspended:
                return redirect('accounts:suspended')
            
            # Check limitations for POST requests
            if (request.method == 'POST' and 
                hasattr(request.user, 'is_currently_limited') and 
                request.user.is_currently_limited):
                messages.error(request, "Your account is currently limited. Please try again later.")
                return redirect('accounts:limited')
        
        return view_func(request, *args, **kwargs)
    return wrapper


def register_view(request):
    """User registration view"""
    if request.user.is_authenticated:
        return redirect('core:home')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            # Save user but do not log in yet
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password1'])  # Hash the password
            user.save()

            # Authenticate to attach backend
            authenticated_user = authenticate(username=user.username, password=form.cleaned_data['password1'])
            if authenticated_user is not None:
                login(request, authenticated_user)
                messages.success(request, 'Welcome to JOOUST CONNECT! Your account has been created.')
                return redirect('core:home')
            else:
                messages.error(request, 'Authentication failed. Please log in manually.')
                return redirect('accounts:login')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'accounts/register.html', {'form': form})


def login_view(request):
    """User login view"""
    if request.user.is_authenticated:
        return redirect('core:home')
    
    if request.method == 'POST':
        form = UserLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                if user.is_active_account:
                    # NEW: Check if user is suspended
                    if hasattr(user, 'is_currently_suspended') and user.is_currently_suspended:
                        messages.error(request, 'Your account has been suspended.')
                        return redirect('accounts:suspended')
                    
                    login(request, user)
                    messages.success(request, f'Welcome back, {user.username}!')
                    return redirect('core:home')
                else:
                    messages.error(request, 'This account has been deactivated.')
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = UserLoginForm()
    
    return render(request, 'accounts/login.html', {'form': form})


def google_login_redirect(request):
    """Redirect to allauth Google login with error handling"""
    if request.user.is_authenticated:
        return redirect('core:home')
    
    try:
        # Check if Google OAuth is configured
        from allauth.socialaccount.models import SocialApp
        google_app = SocialApp.objects.filter(provider='google').first()
        
        if not google_app:
            messages.error(request, 'Google OAuth is not configured. Please use email login.')
            return redirect('accounts:login')
        
        return redirect('/accounts/google/login/')
    except Exception as e:
        messages.error(request, 'Google OAuth is temporarily unavailable. Please use email login.')
        return redirect('accounts:login')


@login_required
def logout_view(request):
    """User logout view"""
    logout(request)
    messages.success(request, 'You have been logged out successfully.')
    return redirect('accounts:login')


@login_required
@check_user_status
def profile_view(request, username):
    """View user profile"""
    user = get_object_or_404(User, username=username)
    profile = user.profile
    
    is_following = False
    if request.user.is_authenticated and request.user != user:
        is_following = Follow.objects.filter(follower=request.user, following=user).exists()
    
    posts = user.posts.all().order_by('-created_at')[:20]
    followers_count = user.followers.count()
    following_count = user.following.count()
    posts_count = user.posts.count()
    
    context = {
        'profile_user': user,
        'profile': profile,
        'is_following': is_following,
        'posts': posts,
        'followers_count': followers_count,
        'following_count': following_count,
        'posts_count': posts_count,
    }
    
    return render(request, 'accounts/profile.html', context)


@login_required
@check_user_status
def edit_profile_view(request):
    """Edit user profile"""
    profile = request.user.profile
    
    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully!')
            return redirect('accounts:profile', username=request.user.username)
    else:
        form = ProfileEditForm(instance=profile)
    
    return render(request, 'accounts/edit_profile.html', {'form': form})


@login_required
@check_user_status
def follow_user(request, username):
    """Follow or unfollow a user"""
    if request.method == 'POST':
        user_to_follow = get_object_or_404(User, username=username)
        
        if user_to_follow == request.user:
            return JsonResponse({'error': 'You cannot follow yourself'}, status=400)
        
        # NEW: Check if user can follow (not limited)
        if hasattr(request.user, 'can_follow') and not request.user.can_follow:
            return JsonResponse({
                'error': 'Your account is currently limited. You cannot follow users.'
            }, status=403)
        
        # Parse JSON body to get the action
        try:
            if request.content_type == 'application/json':
                data = json.loads(request.body)
                action = data.get('action', 'follow')
            else:
                action = request.POST.get('action', 'follow')
        except (json.JSONDecodeError, ValueError):
            action = 'follow'
        
        # Check current follow status
        current_follow_status = Follow.objects.filter(
            follower=request.user, 
            following=user_to_follow
        ).exists()
        
        # Handle follow/unfollow based on action
        if action == 'unfollow' and current_follow_status:
            # Unfollow
            Follow.objects.filter(
                follower=request.user, 
                following=user_to_follow
            ).delete()
            return JsonResponse({
                'status': 'unfollowed',
                'followers_count': user_to_follow.followers.count(),
                'remove_from_suggestions': False
            })
        elif action == 'follow' and not current_follow_status:
            # Follow
            Follow.objects.create(
                follower=request.user,
                following=user_to_follow
            )
            
            # Create notification
            try:
                from notifications.models import Notification
                Notification.objects.create(
                    recipient=user_to_follow,
                    sender=request.user,
                    notification_type='follow',
                    text=f'{request.user.username} started following you'
                )
            except Exception as e:
                print(f"Notification creation failed: {e}")
                # Continue even if notification fails
            
            return JsonResponse({
                'status': 'followed',
                'followers_count': user_to_follow.followers.count(),
                'remove_from_suggestions': True
            })
        else:
            # No change needed - already in desired state
            return JsonResponse({
                'status': 'no_change',
                'followers_count': user_to_follow.followers.count(),
                'message': 'Already in desired follow state'
            })
    
    return JsonResponse({'error': 'Invalid request method'}, status=400)


@login_required
@check_user_status
def followers_list(request, username):
    """List user followers"""
    user = get_object_or_404(User, username=username)
    followers = Follow.objects.filter(following=user).select_related('follower__profile')
    
    return render(request, 'accounts/followers_list.html', {
        'profile_user': user,
        'followers': followers
    })


@login_required
@check_user_status
def following_list(request, username):
    """List users being followed"""
    user = get_object_or_404(User, username=username)
    following = Follow.objects.filter(follower=user).select_related('following__profile')
    
    return render(request, 'accounts/following_list.html', {
        'profile_user': user,
        'following': following
    })


@login_required
@check_user_status
def search_users(request):
    """Search for users"""
    query = request.GET.get('q', '').strip()
    users = []
    
    if query:
        users = User.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query) |
            Q(profile__course__icontains=query) |
            Q(profile__department__icontains=query)
        ).exclude(id=request.user.id).select_related('profile')[:20]
    
    return render(request, 'accounts/search.html', {
        'query': query,
        'users': users
    })


def get_suggested_users(request):
    """Get users to suggest for following - EXCLUDES already followed users"""
    if not request.user.is_authenticated:
        return User.objects.none()
    
    # Get IDs of users the current user is already following
    following_ids = Follow.objects.filter(
        follower=request.user
    ).values_list('following_id', flat=True)
    
    # Exclude: current user, already followed users, and inactive accounts
    suggested_users = User.objects.filter(
        is_active_account=True
    ).exclude(
        id=request.user.id
    ).exclude(
        id__in=following_ids
    ).select_related('profile').order_by('?')[:5]  # Random 5 users
    
    return suggested_users


@login_required
def deactivate_account(request):
    """Deactivate user account"""
    if request.method == 'POST':
        request.user.is_active_account = False
        request.user.save()
        logout(request)
        messages.success(request, 'Your account has been deactivated.')
        return redirect('accounts:login')
    
    return render(request, 'accounts/deactivate_confirm.html')


@login_required
def reactivate_account(request):
    """Reactivate user account"""
    if request.method == 'POST':
        request.user.is_active_account = True
        request.user.save()
        messages.success(request, 'Your account has been reactivated!')
        return redirect('core:home')
    
    return render(request, 'accounts/reactivate_confirm.html')


# NEW VIEWS FOR FLAGGING/SUSPENSION SYSTEM

@login_required
def suspended_page(request):
    """Display suspension information"""
    if not hasattr(request.user, 'is_currently_suspended') or not request.user.is_currently_suspended:
        return redirect('core:home')
    
    context = {
        'suspension_reason': request.user.suspension_reason,
        'suspension_end': request.user.suspension_end,
        'time_remaining': request.user.suspension_end - timezone.now() if request.user.suspension_end else None,
    }
    return render(request, 'accounts/suspended.html', context)


@login_required
def limited_page(request):
    """Display limitation information"""
    if not hasattr(request.user, 'is_currently_limited') or not request.user.is_currently_limited:
        return redirect('core:home')
    
    context = {
        'limitation_reason': request.user.limitation_reason,
        'limitation_end': request.user.limitation_end,
        'time_remaining': request.user.limitation_end - timezone.now() if request.user.limitation_end else None,
    }
    return render(request, 'accounts/limited.html', context)


# NEW: ADMIN/MODERATION VIEWS
@staff_member_required
def admin_user_list(request):
    """Admin view to see all users with their status"""
    users = User.objects.all().select_related('profile').order_by('-date_joined')
    
    # Filter by status if provided
    status_filter = request.GET.get('status', '')
    if status_filter == 'suspended':
        users = [user for user in users if user.is_currently_suspended]
    elif status_filter == 'limited':
        users = [user for user in users if user.is_currently_limited]
    elif status_filter == 'flagged':
        users = users.filter(is_flagged=True)
    elif status_filter == 'active':
        users = [user for user in users if not user.is_currently_suspended and not user.is_currently_limited and not user.is_flagged]
    
    return render(request, 'accounts/admin/user_list.html', {
        'users': users,
        'current_filter': status_filter
    })


@staff_member_required
def admin_flag_user(request, user_id):
    """Admin view to flag a user"""
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        reason = request.POST.get('reason', 'Violation reported')
        user.flag_user(reason)
        messages.success(request, f'User {user.username} has been flagged.')
    
    return redirect('accounts:admin_user_list')


@staff_member_required
def admin_suspend_user(request, user_id):
    """Admin view to suspend a user"""
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        duration = int(request.POST.get('duration', 7))
        reason = request.POST.get('reason', 'Violation of terms of service')
        user.suspend_user(duration, reason)
        messages.success(request, f'User {user.username} has been suspended for {duration} days.')
    
    return redirect('accounts:admin_user_list')


@staff_member_required
def admin_limit_user(request, user_id):
    """Admin view to limit a user"""
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        duration = int(request.POST.get('duration', 3))
        reason = request.POST.get('reason', 'Temporary restrictions applied')
        user.limit_user(duration, reason)
        messages.success(request, f'User {user.username} has been limited for {duration} days.')
    
    return redirect('accounts:admin_user_list')


@staff_member_required
def admin_remove_restrictions(request, user_id):
    """Admin view to remove all restrictions from a user"""
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        user.remove_restrictions()
        messages.success(request, f'All restrictions have been removed from {user.username}.')
    
    return redirect('accounts:admin_user_list')