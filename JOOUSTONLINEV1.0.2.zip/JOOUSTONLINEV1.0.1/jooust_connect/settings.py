"""
Django settings for jooust_connect project.

JOOUST CONNECT - Social Networking Platform for JOOUST Students
"""

from pathlib import Path
from decouple import config

# ---------------------------------------
# BASE CONFIG
# ---------------------------------------
BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = config(
    'SECRET_KEY',
    default='django-insecure-qe#kkf1_7vx%@-0equaa1lk7i74454n^=kosgwt@r754_s0qx2'
)

DEBUG = config('DEBUG', default=True, cast=bool)

ALLOWED_HOSTS = ['localhost', '127.0.0.1', '0.0.0.0', 'unfasciated-addisyn-arduously.ngrok-free.dev', '10.14.65.2']

# ---------------------------------------
# INSTALLED APPS
# ---------------------------------------
SITE_ID = 1
INSTALLED_APPS = [
    # Django core apps
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    'django.contrib.sites',

    # Third-party apps
    'channels',
    'allauth',
    'allauth.account',
    'allauth.socialaccount',
    'allauth.socialaccount.providers.google',

    # Project apps
    'core',
    'accounts',
    'posts',
    'messaging',
    'notifications',
    'subscriptions',
    'reports',
    'announcements',

    # Optional dev tools
    'django_extensions',
]

# ---------------------------------------
# MIDDLEWARE
# ---------------------------------------
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',  # For static files
    'django.contrib.sessions.middleware.SessionMiddleware',
    'allauth.account.middleware.AccountMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'accounts.middleware.UserStatusMiddleware',
]

# ---------------------------------------
# URLS & TEMPLATES
# ---------------------------------------
ROOT_URLCONF = 'jooust_connect.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.media',
                'core.context_processors.sidebar_data',
                'core.context_processors.notification_counts',
                'accounts.context_processors.user_status',
            ],
        },
    },
]

# ---------------------------------------
# WSGI / ASGI CONFIG
# ---------------------------------------
WSGI_APPLICATION = 'jooust_connect.wsgi.application'
ASGI_APPLICATION = 'jooust_connect.asgi.application'

# ---------------------------------------
# CHANNEL LAYERS
# ---------------------------------------
CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels.layers.InMemoryChannelLayer",
    },
}

# ---------------------------------------
# DATABASE
# ---------------------------------------
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

# ---------------------------------------
# AUTH / LOGIN SETTINGS
# ---------------------------------------
AUTH_USER_MODEL = 'accounts.User'
LOGIN_URL = 'accounts:login'
LOGIN_REDIRECT_URL = 'core:home'
LOGOUT_REDIRECT_URL = 'accounts:login'

# ---------------------------------------
# PASSWORD VALIDATION
# ---------------------------------------
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# ---------------------------------------
# AUTHENTICATION BACKENDS
# ---------------------------------------
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'allauth.account.auth_backends.AuthenticationBackend',
]

# ---------------------------------------
# ALLAUTH SETTINGS (CONSOLIDATED)
# ---------------------------------------
ACCOUNT_EMAIL_REQUIRED = True
ACCOUNT_USERNAME_REQUIRED = False
ACCOUNT_AUTHENTICATION_METHOD = 'email'
ACCOUNT_EMAIL_VERIFICATION = 'optional'
ACCOUNT_LOGIN_METHODS = ['email']
ACCOUNT_SESSION_REMEMBER = True
ACCOUNT_LOGOUT_ON_GET = True
ACCOUNT_LOGOUT_REDIRECT_URL = '/accounts/login/'
ACCOUNT_DEFAULT_HTTP_PROTOCOL = 'https' if not DEBUG else 'http'

# Social Account Settings
SOCIALACCOUNT_LOGIN_ON_GET = True
SOCIALACCOUNT_AUTO_SIGNUP = True
SOCIALACCOUNT_EMAIL_VERIFICATION = 'optional'
SOCIALACCOUNT_EMAIL_REQUIRED = True
SOCIALACCOUNT_QUERY_EMAIL = True
SOCIALACCOUNT_STORE_TOKENS = True

# OAuth Providers
SOCIALACCOUNT_PROVIDERS = {
    'google': {
        'SCOPE': [
            'profile',
            'email',
        ],
        'AUTH_PARAMS': {
            'access_type': 'online',
        },
        'APP': {
            'client_id': config('GOOGLE_OAUTH_CLIENT_ID', default=''),
            'secret': config('GOOGLE_OAUTH_CLIENT_SECRET', default=''),
            'key': ''
        }
    }
}

# ---------------------------------------
# EMAIL CONFIGURATION
# ---------------------------------------
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'mail.jooustonline.site'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'noreply@jooustonline.site'
EMAIL_HOST_PASSWORD = 'ScottVal#'
DEFAULT_FROM_EMAIL = 'noreply@jooustonline.site'
SERVER_EMAIL = 'noreply@jooustonline.site'

# Email subjects
EMAIL_SUBJECT_PREFIX = '[JOOUST CONNECT] '

# ---------------------------------------
# SECURITY SETTINGS
# ---------------------------------------
# SECURE_SSL_REDIRECT = False  # Keep False for local testing
# SESSION_COOKIE_SECURE = False
# CSRF_COOKIE_SECURE = False

# ---------------------------------------
# SITE CONFIGURATION
# ---------------------------------------
SITE_DOMAIN = 'jooustonline.site' if not DEBUG else 'localhost:8000'
SITE_NAME = 'JOOUST CONNECT'

# ---------------------------------------
# LOCALIZATION
# ---------------------------------------
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Africa/Nairobi'
USE_I18N = True
USE_TZ = True
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# ---------------------------------------
# STATIC & MEDIA FILES - SIMPLIFIED
# ---------------------------------------
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

# WhiteNoise configuration
STORAGES = {
    "staticfiles": {
        "BACKEND": "whitenoise.storage.CompressedStaticFilesStorage",
    },
}

# ---------------------------------------
# PAYHERO CONFIGURATION
# ---------------------------------------
PAYHERO_API_USERNAME = config('PAYHERO_API_USERNAME', default='')
PAYHERO_API_PASSWORD = config('PAYHERO_API_PASSWORD', default='')
PAYHERO_CHANNEL_ID = config('PAYHERO_CHANNEL_ID', default='')
PAYHERO_CALLBACK_URL = config('PAYHERO_CALLBACK_URL', default='https://your-ngrok-url.ngrok.io/subscriptions/payhero-callback/')