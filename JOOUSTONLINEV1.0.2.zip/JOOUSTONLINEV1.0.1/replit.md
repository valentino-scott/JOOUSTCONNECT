# JOOUST CONNECT

**Tagline:** "Connecting Minds, Building Futures"  
**Creator:** Valentino Achira

## Overview

JOOUST CONNECT is a comprehensive social networking platform built specifically for students at Jaramogi Oginga Odinga University of Science and Technology (JOOUST). The platform enables students to connect, share updates, communicate, and stay informed about university events and announcements.

## Project Status

**Current State:** ✅ **COMPLETE** - Fully functional MVP with all core features implemented, tested, and architect-approved.

**Last Updated:** October 29, 2025

**Quality Assurance:** Passed comprehensive architect review with all critical issues resolved.

## Technology Stack

### Backend
- **Framework:** Django 5.2.7
- **Database:** SQLite (development)
- **Python:** 3.12
- **Key Libraries:**
  - Pillow (image processing)
  - python-decouple (environment management)

### Frontend
- **CSS Framework:** TailwindCSS (via CDN)
- **JavaScript:** Vanilla JS with Fetch API
- **Icons:** Emoji-based icons for simplicity

### Architecture
- **Pattern:** Modular multi-app Django structure
- **Apps:** 8 separate Django apps for clean separation of concerns

## Project Structure

```
JOOUST_CONNECT/
├── jooust_connect/          # Main project settings
├── accounts/                # User authentication, profiles, follow system
├── posts/                   # Posts, likes, comments, reposts
├── messaging/               # Private messaging between users
├── notifications/           # User notifications system
├── subscriptions/           # Free/Premium tiers with blue tick
├── reports/                 # Content moderation and reporting
├── announcements/           # University announcements
├── core/                    # Home feed and shared functionality
├── templates/               # HTML templates
├── static/                  # Static files
├── media/                   # User-uploaded content
└── manage.py               # Django management script
```

## Core Features Implemented

### User Management (accounts app)
- User registration and authentication
- Profile customization (bio, course, department, year, photo, cover photo)
- Follow/unfollow system
- Followers and following lists
- User search by name, course, or department
- Account deactivation/reactivation
- Blue tick verification for premium users

### Social Features (posts app)
- Create posts with text, images, GIFs, and videos
- Like/unlike posts
- Comment system
- Repost functionality (like retweet)
- Post view counter (unique views tracking)
- Explore feed with trending algorithm
- Report posts

### Messaging (messaging app)
- Private direct messages between users
- Chat threads with conversation history
- Read/unread status tracking
- Auto-refresh capability with Fetch API

### Notifications (notifications app)
- Real-time notifications for:
  - New followers
  - Post likes
  - Post comments
  - Post reposts
  - Private messages
- Notification count badge
- Mark as read/unread

### Subscriptions (subscriptions app)
- **Free Tier:** All basic features
- **Premium Tier (KES 500/month):**
  - Blue tick verification badge
  - Priority support
  - Premium badge display
- Payment mockup system (ready for M-Pesa/Stripe integration)
- Subscription management

### Content Moderation (reports app)
- Report posts and users
- Multiple report categories (spam, harassment, hate speech, etc.)
- Admin review system via Django Admin
- Report status tracking

### Announcements (announcements app)
- University-wide announcements
- Category-based organization
- Pinned important announcements
- Image support for announcements

### UI/UX Features
- Twitter/X-inspired layout
- Left sidebar navigation
- Center feed for main content
- Right sidebar for trending and search
- Light/Dark mode toggle with localStorage persistence
- Fully responsive design
- TailwindCSS for modern, clean styling

## Recent Changes

**October 29, 2025 - Final Completion:**
- ✅ Created complete Django project structure with 8 modular apps
- ✅ Implemented all models, views, forms, URLs, and admin interfaces
- ✅ Created comprehensive template system with TailwindCSS (30+ templates)
- ✅ Populated database with 5 dummy users, 10 posts, messages, and announcements
- ✅ Configured Django development server on port 5000
- ✅ Fixed SECRET_KEY to use environment variables for security
- ✅ Completed notification system (follow, like, comment, repost notifications)
- ✅ Completed subscription upgrade/downgrade flows with payment mockup
- ✅ Completed end-to-end reporting system for content moderation
- ✅ Added all missing templates (messaging, subscriptions, reports, search)
- ✅ Passed comprehensive architect review - all features functional
- ✅ Successfully tested all core functionality end-to-end

## User Credentials for Testing

The database has been prepopulated with dummy data. You can log in with any of these test accounts:

- Username: `john_doe` | Password: `password123`
- Username: `jane_smith` | Password: `password123`
- Username: `mike_wilson` | Password: `password123`
- Username: `sarah_jones` | Password: `password123`
- Username: `alex_brown` | Password: `password123`

## Running the Project

### Development Server
The Django development server is configured to run automatically on port 5000:

```bash
python manage.py runserver 0.0.0.0:5000
```

### Database Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### Create Superuser
```bash
python manage.py createsuperuser
```

### Populate Dummy Data
```bash
python manage.py populate_data
```

### Admin Panel
Access at: `http://localhost:5000/admin/`

## Key URLs

- `/` - Landing page (redirects to home if authenticated)
- `/home/` - Home feed with posts from followed users
- `/accounts/login/` - User login
- `/accounts/register/` - User registration
- `/accounts/profile/<username>/` - User profile
- `/posts/explore/` - Trending posts
- `/messages/` - Private messages inbox
- `/notifications/` - Notifications list
- `/subscriptions/` - Subscription plans
- `/announcements/` - University announcements
- `/admin/` - Django admin panel

## Next Phase Features (Not Yet Implemented)

1. **AI Chatbot Integration:**
   - JOOUST Assistant with OpenAI API
   - Student support for timetables, course info, platform help
   - Floating chat icon in bottom-right corner

2. **Real-time Features:**
   - WebSockets for instant messaging
   - Live notification updates

3. **Payment Integration:**
   - M-Pesa integration for premium subscriptions
   - Stripe as alternative payment method

4. **Advanced Features:**
   - Post scheduling
   - Draft saving
   - Hashtag system
   - Advanced search filters
   - Email notifications
   - Admin moderation dashboard

## Development Notes

### Code Organization
- Each app is self-contained with its own models, views, forms, URLs, and templates
- Base template provides consistent layout across all pages
- Django signals used for automatic profile creation
- Custom management commands for data population

### Design Decisions
- SQLite for development (easy setup, no external dependencies)
- TailwindCSS via CDN (no build process required)
- Vanilla JavaScript (no framework dependencies)
- Emoji icons (no icon library needed)
- Dark mode with localStorage (persists user preference)

### Security Considerations
- CSRF protection enabled
- User authentication required for all social features
- Proper permission checks on all views
- Secure password hashing
- Input validation on all forms

## Project Goals

**Vision:** Create a vibrant digital community for JOOUST students to connect, collaborate, and stay informed.

**Mission:** Provide a simple, modern, and efficient social networking platform tailored specifically to the needs of JOOUST students.

**Values:**
- **Simplicity:** Clean, intuitive interface
- **Community:** Foster connections between students
- **Information:** Keep students informed about university activities
- **Privacy:** Respect user data and privacy

## Maintenance and Support

The project is modular and scalable, making it easy to:
- Add new features without affecting existing functionality
- Maintain and debug individual apps independently
- Scale to accommodate more users
- Integrate with external services (payments, AI, etc.)

## Credits

**Project Creator:** Valentino Achira  
**Institution:** Jaramogi Oginga Odinga University of Science and Technology (JOOUST)  
**Framework:** Django 5.2.7  
**Deployment Platform:** Replit

---

*Built with ❤️ for the JOOUST community*
